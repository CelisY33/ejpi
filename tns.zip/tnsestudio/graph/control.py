"""
control.py - Cálculos de Bode, polos/ceros y respuesta al escalón de H(s), sin Qt.
Lo usan el diálogo Bode del PC (bode.py) y los gráficos de e^jπ en el celular.
"""
from __future__ import annotations

import math

import numpy as np
import sympy as sp

from .model import fmt_num

S = sp.Symbol("s")


def _nice(raw):
    p = 10 ** math.floor(math.log10(raw))
    for m in (1, 2, 5, 10):
        if m * p >= raw:
            return m * p
    return 10 * p


def analyze(H, wmin=None, wmax=None, n=2000):
    """H: expresión sympy en s. Devuelve dict con w, mag (dB), fase (°), polos, ceros y márgenes."""
    H = sp.sympify(H)
    if H.free_symbols - {S}:
        raise ValueError("H(s) solo puede tener la variable s (le faltan valores a: %s)"
                         % ", ".join(sorted(x.name for x in H.free_symbols - {S})))
    num, den = sp.fraction(sp.together(H))
    poles, zeros = [], []
    try:
        if den.has(S):
            poles = [complex(r) for r in np.roots([complex(c) for c in sp.Poly(den, S).all_coeffs()])]
        if num.has(S):
            zeros = [complex(r) for r in np.roots([complex(c) for c in sp.Poly(num, S).all_coeffs()])]
    except (sp.PolynomialError, TypeError, ValueError):
        pass
    mags = [abs(r) for r in poles + zeros if abs(r) > 1e-12]
    if wmin is None or wmax is None:
        lo = min(mags) if mags else 1.0
        hi = max(mags) if mags else 1.0
        wmin = wmin or 10 ** (math.floor(math.log10(lo)) - 2)
        wmax = wmax or 10 ** (math.ceil(math.log10(hi)) + 2)
    w = np.logspace(math.log10(wmin), math.log10(wmax), n)
    f = sp.lambdify(S, H, modules=["numpy"])
    with np.errstate(all="ignore"):
        h = np.asarray(f(1j * w), dtype=complex) * np.ones_like(w)
    mag = 20 * np.log10(np.abs(h))
    ph = np.degrees(np.unwrap(np.angle(h)))
    # si arranca muy lejos (ej. +360) se corre a la vuelta más cercana a 0
    if np.isfinite(ph[0]):
        ph -= 360 * round(ph[0] / 360) if abs(ph[0]) > 180 else 0
    out = {"w": w, "mag": mag, "ph": ph, "poles": poles, "zeros": zeros, "gc": None, "pc": None}
    # cruce de ganancia (0 dB) y margen de fase
    s_ = np.sign(mag)
    idx = np.where((s_[:-1] * s_[1:] < 0) & np.isfinite(mag[:-1]) & np.isfinite(mag[1:]))[0]
    if len(idx):
        i = idx[0]
        t = mag[i] / (mag[i] - mag[i + 1])
        lw = math.log10(w[i]) + t * (math.log10(w[i + 1]) - math.log10(w[i]))
        pgc = ph[i] + t * (ph[i + 1] - ph[i])
        out["gc"] = (10 ** lw, 180 + pgc)
    # cruce de fase (−180°) y margen de ganancia
    d = ph + 180
    s2 = np.sign(d)
    idx = np.where((s2[:-1] * s2[1:] < 0) & np.isfinite(d[:-1]) & np.isfinite(d[1:]))[0]
    if len(idx):
        i = idx[0]
        t = d[i] / (d[i] - d[i + 1])
        lw = math.log10(w[i]) + t * (math.log10(w[i + 1]) - math.log10(w[i]))
        mpc = mag[i] + t * (mag[i + 1] - mag[i])
        out["pc"] = (10 ** lw, -mpc)
    return out


def _croot(z):
    if abs(z.imag) < 1e-9 * max(1, abs(z)):
        return fmt_num(z.real)
    return "%s %s %sⅈ" % (fmt_num(z.real), "−" if z.imag < 0 else "+", fmt_num(abs(z.imag)))


def _expm(M):
    """exp(M) con Padé (6) y escalado (para no depender de SciPy)."""
    n = M.shape[0]
    nrm = np.linalg.norm(M, 1)
    j = max(0, int(math.ceil(math.log2(nrm))) + 1) if nrm > 0.5 else 0
    A = M / (2 ** j)
    c = [1.0, 0.5, 0.11363636363636363, 0.015151515151515152, 0.0012626262626262627,
         6.313131313131313e-05, 1.5031265031265032e-06]
    I = np.eye(n)
    X = I.copy()
    N = I * c[0]
    D = I * c[0]
    sign = 1
    for k in range(1, 7):
        X = A @ X
        N = N + c[k] * X
        sign = -sign
        D = D + sign * c[k] * X
    E = np.linalg.solve(D, N)
    for _ in range(j):
        E = E @ E
    return E


def step_response(H, T=None, n=1500):
    """y(t) para una entrada escalón unitario. H racional en s (propia)."""
    H = sp.sympify(H)
    num, den = sp.fraction(sp.together(H))
    pn = sp.Poly(num, S)
    pd = sp.Poly(den, S)
    if pn.degree() > pd.degree():
        raise ValueError("H(s) debe ser propia (grado del numerador ≤ grado del denominador)")
    a = [float(sp.N(v)) for v in pd.all_coeffs()]
    b = [float(sp.N(v)) for v in pn.all_coeffs()]
    a0 = a[0]
    a = [v / a0 for v in a]
    b = [v / a0 for v in b]
    nd = len(a) - 1
    b = [0.0] * (nd + 1 - len(b)) + b
    D_ = b[0]
    if nd == 0:
        t = np.linspace(0, T or 10, n)
        return t, np.full_like(t, D_), {}
    # forma canónica controlable
    A = np.zeros((nd, nd))
    A[0, :] = -np.array(a[1:])
    A[1:, :-1] = np.eye(nd - 1)
    B = np.zeros((nd, 1))
    B[0, 0] = 1
    C = np.array([b[k + 1] - b[0] * a[k + 1] for k in range(nd)]).reshape(1, nd)
    poles = np.roots(a)
    re = [-p.real for p in poles if p.real < -1e-9]
    stable = all(p.real < -1e-9 for p in poles)
    if T is None:
        T = min(1e4, 8.0 / min(re)) if stable and re else 10.0
        if stable:
            T = max(T, 4 * 2 * math.pi / max([abs(p.imag) for p in poles] + [1e-9]) if any(abs(p.imag) > 1e-9 for p in poles) else T)
            T = min(T, 8.0 / min(re) * 1.5)
    dt = T / (n - 1)
    Mbig = np.zeros((nd + 1, nd + 1))
    Mbig[:nd, :nd] = A * dt
    Mbig[:nd, nd:] = B * dt
    E = _expm(Mbig)
    Ad, Bd = E[:nd, :nd], E[:nd, nd:]
    x = np.zeros((nd, 1))
    y = np.empty(n)
    for k in range(n):
        y[k] = float((C @ x)[0, 0]) + D_
        x = Ad @ x + Bd
    t = np.linspace(0, T, n)
    info = {"stable": stable, "poles": poles}
    if stable:
        yf = float(sp.N(H.subs(S, 0)))
        info["final"] = yf
        if abs(yf) > 1e-12:
            yp = float(np.max(y)) if yf > 0 else float(np.min(y))
            info["overshoot"] = max(0.0, (yp - yf) / yf * 100)
            info["tpeak"] = float(t[int(np.argmax(y if yf > 0 else -y))])
            r = y / yf
            try:
                t10 = t[np.where(r >= 0.1)[0][0]]
                t90 = t[np.where(r >= 0.9)[0][0]]
                info["trise"] = float(t90 - t10)
            except IndexError:
                pass
            out = np.where(np.abs(r - 1) > 0.02)[0]
            if len(out) and out[-1] < n - 1:
                info["tsettle"] = float(t[out[-1] + 1])
    return t, y, info
