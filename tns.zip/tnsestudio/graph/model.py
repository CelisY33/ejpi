"""
model.py - Objetos de la pestaña Gráficos (estilo GeoGebra) y su cálculo numérico.

Se escriben como en la calculadora (mismo lector de expresiones) y se dibujan con NumPy:
    f(x)=x^2-1        función con nombre (se puede usar después: g(x)=f(x)+1, f'(x))
    x^2-1             función (le pone nombre solo: f, g, h…)
    y=2x+1            función            x=3   recta vertical      x=y^2   x en función de y
    x^2+y^2=4         curva implícita    y<x^2, x^2+y^2≤9, x>1 and y>0   región sombreada
    (2,3)  A=(1,2)    puntos (se arrastran con el mouse)
    (cos(t),sin(t))   curva paramétrica (t de 0 a 2π)       curva(x(t),y(t),t,a,b)
    r=2sin(3θ)        curva polar (θ de 0 a 2π)              polar(r(θ),a,b)
    a=2               deslizador (las letras libres crean uno solo)
    tangente(f,1)     recta tangente     integral(f,0,2) / area(f,g,a,b)  área sombreada con su valor
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

import numpy as np
import sympy as sp

from ..calc.engine import CalcError, Engine, Parser, Settings, tokenize

X, Y, T = sp.Symbol("x"), sp.Symbol("y"), sp.Symbol("t")
TH = sp.Symbol("θ")
COORDS = {X, Y, T, TH}

COLORS = ["#1565C0", "#C62828", "#2E7D32", "#6A1B9A", "#EF6C00", "#00838F", "#AD1457", "#5D4037",
          "#283593", "#558B2F"]
FUNC_NAMES = list("fghpqsuvw") + ["f%d" % i for i in range(1, 100)]
POINT_NAMES = [c for c in "ABCDEFGHIJKLMNOPQRSUVWZ"] + ["P%d" % i for i in range(1, 100)]

_NP = [{"sec": lambda v: 1 / np.cos(v), "csc": lambda v: 1 / np.sin(v), "cot": lambda v: 1 / np.tan(v),
        "asec": lambda v: np.arccos(1 / v), "acsc": lambda v: np.arcsin(1 / v),
        "acot": lambda v: np.arctan(1 / v)}, "numpy"]


class GraphError(ValueError):
    pass


@dataclass
class GObj:
    text: str                       # lo que se escribió (lineal)
    kind: str = ""                  # func, xfunc, vline, implicit, region, point, param, polar, slider,
                                    # tangent, area
    name: str = ""
    color: str = COLORS[0]
    visible: bool = True
    error: str = ""
    row: object = None              # fila 2D para mostrar en la lista (opcional)
    expr: object = None             # sympy
    fn: object = None               # numpy: f(x), F(x,y), máscara(x,y), (x(t), y(t)), r(θ)
    data: dict = field(default_factory=dict)
    auto_name: bool = False

    # ---- para guardar
    def to_json(self):
        d = {"text": self.text, "color": self.color, "visible": self.visible}
        if self.kind == "slider":
            d.update({"min": self.data.get("min"), "max": self.data.get("max"), "step": self.data.get("step")})
        if not self.auto_name:
            d["name"] = self.name
        else:
            d["auto"] = self.name
        return d


def _real(v, shape):
    """Valores de NumPy -> reales (lo complejo y lo infinito pasa a nan)."""
    a = np.asarray(v)
    if a.shape != shape:
        a = np.broadcast_to(a, shape).copy() if a.ndim == 0 or a.size == 1 else np.full(shape, np.nan)
    if np.iscomplexobj(a):
        a = np.where(np.abs(a.imag) < 1e-9 * (1 + np.abs(a.real)), a.real, np.nan)
    a = a.astype(float, copy=False)
    a[~np.isfinite(a)] = np.nan
    return a


def _real_roots(e):
    """x^(1/3) de un negativo da negativo (como la TI y GeoGebra), no complejo."""
    def is_odd_root(p):
        return isinstance(p, sp.Pow) and p.exp.is_Rational and not p.exp.is_Integer and p.exp.q % 2 == 1

    def fix(p):
        b, ex = p.base, p.exp
        sgn = sp.sign(b) if ex.p % 2 else sp.Integer(1)
        return sgn * sp.Abs(b) ** ex
    try:
        return e.replace(is_odd_root, fix)
    except Exception:  # noqa: BLE001
        return e


def lambdify(args, e):
    e = _real_roots(sp.sympify(e))
    if e.has(sp.Symbol) and any(s.name.startswith("_") for s in e.free_symbols):
        raise GraphError("Las unidades no se pueden graficar")
    f = sp.lambdify(args, e, modules=_NP)

    def g(*vals):
        with np.errstate(all="ignore"):
            try:
                return f(*vals)
            except (ZeroDivisionError, OverflowError, ValueError, TypeError):
                shape = np.shape(vals[0])
                return np.full(shape, np.nan)
    return g


def fmt_num(v, nd=4):
    """2.5, −1.4142, 3 (como GeoGebra: pocos decimales)."""
    if v is None or not np.isfinite(v):
        return "?"
    if abs(v) < 0.5 * 10 ** -nd:
        v = 0.0
    if abs(v) >= 1e6 or (abs(v) < 1e-3 and v != 0):
        s = "%.*g" % (nd, v)
    else:
        s = ("%.*f" % (nd, v)).rstrip("0").rstrip(".")
    if s in ("-0", ""):
        s = "0"
    return s.replace("-", "−")


# ---------------------------------------------------------------- escena
class Scene:
    def __init__(self):
        self.objs: list[GObj] = []
        self.version = 0
        self._new_engine()

    ext = None          # () -> (funciones, variables) de la calculadora

    def _new_engine(self):
        self.eng = Engine(Settings(angle="Radián", mode="Exacto", cplx="Real"))
        # en los gráficos el ángulo de un fasor va en grados (230∠30), las funciones en radianes
        self.eng.polar = lambda r, th: sp.expand(r * (sp.cos(th * sp.pi / 180) + sp.I * sp.sin(th * sp.pi / 180)))
        self._ext_vars = {}
        if self.ext is not None:
            try:
                funcs, names, vars_ = self.ext()
                for k, v in funcs.items():
                    self.eng.funcs.setdefault(k, v)
                    self.eng.names.setdefault(k, names.get(k, k))
                self._ext_vars = {k: v for k, v in vars_.items() if isinstance(v, sp.Basic)}
            except Exception:  # noqa: BLE001
                pass

    # ---- nombres
    def names(self):
        return {o.name for o in self.objs if o.name}

    def _free_name(self, pool, extra=()):
        used = self.names() | set(extra) | self._explicit_names() | set(getattr(self, "eng", None) and
                                                                         self.eng.funcs.keys() or [])
        used_l = {u.lower() for u in used}
        for n in pool:
            if n not in used and n.lower() not in used_l and n.lower() not in ("x", "y", "t", "e", "i", "r"):
                return n
        return "obj%d" % (len(self.objs) + 1)

    def get(self, name):
        for o in self.objs:
            if o.name == name:
                return o
        return None

    def next_color(self):
        used = [o.color for o in self.objs if o.kind != "slider"]
        for c in COLORS:
            if c not in used:
                return c
        return COLORS[len(used) % len(COLORS)]

    # ---- agregar / cambiar
    def add(self, text, row=None, color=None, name=None, visible=True, extra=None):
        o = GObj(text=text.strip(), row=row, color=color or self.next_color(), visible=visible)
        if name:
            o.name = name
        if extra:
            o.data.update({k: v for k, v in extra.items() if v is not None})
        self.objs.append(o)
        self.rebuild()
        self._auto_sliders()
        return o

    def replace(self, o, text, row=None):
        o.text = text.strip()
        o.row = row
        if o.auto_name:
            o.name = ""
        self.rebuild()
        self._auto_sliders()

    def remove(self, o):
        if o in self.objs:
            self.objs.remove(o)
        self.rebuild()

    def clear(self):
        self.objs.clear()
        self.rebuild()

    def set_slider(self, o, value):
        o.data["value"] = float(value)
        step = o.data.get("step", 0.1)
        txt = fmt_num(value, 6).replace("−", "-")
        o.text = "%s=%s" % (o.name, txt)
        o.row = None
        _ = step
        self.rebuild()

    def _auto_sliders(self):
        """Letras libres (a, b, k…) en las expresiones: crea deslizadores, como GeoGebra."""
        known = self.names() | self._explicit_names()
        missing = []
        for o in self.objs:
            if o.error.startswith("¿") and o.data.get("free"):
                missing += [s for s in o.data["free"] if s not in known and s not in missing]
        if not missing:
            return
        for s in missing:
            sl = GObj(text="%s=1" % s, color="#5A6070")
            sl.data.update({"min": -5.0, "max": 5.0, "step": 0.1})
            self.objs.insert(0, sl)
        self.rebuild()

    # ---- compilar todo, en orden (las funciones con nombre quedan disponibles para las siguientes)
    def _explicit_names(self):
        out = set()
        for o in self.objs:
            m = re.match(r"^\s*([A-Za-zθ][A-Za-z0-9_θ]*)\s*(\(\s*[A-Za-zθ]\s*\))?\s*=(?!=)", o.text)
            if m and m.group(1) not in ("x", "y", "r"):
                out.add(m.group(1))
        return out

    def _dedupe_names(self):
        """Dos objetos con el mismo nombre (f(x)=… dos veces): el segundo pasa a g, h… (no se pisa nada)."""
        seen, renamed = set(), []
        for o in self.objs:
            m = re.match(r"^\s*([A-Za-zθ][A-Za-z0-9_θ]*)\s*(\(\s*[A-Za-zθ]\s*\))?\s*=(?!=)", o.text)
            if not m or m.group(1) in ("x", "y", "r"):
                continue
            n = m.group(1)
            if n in seen:
                pool = FUNC_NAMES if m.group(2) else [n + str(i) for i in range(2, 200)]
                new = self._free_name(pool, extra=seen)
                o.text = new + o.text[m.end(1):]
                o.row = None
                renamed.append((n, new))
                n = new
            seen.add(n)
        return renamed

    def rebuild(self, _second=False):
        self.renamed = self._dedupe_names()
        self._new_engine()
        reserved = self._explicit_names()
        for o in self.objs:
            if o.auto_name and o.name in reserved:
                o.name = ""                    # el usuario usó ese nombre: el automático cambia
        retry = []
        for o in self.objs:
            o.error = ""
            try:
                self._compile(o)
            except GraphError as e:
                o.error = str(e)
            except CalcError as e:
                o.error = str(e)
            except (TypeError, ValueError, AttributeError, NotImplementedError, sp.SympifyError,
                    ZeroDivisionError, RecursionError) as e:
                o.error = "No pude graficar eso (%s)" % str(e)[:80]
            if o.error:
                o.fn = None
                retry.append(o)
        # lo que usa algo definido más abajo (g(x)=f(x)+1 antes de f): una segunda pasada
        for o in retry:
            if o.error.startswith("¿") and not set(o.data.get("free") or []) & reserved:
                continue
            err = o.error
            o.error = ""
            try:
                self._compile(o)
            except Exception:  # noqa: BLE001
                o.error = err
                o.fn = None
        self.version += 1

    # ---- lectura
    def parse(self, text, bound=None):
        text = _derivs(text)
        toks = tokenize(text)
        p = Parser(self.eng, toks)
        if bound:
            p.bound.update(bound)
        v = p.expr()
        p._end()
        return v

    def _params(self, e, allowed=COORDS):
        """Símbolos libres que no son x, y, t, θ: deslizadores o desconocidos."""
        e = sp.sympify(e)
        if sp.Symbol("e") in e.free_symbols and not (self.get("e") and self.get("e").kind == "slider"):
            e = e.xreplace({sp.Symbol("e"): sp.E})          # e^x = ℯ^x en los gráficos (como GeoGebra)
        free = sorted({s.name for s in sp.sympify(e).free_symbols} - {s.name for s in allowed})
        ext = {}
        for s_ in free:          # variables guardadas en la calculadora (a:=5) se usan tal cual
            if not (self.get(s_) and self.get(s_).kind == "slider") and s_.lower() in self._ext_vars:
                ext[sp.Symbol(s_)] = self._ext_vars[s_.lower()]
        free = [s_ for s_ in free if sp.Symbol(s_) not in ext]
        missing = [s for s in free if not (self.get(s) and self.get(s).kind == "slider")]
        if missing:
            raise _Missing(missing)
        vals = {sp.Symbol(s): sp.Float(self.get(s).data.get("value", 1.0)) for s in free}
        vals.update(ext)
        return sp.sympify(e).xreplace(vals) if vals else sp.sympify(e)

    def _compile(self, o):
        try:
            self._compile2(o)
        except _Missing as m:
            o.data["free"] = m.names
            raise GraphError("¿%s? (se crea un deslizador)" % ", ".join(m.names))

    def _compile2(self, o):
        t = o.text.strip()
        for a, b in (("@<", "∠"), ("@i", "ⅈ"), ("@e", "ℯ"), ("@>", "▸"), ("<=", "≤"), (">=", "≥")):
            t = t.replace(a, b)
        if not t:
            raise GraphError("Vacío")
        o.data.pop("free", None)
        low = t.lower()
        # comandos
        m = re.match(r"^\s*(tangente|tangent|integral|area|área|curva|curve|polar)\s*\((.*)\)\s*$", t, re.I)
        if m:
            return self._command(o, m.group(1).lower().replace("á", "a"), _split(m.group(2)))
        # nombre = …
        m = re.match(r"^\s*([A-Za-zθ][A-Za-z0-9_θ]*)\s*\(\s*([A-Za-zθ])\s*\)\s*=(?!=)(.*)$", t)
        if m and m.group(1).lower() not in ("y", "x", "r"):
            return self._function(o, m.group(1), m.group(2), m.group(3))
        m = re.match(r"^\s*([A-Za-z][A-Za-z0-9_]*)\s*=\s*(\(.*\))\s*$", t)
        if m and m.group(1) not in ("x", "y", "r") and _is_tuple(m.group(2)):
            o.name = m.group(1)
            return self._tuple(o, m.group(2))
        if _is_tuple(t):
            return self._tuple(o, t)
        m = re.match(r"^\s*r\s*=(.*)$", t)
        if m and "θ" in m.group(1):
            return self._polar(o, m.group(1), 0, 2 * math.pi)
        m = re.match(r"^\s*([A-Za-z][A-Za-z0-9_]*)\s*=(?!=)\s*([^=<>≤≥≠]*)$", t)
        if m and m.group(1) not in ("x", "y") and not low.startswith("r=θ"):
            name, rhs = m.group(1), m.group(2)
            v = self.parse(rhs)
            if not (sp.sympify(v).free_symbols - _unit_syms(sp.sympify(v))):
                return self._slider(o, name, v)
            fs = sp.sympify(v).free_symbols
            if X in fs and Y not in fs and name not in ("r",):       # g=x^2+1 es g(x)=x^2+1
                return self._function(o, name, "x", rhs)
        # x^2 | x>0 : con dominio (como la TI)
        parts = _split_bar(t)
        if parts:
            v = self.parse(parts[0])
            cond = self.parse(parts[1])
            if isinstance(v, sp.Expr) and isinstance(cond, (sp.Rel, sp.And, sp.Or)):
                return self._relation(o, sp.Piecewise((v, cond), (sp.nan, True)))
        # ecuación / desigualdad / expresión
        v = self.parse(t)
        return self._relation(o, v)

    # ---- tipos
    def _function(self, o, name, var, body_text):
        sym = sp.Symbol(var)
        body = self.parse(body_text, {var.lower(): sym})
        body = sp.sympify(body)
        if var == "θ" or (name.lower() == "r"):
            return self._polar_expr(o, body.xreplace({sym: TH}), 0, 2 * math.pi, name=name)
        o.name = name
        e = body.xreplace({sym: X})
        self.eng.funcs[name.lower()] = ([X], e)
        self.eng.names[name.lower()] = name
        return self._func_expr(o, e)

    def _func_expr(self, o, e, kind="func"):
        e = sp.sympify(e)
        if isinstance(e, (sp.MatrixBase,)) or not isinstance(e, sp.Expr):
            raise GraphError("Eso no es una función de x")
        if e.free_symbols & {Y}:
            raise GraphError("Una función de x no puede tener y")
        en = self._params(e, {X})
        o.kind = kind
        o.expr = e
        o.fn = lambdify(X, en)
        try:
            d1 = sp.diff(en, X)
            o.data["d1"] = lambdify(X, d1)
            o.data["d2"] = lambdify(X, sp.diff(d1, X))
        except Exception:  # noqa: BLE001
            o.data.pop("d1", None)
            o.data.pop("d2", None)
        if not o.name:
            o.name = self._free_name(FUNC_NAMES)
            o.auto_name = True
        if o.name not in self.eng.funcs and o.name.lower() not in ("x", "y"):
            self.eng.funcs[o.name.lower()] = ([X], e)
            self.eng.names[o.name.lower()] = o.name

    def _relation(self, o, v):
        if isinstance(v, (bool,)) or v in (sp.true, sp.false):
            raise GraphError("Eso es siempre %s" % ("verdadero" if v in (True, sp.true) else "falso"))
        if isinstance(v, sp.Equality):
            lhs, rhs = v.lhs, v.rhs
            fs = v.free_symbols
            if lhs == Y and Y not in rhs.free_symbols:
                return self._func_expr(o, rhs)
            if lhs == X and X not in rhs.free_symbols:
                if Y in rhs.free_symbols:
                    return self._xfunc(o, rhs)
                c = self._params(rhs, set())
                o.kind, o.expr = "vline", rhs
                o.data["x"] = float(sp.N(c))
                self._curve_name(o)
                return
            if not (fs & {X, Y}):
                raise GraphError("La ecuación no tiene x ni y")
            G = sp.sympify(lhs - rhs)
            Gn = self._params(G, {X, Y})
            o.kind, o.expr = "implicit", v
            o.fn = lambdify((X, Y), Gn)
            self._curve_name(o)
            return
        if isinstance(v, (sp.Rel, sp.And, sp.Or, sp.Not)) and not isinstance(v, sp.Equality):
            if not (v.free_symbols & {X, Y}):
                raise GraphError("La desigualdad no tiene x ni y")
            vn = self._params(v, {X, Y})
            o.kind, o.expr = "region", v
            o.fn = lambdify((X, Y), vn)
            bounds = []
            for r in ([vn] if isinstance(vn, sp.Rel) else list(vn.atoms(sp.Rel))):
                if isinstance(r, sp.Ne):
                    continue
                strict = isinstance(r, (sp.StrictLessThan, sp.StrictGreaterThan))
                bounds.append((lambdify((X, Y), r.lhs - r.rhs), strict))
            o.data["bounds"] = bounds
            if not o.name:
                o.name = self._free_name(["r%d" % i for i in range(1, 200)])
                o.auto_name = True
            return
        e = sp.sympify(v)
        if isinstance(e, sp.Expr) and Y in e.free_symbols:
            raise GraphError("Falta el = (por ejemplo x^2+y^2=4)")
        if isinstance(e, sp.Expr) and not (e.free_symbols - _unit_syms(e)) and e.has(sp.I):
            return self._phasor(o, e)
        return self._func_expr(o, e)

    def _phasor(self, o, e):
        """230∠30 o 3+4@i: flecha desde el origen (diagrama fasorial)."""
        from ..calc import units
        unit = ""
        if units.has_units(e):
            num, u = units.split(e)
            _f, toks = units.best_unit(u)
            unit = "·".join("_" + n + ("^%s" % x if x != 1 else "") for n, x in toks)
            e = num
        c = complex(sp.N(e))
        if not (math.isfinite(c.real) and math.isfinite(c.imag)):
            raise GraphError("Ese fasor no tiene valor")
        o.kind, o.expr = "phasor", e
        o.data["z"] = (c.real, c.imag)
        o.data["unit"] = unit
        if not o.name:
            o.name = self._free_name(["v%d" % i for i in range(1, 200)])
            o.auto_name = True

    def _xfunc(self, o, e):
        en = self._params(e, {Y})
        o.kind, o.expr = "xfunc", e
        o.fn = lambdify(Y, en)
        self._curve_name(o)

    def _curve_name(self, o):
        if not o.name:
            o.name = self._free_name(["c%d" % i for i in range(1, 200)])
            o.auto_name = True

    def _tuple(self, o, t):
        parts = _split(t.strip()[1:-1])
        if len(parts) != 2:
            raise GraphError("Un punto tiene dos coordenadas: (x,y)")
        a, b = (sp.sympify(self.parse(p)) for p in parts)
        fs = (a.free_symbols | b.free_symbols)
        if T in fs:
            return self._param_expr(o, a, b, 0, 2 * math.pi)
        an, bn = self._params(a, set()), self._params(b, set())
        o.kind = "point"
        o.expr = (a, b)
        o.data["xy"] = (float(sp.N(an)), float(sp.N(bn)))
        o.data["free"] = None
        o.data["drag"] = bool(a.is_number and b.is_number)
        if not o.name:
            o.name = self._free_name(POINT_NAMES)
            o.auto_name = True

    def _param_expr(self, o, a, b, t0, t1):
        an, bn = self._params(a, {T}), self._params(b, {T})
        o.kind, o.expr = "param", (a, b)
        fx, fy = lambdify(T, an), lambdify(T, bn)
        o.fn = (fx, fy)
        o.data["t"] = (float(t0), float(t1))
        self._curve_name(o)

    def _polar(self, o, rhs, a, b):
        e = sp.sympify(self.parse(rhs))
        return self._polar_expr(o, e, a, b)

    def _polar_expr(self, o, e, a, b, name=None):
        en = self._params(e, {TH})
        o.kind, o.expr = "polar", e
        o.fn = lambdify(TH, en)
        o.data["t"] = (float(a), float(b))
        if name:
            o.name = name
        self._curve_name(o)

    def _slider(self, o, name, v):
        if name.lower() in self.eng._fn or name.lower() in ("pi", "ans"):
            raise GraphError("%s es un nombre reservado" % name)
        if sp.sympify(v).has(sp.I) or sp.sympify(v).free_symbols:
            o.name = name
            return self._phasor(o, sp.sympify(v))
        val = float(sp.N(v))
        o.kind = "slider"
        o.name = name
        o.data["value"] = val
        lo, hi = o.data.get("min", -5.0), o.data.get("max", 5.0)
        if val < lo:
            o.data["min"] = math.floor(val)
        if val > hi:
            o.data["max"] = math.ceil(val)
        o.data.setdefault("min", lo)
        o.data.setdefault("max", hi)
        o.data.setdefault("step", 0.1)

    def _fn_of(self, name):
        g = self.get(name.strip())
        if g is None or g.kind not in ("func", "tangent") or g.fn is None:
            raise GraphError("%s no es una función del gráfico" % name.strip())
        return g

    def _command(self, o, cmd, args):
        if cmd in ("tangente", "tangent"):
            if len(args) != 2:
                raise GraphError("tangente(f, a): función y el valor de x")
            g = self._fn_of(args[0])
            a = float(sp.N(self._params(self.parse(args[1]), set())))
            e = self._params(g.expr, {X})
            y0 = float(sp.N(e.subs(X, a)))
            m = float(sp.N(sp.diff(e, X).subs(X, a)))
            if not (np.isfinite(y0) and np.isfinite(m)):
                raise GraphError("No hay tangente en x=%s" % fmt_num(a))
            line = sp.Float(m, 15) * (X - sp.Float(a, 15)) + sp.Float(y0, 15)
            o.kind = "tangent"
            o.expr = sp.expand(line)
            o.fn = lambdify(X, o.expr)
            o.data.update({"at": (a, y0), "m": m, "of": g.name})
            if not o.name:
                o.name = self._free_name(["t%d" % i for i in range(1, 200)])
                o.auto_name = True
            return
        if cmd in ("integral", "area"):
            if cmd == "integral" and len(args) == 3:
                g, h, a, b = self._fn_of(args[0]), None, args[1], args[2]
            elif cmd == "area" and len(args) in (2, 4):
                g = self._fn_of(args[0])
                h = None if args[1].strip().lower() in ("0", "ejex", "eje") else self._fn_of(args[1])
                a, b = (args[2], args[3]) if len(args) == 4 else (None, None)
            else:
                raise GraphError("integral(f, a, b) o area(f, g[, a, b])")
            eg = self._params(g.expr, {X})
            eh = self._params(h.expr, {X}) if h else sp.Integer(0)
            if a is None:
                xs = _intersections(lambdify(X, eg - eh))
                if len(xs) < 2:
                    raise GraphError("No encontré dos cortes entre %s y %s; escribe area(f,g,a,b)"
                                     % (g.name, h.name if h else "el eje x"))
                a_, b_ = xs[0], xs[-1]
            else:
                a_ = float(sp.N(self._params(self.parse(a), set())))
                b_ = float(sp.N(self._params(self.parse(b), set())))
            fd = lambdify(X, eg - eh)
            xs = np.linspace(a_, b_, 4001)
            ys = _real(fd(xs), xs.shape)
            if np.isnan(ys).any():
                raise GraphError("La función no está definida en todo el intervalo")
            val = float(np.trapezoid(ys, xs)) if hasattr(np, "trapezoid") else float(np.trapz(ys, xs))
            if cmd == "area":
                val = float(np.trapezoid(np.abs(ys), xs)) if hasattr(np, "trapezoid") else float(np.trapz(np.abs(ys), xs))
            try:
                ex = sp.integrate(eg - eh if cmd == "integral" else sp.Abs(eg - eh), (X, a_, b_))
                if ex.is_number and ex.is_real and not ex.has(sp.Integral):
                    val = float(ex)
            except Exception:  # noqa: BLE001
                pass
            o.kind = "area"
            o.fn = (g.fn, h.fn if h else None)
            o.data.update({"a": a_, "b": b_, "value": val, "of": (g.name, h.name if h else None)})
            if not o.name:
                o.name = self._free_name(["A%d" % i for i in range(1, 200)] if False else
                                         ["area%d" % i for i in range(1, 200)])
                o.auto_name = True
            return
        if cmd in ("curva", "curve"):
            if len(args) not in (2, 5):
                raise GraphError("curva(x(t), y(t), t, a, b)")
            if len(args) == 5:
                var = args[2].strip()
                a = sp.sympify(self.parse(args[0], {var.lower(): T}))
                b = sp.sympify(self.parse(args[1], {var.lower(): T}))
                t0 = float(sp.N(self._params(self.parse(args[3]), set())))
                t1 = float(sp.N(self._params(self.parse(args[4]), set())))
                return self._param_expr(o, a, b, t0, t1)
            a, b = (sp.sympify(self.parse(p)) for p in args)
            return self._param_expr(o, a, b, 0, 2 * math.pi)
        if cmd == "polar":
            if len(args) not in (1, 3):
                raise GraphError("polar(r(θ), a, b)")
            e = sp.sympify(self.parse(args[0]))
            if len(args) == 3:
                a = float(sp.N(self._params(self.parse(args[1]), set())))
                b = float(sp.N(self._params(self.parse(args[2]), set())))
            else:
                a, b = 0.0, 2 * math.pi
            return self._polar_expr(o, e, a, b)
        raise GraphError("No conozco el comando %s" % cmd)

    # ---- texto para mostrar en la lista
    def display_text(self, o):
        t = o.text.strip()
        if o.kind == "func" and not o.auto_name and re.match(r"^\s*%s\s*=" % re.escape(o.name), t):
            return "%s(x)=%s" % (o.name, t.split("=", 1)[1].strip())
        if o.kind == "tangent" and "m" in o.data and not o.error:
            m, (a, y0) = o.data["m"], o.data["at"]
            b = y0 - m * a
            line = "%s*x" % fmt_num(m) if abs(m) > 1e-12 else ""
            if abs(b) > 1e-12 or not line:
                line += ("+" if b >= 0 and line else "") + fmt_num(b)
            return "%s: y=%s" % (o.name, line.replace("−", "-"))
        if o.kind == "phasor" and not o.error:
            re_, im_ = o.data["z"]
            mag, ang = math.hypot(re_, im_), math.degrees(math.atan2(im_, re_))
            return "%s=(%s∠%s°)%s" % (o.name, fmt_num(mag), fmt_num(ang), o.data.get("unit", ""))
        if o.kind == "area" and not o.error:
            return "%s=%s" % (o.name, fmt_num(o.data.get("value"), 4).replace("−", "-"))
        if o.kind in ("func", "tangent") and o.auto_name and not re.match(r"^\s*y\s*=", t):
            return "%s(x)=%s" % (o.name, t)
        if o.kind in ("func",) and re.match(r"^\s*y\s*=", t) and o.auto_name:
            return "%s(x)=%s" % (o.name, t.split("=", 1)[1])
        if o.kind == "point" and o.auto_name:
            return "%s=%s" % (o.name, t)
        if o.kind in ("implicit", "region", "param", "polar", "vline", "xfunc") and o.auto_name:
            return "%s: %s" % (o.name, t)
        return t


def _unit_syms(e):
    return {s for s in getattr(e, "free_symbols", set()) if s.name.startswith("_")}


class _Missing(Exception):
    def __init__(self, names):
        super().__init__(", ".join(names))
        self.names = names


def _split(s):
    """Separa por comas de primer nivel."""
    out, cur, depth = [], "", 0
    for c in s:
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
        if c == "," and depth == 0:
            out.append(cur)
            cur = ""
        else:
            cur += c
    out.append(cur)
    return [p.strip() for p in out]


def _split_bar(t):
    """'x^2 | x>0' -> ['x^2', 'x>0'] (solo si después de | hay una desigualdad)."""
    depth = 0
    for i, c in enumerate(t):
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
        elif c == "|" and depth == 0:
            a, b = t[:i], t[i + 1:]
            if any(op in b for op in "<>≤≥") and "=" not in a:
                return [a, b]
    return None


def _is_tuple(t):
    t = t.strip()
    if not (t.startswith("(") and t.endswith(")")):
        return False
    depth = 0
    for i, c in enumerate(t):
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
            if depth == 0 and i != len(t) - 1:
                return False
    return len(_split(t[1:-1])) == 2


def _derivs(text):
    """f'(x) -> derivative(f(x),x,1), f''(2) -> derivative(f(x),x=2,2)."""
    def rep(m):
        name, primes, arg = m.group(1), len(m.group(2)), m.group(3).strip()
        if re.fullmatch(r"[A-Za-zθ]", arg):
            return "derivative(%s(%s),%s,%d)" % (name, arg, arg, primes)
        return "derivative(%s(x),x=%s,%d)" % (name, arg, primes)
    return re.sub(r"([A-Za-z][A-Za-z0-9_]*)('+)\(([^()]*)\)", rep, text)


def _intersections(fd, lo=-50.0, hi=50.0, n=20001):
    xs = np.linspace(lo, hi, n)
    ys = _real(fd(xs), xs.shape)
    return [float(v) for v in sign_roots(fd, xs, ys)]


def sign_roots(fd, xs, ys, iters=50):
    """Ceros donde cambia el signo (sin saltos de asíntota), refinados por bisección."""
    s = np.sign(ys)
    idx = np.where((s[:-1] * s[1:] < 0) & np.isfinite(ys[:-1]) & np.isfinite(ys[1:]))[0]
    exact = np.where(ys == 0)[0]
    out = [xs[i] for i in exact]
    if len(idx):
        a, b = xs[idx].copy(), xs[idx + 1].copy()
        fa = ys[idx].copy()
        for _ in range(iters):
            m = (a + b) / 2
            fm = _real(fd(m), m.shape)
            left = np.sign(fm) == np.sign(fa)
            a = np.where(left, m, a)
            fa = np.where(left, fm, fa)
            b = np.where(left, b, m)
        m = (a + b) / 2
        fm = _real(fd(m), m.shape)
        span = np.nanmax(np.abs(ys)) if np.isfinite(ys).any() else 1.0
        ok = np.isfinite(fm) & (np.abs(fm) < 1e-6 * max(1.0, span))     # descarta saltos (1/x, tan)
        out += list(m[ok])
    return sorted(out)
