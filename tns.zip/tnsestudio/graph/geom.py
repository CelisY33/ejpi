"""
geom.py - Lo que se dibuja en un gráfico, sin Qt: líneas, curvas implícitas, regiones, áreas, puntos
especiales (raíces, máximos…), qué hay bajo el dedo/mouse y la cuadrícula.

Lo usan el gráfico del PC (view.py, que lo pinta con Qt) y e^jπ en el celular (que lo pinta en un
<canvas>). Trabaja con cualquier objeto "vista" que tenga cx, cy, sx, sy (centro y píxeles por unidad),
width(), height(), scene y selected; Viewport es la versión mínima sin ventana.
"""
from __future__ import annotations

import math

import numpy as np

from .model import _real, fmt_num, sign_roots

TRIG = ("sin", "cos", "tan", "sec", "csc", "cot")


# ---------------------------------------------------------------- vista sin ventana
class Viewport:
    def __init__(self, scene, w=360, h=480):
        self.scene = scene
        self.w, self.h = float(w), float(h)
        self.cx = self.cy = 0.0
        self.sx = self.sy = None
        self.selected = None
        self.pi_mode = "auto"
        self.grid = True

    def width(self):
        return self.w

    def height(self):
        return self.h

    def ensure_scale(self):
        if self.sx is None:
            self.sx = self.sy = max(200.0, self.w) / 20.0

    def standard(self):
        self.cx = self.cy = 0.0
        self.sx = self.sy = max(200.0, self.w) / 20.0

    def to_px(self, x, y):
        return (self.w / 2 + (x - self.cx) * self.sx, self.h / 2 - (y - self.cy) * self.sy)

    def to_world(self, px, py):
        return (self.cx + (px - self.w / 2) / self.sx, self.cy - (py - self.h / 2) / self.sy)

    def bounds(self):
        x0, y1 = self.to_world(0, 0)
        x1, y0 = self.to_world(self.w, self.h)
        return x0, x1, y0, y1

    def zoom(self, f, at=None, axis="both"):
        self.ensure_scale()
        mx, my = at if at is not None else (self.w / 2, self.h / 2)
        wx, wy = self.to_world(mx, my)
        if axis in ("both", "x"):
            self.sx = min(1e9, max(1e-6, self.sx * f))
        if axis in ("both", "y"):
            self.sy = min(1e9, max(1e-6, self.sy * f))
        self.cx = wx - (mx - self.w / 2) / self.sx
        self.cy = wy + (my - self.h / 2) / self.sy


# ---------------------------------------------------------------- cuadrícula
def pi_label(n, d):
    """n·π/d -> texto (π/2, 3π/2, −π)."""
    g = math.gcd(abs(n), d)
    n, d = n // g, d // g
    if n == 0:
        return "0"
    s = "−" if n < 0 else ""
    n = abs(n)
    num = "π" if n == 1 else "%dπ" % n
    return s + (num if d == 1 else "%s/%d" % (num, d))


def nice_step(raw):
    p = 10 ** math.floor(math.log10(raw))
    for m in (1, 2, 5, 10):
        if m * p >= raw:
            return m * p, m
    return 10 * p, 1


def pi_axis(v):
    if v.pi_mode == "on":
        return True
    if v.pi_mode == "off":
        return False
    for o in v.scene.objs:
        if o.visible and not o.error and o.kind in ("func", "tangent", "param", "polar") and o.expr is not None:
            s = str(o.expr)
            if any(t + "(" in s for t in TRIG):
                return True
    return False


def steps(scale, use_pi=False, target=70.0):
    if use_pi:
        cands = []
        for d in (12, 6, 4, 3, 2):
            cands.append((math.pi / d, d))
        for m in (1, 2, 5, 10, 20, 50, 100, 200, 500, 1000):
            cands.append((math.pi * m, 1.0 / m))
        for st, d in cands:
            if st * scale >= target + 8:
                sub = st / (2 if d in (12, 4, 2) else 3 if d in (6, 3) else 2)
                return st, sub, ("pi", d)
        st = math.pi * 1000
        return st, st / 2, ("pi", 0.001)
    st, mant = nice_step(target / scale)
    sub = st / (4 if mant == 2 else 5)
    return st, sub, ("num", st)


def label_x(val, info):
    if info[0] == "pi":
        n = round(val / math.pi * 12)
        return pi_label(n, 12)
    return fmt_num(val, 6) if abs(val) > 1e-12 * max(1, abs(info[1])) else "0"


def snap_step(v):
    st, _m = nice_step(70 / v.sx)
    return st / 10


# ---------------------------------------------------------------- ajustar la vista a lo que hay
def fit(v):
    """Ajusta la vista a lo que hay (puntos, curvas en x∈[-10,10]). Devuelve (cx, cy, sx, sy) o None."""
    xs, ys = [], []
    for o in v.scene.objs:
        if not o.visible or o.error:
            continue
        if o.kind == "point":
            xs.append(o.data["xy"][0])
            ys.append(o.data["xy"][1])
        elif o.kind == "phasor":
            xs += [0.0, o.data["z"][0]]
            ys += [0.0, o.data["z"][1]]
        elif o.kind in ("func", "tangent") and o.fn is not None:
            xv = np.linspace(v.cx - 10, v.cx + 10, 801)
            yv = _real(o.fn(xv), xv.shape)
            yv = yv[np.isfinite(yv)]
            if yv.size:
                lo, hi = np.percentile(yv, [5, 95])
                ys += [lo, hi]
                xs += [v.cx - 10, v.cx + 10]
        elif o.kind in ("param", "polar") and o.fn is not None:
            pts = param_pts(o)
            if pts is not None:
                ok = np.isfinite(pts).all(axis=1)
                if ok.any():
                    xs += [pts[ok, 0].min(), pts[ok, 0].max()]
                    ys += [pts[ok, 1].min(), pts[ok, 1].max()]
    if not xs:
        return None
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    if x1 - x0 < 1e-9:
        x0, x1 = x0 - 1, x1 + 1
    if y1 - y0 < 1e-9:
        y0, y1 = y0 - 1, y1 + 1
    w, h = max(200, v.width()), max(200, v.height())
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    sx = 0.85 * w / (x1 - x0)
    sy = 0.85 * h / (y1 - y0)
    r = sx / sy
    if 0.2 < r < 5:                      # si no es muy distinto, deja los ejes iguales (1:1)
        sx = sy = min(sx, sy)
    return cx, cy, sx, sy


# ---------------------------------------------------------------- lo que se dibuja de cada objeto
def geom(v, o):
    w, h = v.width(), v.height()
    x0, x1, y0, y1 = v.bounds()
    k = o.kind
    if k in ("func", "tangent"):
        n = max(400, int(w * 2))
        xs = np.linspace(x0, x1, n)
        ys = _real(o.fn(xs), xs.shape)
        return {"lines": polyline(v, xs, ys)}
    if k == "xfunc":
        n = max(400, int(h * 2))
        ys = np.linspace(y0, y1, n)
        xs = _real(o.fn(ys), ys.shape)
        return {"lines": polyline(v, xs, ys, vertical=True)}
    if k == "vline":
        px, _ = v.to_px(o.data["x"], 0)
        return {"lines": [np.array([[px, -10.0], [px, h + 10.0]])]}
    if k in ("param", "polar"):
        pts = param_pts(o)
        return {"lines": polyline(v, pts[:, 0], pts[:, 1], free=True)}
    if k == "implicit":
        return {"segs": contour(v, o.fn, 3)}
    if k == "region":
        return region(v, o)
    if k == "point":
        return {"pt": v.to_px(*o.data["xy"])}
    if k == "phasor":
        return {"arrow": (v.to_px(0, 0), v.to_px(*o.data["z"]))}
    if k == "area":
        return area(v, o)
    return None


def param_pts(o):
    t0, t1 = o.data["t"]
    n = 3000
    ts = np.linspace(t0, t1, n)
    if o.kind == "param":
        fx, fy = o.fn
        xs, ys = _real(fx(ts), ts.shape), _real(fy(ts), ts.shape)
    else:
        r = _real(o.fn(ts), ts.shape)
        xs, ys = r * np.cos(ts), r * np.sin(ts)
    return np.column_stack([xs, ys])


def polyline(v, xs, ys, vertical=False, free=False):
    """Trozos de línea en píxeles; se corta donde no hay valor o hay un salto (asíntota)."""
    w, h = v.width(), v.height()
    px = w / 2 + (xs - v.cx) * v.sx
    py = h / 2 - (ys - v.cy) * v.sy
    ok = np.isfinite(px) & np.isfinite(py)
    lim = 20 * max(w, h)
    px = np.clip(px, -lim, lim)
    py = np.clip(py, -lim, lim)
    jump = np.zeros(len(px), bool)
    if len(px) > 1:
        d = np.abs(np.diff(py if not vertical else px)) if not free else np.hypot(np.diff(px), np.diff(py))
        big = d > (h if not vertical else w) * (0.9 if not free else 0.5)
        jump[1:] = big
    out = []
    start = None
    for i in range(len(px)):
        if not ok[i] or jump[i]:
            if start is not None and i - start > 1:
                out.append(np.column_stack([px[start:i], py[start:i]]))
            start = i if ok[i] else None
            continue
        if start is None:
            start = i
    if start is not None and len(px) - start > 1:
        out.append(np.column_stack([px[start:], py[start:]]))
    return out


def grid_eval(v, step):
    w, h = v.width(), v.height()
    nx, ny = int(w / step) + 2, int(h / step) + 2
    pxs = np.arange(nx) * step
    pys = np.arange(ny) * step
    wx = v.cx + (pxs - w / 2) / v.sx
    wy = v.cy - (pys - h / 2) / v.sy
    XX, YY = np.meshgrid(wx, wy)
    return pxs, pys, XX, YY


def contour(v, fn, step, values=None, check=True):
    """Marching squares: segmentos de F(x,y)=0 en píxeles (filas x0, y0, x1, y1)."""
    pxs, pys, XX, YY = grid_eval(v, step)
    G = _real(fn(XX, YY), XX.shape) if values is None else values
    v0, v1 = G[:-1, :-1], G[:-1, 1:]          # arriba-izq, arriba-der
    v3, v2 = G[1:, :-1], G[1:, 1:]            # abajo-izq, abajo-der
    PX, PY = np.meshgrid(pxs, pys)
    x0, y0 = PX[:-1, :-1], PY[:-1, :-1]

    def cross(a, b):
        with np.errstate(all="ignore"):
            c = (np.sign(a) * np.sign(b) < 0) & np.isfinite(a) & np.isfinite(b)
            t = np.where(c, a / (a - b), np.nan)
        return c, t
    c0, t0 = cross(v0, v1)      # borde de arriba
    c1, t1 = cross(v1, v2)      # derecha
    c2, t2 = cross(v3, v2)      # abajo
    c3, t3 = cross(v0, v3)      # izquierda
    E = [(c0, x0 + t0 * step, y0), (c1, x0 + step, y0 + t1 * step),
         (c2, x0 + t2 * step, y0 + step), (c3, x0, y0 + t3 * step)]
    cnt = c0.astype(int) + c1 + c2 + c3
    segs = []
    pairs = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
    for a, b in pairs:
        m = E[a][0] & E[b][0] & (cnt == 2)
        if m.any():
            segs.append(np.column_stack([E[a][1][m], E[a][2][m], E[b][1][m], E[b][2][m]]))
    m4 = cnt == 4
    if m4.any():
        for a, b in ((0, 3), (1, 2)):
            segs.append(np.column_stack([E[a][1][m4], E[a][2][m4], E[b][1][m4], E[b][2][m4]]))
    if not segs:
        return np.zeros((0, 4))
    S = np.vstack(segs)
    if check and values is None and len(S):
        mx = (S[:, 0] + S[:, 2]) / 2
        my = (S[:, 1] + S[:, 3]) / 2
        wx, wy = v.to_world(mx, my)
        gm = np.abs(_real(fn(wx, wy), wx.shape))
        # en un salto (polo) el valor al medio es enorme; en un cero de verdad es casi 0
        ix = np.clip((mx / step).astype(int), 0, G.shape[1] - 2)
        iy = np.clip((my / step).astype(int), 0, G.shape[0] - 2)
        corners = np.nanmax(np.abs(np.stack([G[iy, ix], G[iy, ix + 1], G[iy + 1, ix], G[iy + 1, ix + 1]])), axis=0)
        S = S[np.isfinite(gm) & (gm <= 0.6 * corners + 1e-12)]
    return S


def region(v, o, step=2):
    """Región sombreada: máscara (celdas de step px) y su borde."""
    _pxs, _pys, XX, YY = grid_eval(v, step)
    with np.errstate(all="ignore"):
        try:
            M = np.asarray(o.fn(XX, YY))
        except Exception:  # noqa: BLE001
            M = np.zeros(XX.shape, bool)
    if M.shape != XX.shape:
        M = np.broadcast_to(M, XX.shape)
    M = M.astype(bool)
    segs = contour(v, None, step, values=np.where(M, 1.0, -1.0), check=False)
    strict = any(s for _f, s in o.data.get("bounds", [])) and not any(not s for _f, s in o.data.get("bounds", []))
    return {"mask": M, "step": step, "segs": segs, "dash": strict}


def area(v, o):
    """Área sombreada entre f y g (o el eje): borde de arriba y de abajo en píxeles y dónde va el valor."""
    f, g = o.fn
    a, b = o.data["a"], o.data["b"]
    xs = np.linspace(a, b, 600)
    y1 = _real(f(xs), xs.shape)
    y2 = _real(g(xs), xs.shape) if g is not None else np.zeros_like(xs)
    top = [v.to_px(x, y) for x, y in zip(xs, y1) if np.isfinite(y)]
    bot = [v.to_px(x, y) for x, y in zip(xs[::-1], y2[::-1]) if np.isfinite(y)]
    mid = v.to_px((a + b) / 2, (np.nanmean(y1) + np.nanmean(y2)) / 2 if np.isfinite(y1).any() else 0)
    text = "%s = %s" % ("área" if o.data.get("of", (None, None))[1] else "∫", fmt_num(o.data["value"]))
    return {"poly": top + bot, "label": mid, "text": text}


# ---------------------------------------------------------------- puntos especiales de la curva elegida
def specials(v):
    o = v.selected
    out = []
    if o is None or o.error or not o.visible or o.kind not in ("func", "tangent") or o.fn is None:
        return out
    x0, x1, y0, y1 = v.bounds()
    xs = np.linspace(x0, x1, int(max(800, v.width() * 2)))
    ys = _real(o.fn(xs), xs.shape)
    for r in sign_roots(o.fn, xs, ys):
        out.append((r, 0.0, "Raíz"))
    d1 = o.data.get("d1")
    if d1 is not None and o.kind == "func":
        ds = _real(d1(xs), xs.shape)
        for r in sign_roots(d1, xs, ds):
            yv = float(_real(o.fn(np.array([r])), (1,))[0])
            if not np.isfinite(yv):
                continue
            dd = _real(d1(np.array([r - 1e-4, r + 1e-4])), (2,))
            kind = "Máximo" if dd[0] > 0 > dd[1] else "Mínimo" if dd[0] < 0 < dd[1] else "Extremo"
            out.append((r, yv, kind))
    d2 = o.data.get("d2")
    if d2 is not None and o.kind == "func":
        dd = _real(d2(xs), xs.shape)
        if np.isfinite(dd).any() and np.nanmax(np.abs(dd)) > 1e-9:
            for r in sign_roots(d2, xs, dd):
                yv = float(_real(o.fn(np.array([r])), (1,))[0])
                if np.isfinite(yv):
                    out.append((r, yv, "Inflexión"))
    if x0 <= 0 <= x1:
        y = float(_real(o.fn(np.array([0.0])), (1,))[0])
        if np.isfinite(y):
            out.append((0.0, y, "Corte con el eje y"))
    for p in v.scene.objs:
        if p is o or not p.visible or p.error or p.kind not in ("func", "tangent") or p.fn is None:
            continue
        fd = (lambda f, g: (lambda t: _real(f(t), np.shape(t)) - _real(g(t), np.shape(t))))(o.fn, p.fn)
        dv = fd(xs)
        with np.errstate(all="ignore"):
            same = np.isfinite(dv).any() and np.nanmax(np.abs(dv)) < 1e-9
        if same:
            continue                             # la misma curva dos veces: no son intersecciones
        for r in sign_roots(fd, xs, dv):
            yv = float(_real(o.fn(np.array([r])), (1,))[0])
            out.append((r, yv, "Intersección con %s" % p.name))
    # sin repetidos
    clean = []
    for x, y, t in out:
        for i, (a, b, t2) in enumerate(clean):
            if abs(x - a) < 1e-7 and abs(y - b) < 1e-7:
                if t not in t2:
                    clean[i] = (a, b, t2 + ", " + t[0].lower() + t[1:])
                break
        else:
            clean.append((x, y, t))
    return clean


# ---------------------------------------------------------------- qué hay bajo el mouse / el dedo
def hit(v, geo, special, mx, my, radius=8):
    """("point", obj) / ("phasor", obj) / ("special", (x,y,t)) / ("curve", obj, x, y) / ("region", obj) / None.
    geo: {id(obj): geom(v, obj)}; special: specials(v)."""
    best = None
    for o in reversed(v.scene.objs):
        g = geo.get(id(o))
        if o.kind == "point" and g and o.visible and not o.error:
            x, y = g["pt"]
            d = math.hypot(x - mx, y - my)
            if d <= radius and (best is None or d < best[0]):
                best = (d, ("point", o))
        if o.kind == "phasor" and g and o.visible and not o.error:
            x, y = g["arrow"][1]
            d = math.hypot(x - mx, y - my)
            if d <= radius + 3 and (best is None or d < best[0]):
                best = (d, ("phasor", o))
    if best:
        return best[1]
    for s in special:
        x, y = v.to_px(s[0], s[1])
        if math.hypot(x - mx, y - my) <= radius:
            return ("special", s)
    wx, _wy = v.to_world(mx, my)
    for o in reversed(v.scene.objs):
        if not o.visible or o.error or o.fn is None:
            continue
        if o.kind in ("func", "tangent"):
            yv = float(_real(o.fn(np.array([wx])), (1,))[0])
            if np.isfinite(yv):
                py = v.to_px(wx, yv)[1]
                if abs(py - my) <= radius:
                    return ("curve", o, wx, yv)
            continue
        g = geo.get(id(o))
        if not g:
            continue
        pts = None
        if "lines" in g and g["lines"]:
            pts = np.vstack(g["lines"])
        elif "segs" in g and len(g["segs"]):
            pts = np.vstack([g["segs"][:, :2], g["segs"][:, 2:]])
        if pts is not None and len(pts):
            d = np.hypot(pts[:, 0] - mx, pts[:, 1] - my)
            i = int(np.argmin(d))
            if d[i] <= radius:
                x, y = v.to_world(pts[i, 0], pts[i, 1])
                return ("curve", o, x, y)
        if o.kind == "region" and "mask" in g:
            M, st = g["mask"], g["step"]
            iy, ix = int(my / st), int(mx / st)
            if 0 <= iy < M.shape[0] and 0 <= ix < M.shape[1] and M[iy, ix]:
                return ("region", o)
    return None


def hover(v, h):
    """Texto para lo que hay bajo el mouse: (px, py, texto, color) o None."""
    if not h:
        return None
    if h[0] == "point":
        o = h[1]
        x, y = o.data["xy"]
        px, py = v.to_px(x, y)
        return (px, py, "%s = (%s, %s)" % (o.name, fmt_num(x), fmt_num(y)), o.color)
    if h[0] == "phasor":
        o = h[1]
        re_, im_ = o.data["z"]
        px, py = v.to_px(re_, im_)
        txt = "%s = (%s ∠ %s°)   %s %s %sⅈ" % (o.name, fmt_num(math.hypot(re_, im_)),
                                               fmt_num(math.degrees(math.atan2(im_, re_))),
                                               fmt_num(re_), "−" if im_ < 0 else "+", fmt_num(abs(im_)))
        return (px, py, txt, o.color)
    if h[0] == "special":
        x, y, t = h[1]
        px, py = v.to_px(x, y)
        return (px, py, "%s (%s, %s)" % (t, fmt_num(x), fmt_num(y)), "#5F6673")
    if h[0] == "curve":
        o, x, y = h[1], h[2], h[3]
        px, py = v.to_px(x, y)
        return (px, py, "%s: (%s, %s)" % (o.name, fmt_num(x), fmt_num(y)), o.color)
    return None
