"""
layout.py - Arma y dibuja las expresiones 2D sin depender de Qt.

    layout(row, font_px) -> caja con w, a (sobre la línea base), d (bajo ella),
    paint(lienzo, x, base) y carets(x, base, out) con las posiciones del cursor.

El "lienzo" es cualquier objeto con estos métodos (los colores son textos "#RRGGBB"):
    text(x, y, texto, px, italic, bold, color)        texto con la línea base en y
    line(x1, y1, x2, y2, color, ancho)
    rect(x, y, w, h, color, ancho, dash=False)        solo el borde
    path(Path, color, ancho)                          trazo (moveTo / lineTo / quadTo)
Y las medidas de letra las da un objeto "fuentes" con metrics(px, italic, bold).horizontalAdvance(texto).
La app de PC usa Qt (mathview.QtCanvas / QtFonts); la calculadora usa Pillow (render.py).
"""
from __future__ import annotations

from .rows import (CLOSE, KNOWN_FUNCS, Abs, BigOp, Deriv, Frac, Ghost, Integral, Limit, LogBase, Matrix,  # noqa: F401
                   NRoot, Paren, Piecewise, Row, Sqrt, Sub, SubVar, Sup, System, _row, optional_slots)
from . import rows as _rows


class Path:
    """Trazo independiente del dibujante: lista de ("M", x, y), ("L", x, y), ("Q", cx, cy, x, y)."""

    def __init__(self):
        self.ops = []

    def moveTo(self, x, y):
        self.ops.append(("M", x, y))

    def lineTo(self, x, y):
        self.ops.append(("L", x, y))

    def quadTo(self, cx, cy, x, y):
        self.ops.append(("Q", cx, cy, x, y))


_FONTS = None          # proveedor de medidas por defecto (lo registra mathview o render)
_ADAPT = None          # convierte un dibujante "nativo" (QPainter) en lienzo (lo registra mathview)


def set_default_fonts(fonts, adapt=None):
    global _FONTS, _ADAPT
    _FONTS = fonts
    if adapt is not None:
        _ADAPT = adapt


FAMILIES = ["Cambria Math", "Cambria", "Times New Roman", "Liberation Serif", "DejaVu Serif"]
TEXT_COLOR = "#23252B"
UNIT_COLOR = "#0F6E56"
SLOT_COLOR = "#9AA1B2"
GHOST_COLOR = "#A4A9B6"

ASC = 0.74      # alto sobre la línea base (proporción del tamaño de letra)
DESC = 0.24     # bajo la línea base
AXIS = 0.28     # altura de la raya de fracción / centro de matrices
OPS = set("+−=<>≤≥≠→▸≈±")
OPENERS = set("([{,∠:") | OPS   # después de estos, + y − son signos (sin espacios)
DISPLAY = {"*": "·", "-": "−"}
UPRIGHT_LETTERS = set("πℯ∞θ°")   # letras que no van en cursiva
UNIT_CHARS = set("°Ωµμ")



class Ctx:
    def __init__(self, color=TEXT_COLOR, readonly=False, fonts=None):
        self.readonly = readonly          # en el historial no se dibujan las cajitas opcionales vacías
        self.color = color
        self.unit = UNIT_COLOR
        self.slot = SLOT_COLOR
        self.fonts = fonts or _FONTS
        if self.fonts is None:
            raise RuntimeError("No hay fuentes para dibujar (importa mathview o render)")

    def metrics(self, px, italic=False, bold=False):
        return self.fonts.metrics(px, italic, bold)


class LBox:
    """Caja de dibujo: w ancho, a sobre la base, d bajo la base."""
    w = a = d = 0.0

    def paint(self, p, x: float, y: float):
        pass

    def carets(self, x: float, y: float, out: list):
        pass


class GlyphL(LBox):
    def __init__(self, ctx, text, px, color, italic=False, bold=False, lpad=0.0, rpad=0.0):
        self.ctx, self.text, self.px, self.color = ctx, text, px, color
        self.italic, self.bold = italic, bold
        fm = ctx.metrics(px, italic, bold)
        self.lpad = lpad
        self.tw = fm.horizontalAdvance(text)
        self.w = lpad + self.tw + rpad
        self.a = ASC * px
        self.d = DESC * px

    def paint(self, p, x, y):
        p.text(x + self.lpad, y, self.text, self.px, self.italic, self.bold, self.color)


class SlotL(LBox):
    """Cajita vacía con borde punteado (gris claro si es opcional, como en la TI)."""

    def __init__(self, ctx, px, optional=False):
        self.ctx, self.px = ctx, px
        self.optional = optional
        self.w = 0.62 * px
        self.a = 0.70 * px
        self.d = 0.12 * px

    def paint(self, p, x, y):
        p.rect(x + 0.08 * self.px, y - 0.64 * self.px, 0.46 * self.px, 0.72 * self.px,
               "#C9CED8" if self.optional else self.ctx.slot, max(1.0, self.px / 18), dash=True)


KEYWORDS = ("and", "or", "xor", "not")


def _word_marks(row) -> set:
    """Índices de las letras de and / or / xor / not (van derechas, no en cursiva, como la TI)."""
    out = set()
    n = len(row)
    k = 0

    def letter(i):
        return 0 <= i < n and isinstance(row[i], str) and len(row[i]) == 1 and (row[i].isalnum() or row[i] == "_")
    while k < n:
        if letter(k) and not letter(k - 1):
            j = k
            while letter(j):
                j += 1
            if "".join(row[k:j]).lower() in KEYWORDS:
                out.update(range(k, j))
            k = j
        else:
            k += 1
    return out


def _bold_marks(row) -> set:
    """Índices de los caracteres que forman el nombre de una función conocida (solve, sin…)."""
    out = set()
    if not KNOWN_FUNCS:
        return out
    n = len(row)
    k = 0
    while k < n:
        it = row[k]
        if isinstance(it, str) and len(it) == 1 and it.isalpha() and \
                not (k > 0 and row[k - 1] == "_") and not (k > 0 and isinstance(row[k - 1], str)
                                                           and len(row[k - 1]) == 1 and (row[k - 1].isalnum())):
            j = k
            while j < n and isinstance(row[j], str) and len(row[j]) == 1 and (row[j].isalnum() or row[j] in "\\_"):
                j += 1
            name = "".join(row[k:j]).lower()
            if name in KNOWN_FUNCS:
                out.update(range(k, j))
            k = j
        else:
            if isinstance(it, str) and len(it) > 1 and it.lower() in KNOWN_FUNCS:
                out.add(k)
            k += 1
    return out


class StretchL(LBox):
    """Paréntesis escrito a mano que crece con lo que encierra (como en la TI)."""
    OPEN = {"(": "(", "[": "[", "{": "{", ")": "(", "]": "[", "}": "{"}

    def __init__(self, ctx, ch, px, a, d):
        self.ctx, self.px, self.ch = ctx, px, ch
        self.right = ch in ")]}"
        self.dw = 0.3 * px
        self.w = self.dw + 0.06 * px
        self.a, self.d = a, d
        self.lw = max(1.0, px / 16)

    def paint(self, p, x, y):
        dx = 0.06 * self.px if self.right else 0.0
        _delim(p, self.OPEN[self.ch], x + dx, self.dw, y - self.a + 0.02 * self.px, y + self.d - 0.02 * self.px,
               self.lw, self.ctx.color, right=self.right)


class RowL(LBox):
    def __init__(self, ctx, row, px, top=False, optional=False):
        self.row, self.px = row, px
        self.items = []         # (dx, LBox)
        self.offs = []          # x de cada posición del cursor (0..len)
        self.empty = None
        bold = _bold_marks(row)
        self._words = _word_marks(row)
        lbs = self._build(ctx, row, px, bold, {})
        stretch = self._stretch(row, lbs, px)
        if stretch:
            lbs = self._build(ctx, row, px, bold, stretch)
        x = 0.0
        a, d = ASC * px, DESC * px
        for lb in lbs:
            self.offs.append(x)
            self.items.append((x, lb))
            x += lb.w
            a, d = max(a, lb.a), max(d, lb.d)
        self.offs.append(x)
        if not row and not top and not (optional and ctx.readonly):
            self.empty = SlotL(ctx, px, optional)
            x = self.empty.w
            a, d = max(a, self.empty.a), max(d, self.empty.d)
        self.w, self.a, self.d = x, a, d
        self.ca, self.cd = ASC * px * 1.02, DESC * px * 1.1   # alto del cursor

    def _build(self, ctx, row, px, bold, stretch):
        out = []
        prev = None
        prev_ch = None          # carácter anterior (None al inicio o después de una caja)
        in_unit = False
        for k, it in enumerate(row):
            if k in stretch:
                lb = StretchL(ctx, it, px, *stretch[k])
                prev_ch = it
            elif isinstance(it, Ghost):
                lb = GlyphL(ctx, str(it), px, GHOST_COLOR)
                prev_ch = None
            elif isinstance(it, str):
                nxt = row[k + 1] if k + 1 < len(row) and isinstance(row[k + 1], str) else None
                if k in bold:
                    lb = GlyphL(ctx, it, px, ctx.color, bold=True, rpad=0.02 * px)
                elif k in self._words:
                    lb = GlyphL(ctx, it, px, ctx.color)
                else:
                    lb, in_unit = self._glyph(ctx, it, px, in_unit, prev_ch, prev is None, nxt)
                prev_ch = DISPLAY.get(it, it) if len(it) == 1 else None
            else:
                in_unit = False
                prev_ch = None
                lb = layout_box(ctx, it, px, prev)
            out.append(lb)
            prev = lb
        return out

    @staticmethod
    def _stretch(row, lbs, px):
        """Pares ( ) [ ] { } escritos a mano cuyo contenido es alto -> {índice: (a, d)}."""
        pairs = {"(": ")", "[": "]", "{": "}"}
        stack, out = [], {}
        for k, it in enumerate(row):
            if not isinstance(it, str) or len(it) != 1:
                continue
            if it in pairs:
                stack.append(k)
            elif it in ")]}" and stack and pairs.get(row[stack[-1]]) == it:
                i = stack.pop()
                inner = lbs[i + 1:k]
                if not inner:
                    continue
                ia = max(lb.a for lb in inner)
                idd = max(lb.d for lb in inner)
                if ia > 0.9 * px or idd > 0.36 * px:
                    out[i] = out[k] = (ia + 0.06 * px, idd + 0.06 * px)
        return out

    @staticmethod
    def _glyph(ctx, it, px, in_unit, prev_ch=None, first=False, nxt=None):
        if len(it) > 1:
            if it.startswith("_"):
                return GlyphL(ctx, it, px, ctx.unit), False
            if it[0] == "c" and it[1:].isdigit():          # constantes de deSolve: c1, c2…
                return GlyphL(ctx, it, px, ctx.color, italic=True, bold=True, rpad=0.04 * px), False
            return GlyphL(ctx, it, px, ctx.color, rpad=0.04 * px), False
        ch = DISPLAY.get(it, it)
        if ch == "_":
            return GlyphL(ctx, ch, px, ctx.unit), True
        if in_unit and (ch.isalpha() or ch in UNIT_CHARS):
            return GlyphL(ctx, ch, px, ctx.unit), True
        if ch == "ⅈ":
            return GlyphL(ctx, ch, px, ctx.color, bold=True, lpad=0.03 * px, rpad=0.05 * px), False
        if ch in "+−±" and (first or prev_ch in OPENERS):
            return GlyphL(ctx, ch, px, ctx.color, rpad=0.02 * px), False      # signo, no operación
        if ch == ":" and nxt == "=":
            return GlyphL(ctx, ch, px, ctx.color, lpad=0.16 * px), False      # :=
        if ch in OPS:
            pad = 0.16 * px
            return GlyphL(ctx, ch, px, ctx.color, lpad=0.0 if prev_ch == ":" else pad, rpad=pad), False
        if ch == ",":
            return GlyphL(ctx, ch, px, ctx.color, rpad=0.14 * px), False
        if ch.isalpha() and ch not in UPRIGHT_LETTERS:
            return GlyphL(ctx, ch, px, ctx.color, italic=True, rpad=0.06 * px), False
        return GlyphL(ctx, ch, px, ctx.color), False

    def paint(self, p, x, y):
        if not hasattr(p, "text") and _ADAPT is not None:
            p = _ADAPT(p)                     # se pasó un QPainter directo
        if self.empty:
            self.empty.paint(p, x, y)
        for dx, lb in self.items:
            lb.paint(p, x + dx, y)

    def carets(self, x, y, out):
        top, bot = y - self.ca, y + self.cd
        if self.empty:
            out.append((self.row, 0, x + 0.14 * self.px, top, bot))
            return
        for i, ox in enumerate(self.offs):
            out.append((self.row, i, x + ox, top, bot))
        for dx, lb in self.items:
            lb.carets(x + dx, y, out)


class SupL(LBox):
    def __init__(self, ctx, box, px, prev):
        cpx = max(10.0, px * 0.7)
        self.child = RowL(ctx, box.row, cpx)
        prev_a = prev.a if prev is not None else ASC * px
        self.shift = max(0.40 * px, prev_a - 0.45 * cpx)
        self.gap = 0.03 * px
        self.w = self.gap + self.child.w + 0.05 * px
        self.a = self.shift + self.child.a
        self.d = max(0.0, self.child.d - self.shift)

    def paint(self, p, x, y):
        self.child.paint(p, x + self.gap, y - self.shift)

    def carets(self, x, y, out):
        self.child.carets(x + self.gap, y - self.shift, out)


class SubL(LBox):
    def __init__(self, ctx, box, px):
        cpx = max(10.0, px * 0.7)
        self.child = RowL(ctx, box.row, cpx)
        self.shift = 0.22 * px
        self.w = self.child.w + 0.04 * px
        self.a = max(0.0, self.child.a - self.shift)
        self.d = self.shift + self.child.d

    def paint(self, p, x, y):
        self.child.paint(p, x + 0.02 * self.w, y + self.shift)

    def carets(self, x, y, out):
        self.child.carets(x + 0.02 * self.w, y + self.shift, out)


class FracL(LBox):
    def __init__(self, ctx, box, px):
        self.ctx, self.px = ctx, px
        cpx = max(11.0, px * 0.9)
        self.num = RowL(ctx, box.num, cpx)
        self.den = RowL(ctx, box.den, cpx)
        self.pad = 0.12 * px
        self.gap = 0.10 * px
        self.axis = AXIS * px
        self.bar = max(1.0, px / 20)
        inner = max(self.num.w, self.den.w) + 0.16 * px
        self.w = inner + 2 * self.pad
        self.inner = inner
        self.a = self.axis + self.gap + self.num.d + self.num.a
        self.d = max(0.0, self.den.a + self.gap + self.den.d - self.axis)

    def _pos(self, x, y):
        nx = x + self.pad + (self.inner - self.num.w) / 2
        ny = y - self.axis - self.gap - self.num.d
        dx = x + self.pad + (self.inner - self.den.w) / 2
        dy = y - self.axis + self.gap + self.den.a
        return nx, ny, dx, dy

    def paint(self, p, x, y):
        nx, ny, dx, dy = self._pos(x, y)
        self.num.paint(p, nx, ny)
        self.den.paint(p, dx, dy)
        p.line(x + self.pad, y - self.axis, x + self.pad + self.inner, y - self.axis, self.ctx.color, self.bar)

    def carets(self, x, y, out):
        nx, ny, dx, dy = self._pos(x, y)
        self.num.carets(nx, ny, out)
        self.den.carets(dx, dy, out)


class SqrtL(LBox):
    def __init__(self, ctx, box, px, index=None):
        self.ctx, self.px = ctx, px
        self.child = RowL(ctx, box.row, px)
        self.index = RowL(ctx, index, max(9.0, px * 0.55), optional=True) if index is not None else None
        self.lw = max(1.0, px / 18)
        self.gap = 0.12 * px
        self.sign = 0.62 * px
        self.lead = 0.0
        if self.index is not None:
            self.lead = max(0.0, self.index.w - 0.28 * px)
        self.w = self.lead + self.sign + self.child.w + 0.12 * px
        self.a = self.child.a + self.gap + self.lw
        if self.index is not None:
            self.a = max(self.a, 0.42 * px + self.index.a + self.index.d)
        self.d = self.child.d + 0.02 * px

    def paint(self, p, x, y):
        s = self.px
        x0 = x + self.lead
        top = y - self.child.a - self.gap
        bottom = y + self.child.d
        path = Path()
        path.moveTo(x0 + 0.04 * s, y - 0.30 * s)
        path.lineTo(x0 + 0.16 * s, y - 0.38 * s)
        path.lineTo(x0 + 0.32 * s, bottom)
        path.lineTo(x0 + 0.56 * s, top)
        path.lineTo(x + self.w - 0.04 * s, top)
        p.path(path, self.ctx.color, self.lw)
        self.child.paint(p, x0 + self.sign, y)
        if self.index is not None:
            self.index.paint(p, x0 + 0.24 * s - self.index.w, y - 0.42 * s - self.index.d)

    def carets(self, x, y, out):
        x0 = x + self.lead
        if self.index is not None:
            self.index.carets(x0 + 0.24 * self.px - self.index.w, y - 0.42 * self.px - self.index.d, out)
        self.child.carets(x0 + self.sign, y, out)


def _delim(p, kind, x, w, top, bottom, lw, color, right=False):
    """Dibuja un delimitador que crece: ( [ { | (o su par de cierre si right)."""
    path = Path()
    mid = (top + bottom) / 2

    def X(f):           # f: 0 = lado de afuera, 1 = lado de adentro
        return x + (w * (1 - f) if right else w * f)

    if kind == "(":
        path.moveTo(X(0.85), top)
        path.quadTo(X(-0.05), mid, X(0.85), bottom)
    elif kind == "[":
        path.moveTo(X(0.85), top)
        path.lineTo(X(0.25), top)
        path.lineTo(X(0.25), bottom)
        path.lineTo(X(0.85), bottom)
    elif kind == "{":
        q = (bottom - top) / 4
        path.moveTo(X(0.9), top)
        path.quadTo(X(0.45), top, X(0.45), top + q)
        path.lineTo(X(0.45), mid - q * 0.6)
        path.quadTo(X(0.45), mid, X(0.05), mid)
        path.quadTo(X(0.45), mid, X(0.45), mid + q * 0.6)
        path.lineTo(X(0.45), bottom - q)
        path.quadTo(X(0.45), bottom, X(0.9), bottom)
    else:   # |
        path.moveTo(X(0.5), top)
        path.lineTo(X(0.5), bottom)
    p.path(path, color, lw)


class DelimL(LBox):
    """Paren y Abs: delimitadores a los lados del contenido."""

    def __init__(self, ctx, row, px, kind, optional=False):
        self.ctx, self.px, self.kind = ctx, px, kind
        self.child = RowL(ctx, row, px, optional=optional)
        self.tall = self.child.a > 0.82 * px or self.child.d > 0.32 * px
        if self.tall:
            self.dw = 0.32 * px if kind != "|" else 0.22 * px
            self.a = self.child.a + 0.06 * px
            self.d = self.child.d + 0.06 * px
            self.lw = max(1.0, px / 16)
            self.w = 2 * self.dw + self.child.w + 0.04 * px
        else:
            self.open = GlyphL(ctx, kind, px, ctx.color)
            self.close = GlyphL(ctx, CLOSE.get(kind, kind), px, ctx.color)
            self.dw = self.open.w
            self.w = self.open.w + self.child.w + self.close.w + 0.04 * px
            self.a = max(self.child.a, self.open.a)
            self.d = max(self.child.d, self.open.d)

    def _cx(self, x):
        return x + self.dw + 0.02 * self.px

    def paint(self, p, x, y):
        cx = self._cx(x)
        if self.tall:
            top, bot = y - self.a + 0.02 * self.px, y + self.d - 0.02 * self.px
            _delim(p, self.kind, x, self.dw, top, bot, self.lw, self.ctx.color)
            _delim(p, self.kind, cx + self.child.w + 0.02 * self.px, self.dw, top, bot, self.lw,
                   self.ctx.color, right=True)
        else:
            self.open.paint(p, x, y)
            self.close.paint(p, cx + self.child.w + 0.02 * self.px, y)
        self.child.paint(p, cx, y)

    def carets(self, x, y, out):
        self.child.carets(self._cx(x), y, out)


class MatrixL(LBox):
    def __init__(self, ctx, box, px):
        self.ctx, self.px = ctx, px
        self.cells = [[RowL(ctx, c, px) for c in r] for r in box.rows]
        nc = box.ncols
        self.colw = [max((r[j].w for r in self.cells if j < len(r)), default=0.0) for j in range(nc)]
        self.rowa = [max((c.a for c in r), default=ASC * px) for r in self.cells]
        self.rowd = [max((c.d for c in r), default=DESC * px) for r in self.cells]
        self.cgap = 0.7 * px
        self.rgap = 0.22 * px
        self.dw = 0.3 * px
        self.lw = max(1.0, px / 16)
        inner_w = sum(self.colw) + self.cgap * max(0, nc - 1)
        inner_h = sum(self.rowa) + sum(self.rowd) + self.rgap * max(0, len(self.cells) - 1)
        self.inner_w, self.inner_h = inner_w, inner_h
        self.pad = 0.12 * px
        self.w = 2 * self.dw + inner_w + 2 * self.pad
        h = inner_h + 0.16 * px
        self.a = AXIS * px + h / 2
        self.d = max(0.0, h / 2 - AXIS * px)

    def _cells(self, x, y):
        top = y - self.a + 0.08 * self.px
        cy = top
        for i, r in enumerate(self.cells):
            base = cy + self.rowa[i]
            cx = x + self.dw + self.pad
            for j, c in enumerate(r):
                yield c, cx + (self.colw[j] - c.w) / 2, base
                cx += self.colw[j] + self.cgap
            cy = base + self.rowd[i] + self.rgap

    def paint(self, p, x, y):
        top, bot = y - self.a, y + self.d
        _delim(p, "[", x, self.dw, top, bot, self.lw, self.ctx.color)
        _delim(p, "[", x + self.w - self.dw, self.dw, top, bot, self.lw, self.ctx.color, right=True)
        for c, cx, base in self._cells(x, y):
            c.paint(p, cx, base)

    def carets(self, x, y, out):
        for c, cx, base in self._cells(x, y):
            c.carets(cx, base, out)


class HSeq(LBox):
    """Secuencia horizontal de cajas con desplazamiento vertical propio: [(LBox, dy), …]."""

    def __init__(self, parts):
        self.parts = parts
        self.w = sum(b.w for b, _ in parts)
        self.a = max((b.a - dy for b, dy in parts), default=0.0)
        self.d = max((b.d + dy for b, dy in parts), default=0.0)

    def _iter(self, x, y):
        for b, dy in self.parts:
            yield b, x, y + dy
            x += b.w

    def paint(self, p, x, y):
        for b, bx, by in self._iter(x, y):
            b.paint(p, bx, by)

    def carets(self, x, y, out):
        for b, bx, by in self._iter(x, y):
            b.carets(bx, by, out)


class Gap(LBox):
    def __init__(self, w):
        self.w = w


def _slot_row(ctx, box, i, row, px):
    return RowL(ctx, row, px, optional=i in optional_slots(box))


class StackL(LBox):
    """Columna centrada: arriba / centro / abajo (para Σ, Π, lím, ∫)."""

    def __init__(self, center, top=None, bottom=None, px=20.0, gap=0.06):
        self.c, self.t, self.b = center, top, bottom
        g = gap * px
        self.g = g
        self.w = max(center.w, top.w if top else 0, bottom.w if bottom else 0)
        self.a = center.a + ((top.a + top.d + g) if top else 0)
        self.d = center.d + ((bottom.a + bottom.d + g) if bottom else 0)

    def _pos(self, x, y):
        out = [(self.c, x + (self.w - self.c.w) / 2, y)]
        if self.t:
            out.append((self.t, x + (self.w - self.t.w) / 2, y - self.c.a - self.g - self.t.d))
        if self.b:
            out.append((self.b, x + (self.w - self.b.w) / 2, y + self.c.d + self.g + self.b.a))
        return out

    def paint(self, p, x, y):
        for b, bx, by in self._pos(x, y):
            b.paint(p, bx, by)

    def carets(self, x, y, out):
        for b, bx, by in self._pos(x, y):
            b.carets(bx, by, out)


class BigGlyphL(GlyphL):
    def __init__(self, ctx, text, px, scale=1.6):
        super().__init__(ctx, text, px * scale, ctx.color)
        self.a = 0.62 * px * scale
        self.d = 0.18 * px * scale


def _paren_of(ctx, row, px, i=None, box=None):
    return DelimL(ctx, row, px, "(", optional=(box is not None and i in optional_slots(box)))


def LogL(ctx, box, px):
    cpx = max(10.0, px * 0.7)
    base = _slot_row(ctx, box, 0, box.base, cpx)
    return HSeq([(GlyphL(ctx, "log", px, ctx.color), 0.0), (base, 0.25 * px),
                 (DelimL(ctx, box.arg, px, "("), 0.0)])


def BigOpL(ctx, box, px):
    cpx = max(10.0, px * 0.7)
    below = HSeq([(RowL(ctx, box.var, cpx), 0.0), (GlyphL(ctx, "=", cpx, ctx.color), 0.0),
                  (RowL(ctx, box.lo, cpx), 0.0)])
    st = StackL(BigGlyphL(ctx, "∑" if box.op == "Σ" else "∏", px), RowL(ctx, box.hi, cpx), below, px)
    return HSeq([(st, 0.0), (Gap(0.08 * px), 0.0), (DelimL(ctx, box.body, px, "("), 0.0)])


def DerivL(ctx, box, px):
    cpx = max(11.0, px * 0.9)
    tiny = max(9.0, px * 0.6)
    if box.order is not None:
        num = HSeq([(GlyphL(ctx, "d", cpx, ctx.color, italic=True), 0.0),
                    (RowL(ctx, box.order, tiny, optional=True), -0.35 * cpx)])
        den = HSeq([(GlyphL(ctx, "d", cpx, ctx.color, italic=True), 0.0), (RowL(ctx, box.var, cpx), 0.0),
                    (_Mirror(box.order, ctx, tiny), -0.35 * cpx)])
    else:
        num = GlyphL(ctx, "d", cpx, ctx.color, italic=True)
        den = HSeq([(GlyphL(ctx, "d", cpx, ctx.color, italic=True), 0.0), (RowL(ctx, box.var, cpx), 0.0)])
    return HSeq([(_FracOf(ctx, num, den, px), 0.0), (DelimL(ctx, box.body, px, "("), 0.0)])


class _Mirror(LBox):
    """Copia (sin cursor) del orden de la derivada, para el denominador d x^n."""

    def __init__(self, row, ctx, px):
        self.lay = RowL(ctx, row, px, optional=True)
        self.w, self.a, self.d = self.lay.w, self.lay.a, self.lay.d

    def paint(self, p, x, y):
        self.lay.paint(p, x, y)


class _FracOf(LBox):
    """Fracción entre dos cajas ya armadas (sin cursor en ellas salvo lo que traigan)."""

    def __init__(self, ctx, num, den, px):
        self.ctx, self.px = ctx, px
        self.num, self.den = num, den
        self.pad, self.gap, self.axis = 0.08 * px, 0.08 * px, AXIS * px
        self.inner = max(num.w, den.w) + 0.1 * px
        self.w = self.inner + 2 * self.pad
        self.a = self.axis + self.gap + num.d + num.a
        self.d = max(0.0, den.a + self.gap + den.d - self.axis)

    def _pos(self, x, y):
        return ((self.num, x + self.pad + (self.inner - self.num.w) / 2, y - self.axis - self.gap - self.num.d),
                (self.den, x + self.pad + (self.inner - self.den.w) / 2, y - self.axis + self.gap + self.den.a))

    def paint(self, p, x, y):
        for b, bx, by in self._pos(x, y):
            b.paint(p, bx, by)
        p.line(x + self.pad, y - self.axis, x + self.pad + self.inner, y - self.axis, self.ctx.color,
               max(1.0, self.px / 20))

    def carets(self, x, y, out):
        for b, bx, by in self._pos(x, y):
            b.carets(bx, by, out)


def IntegralL(ctx, box, px):
    cpx = max(10.0, px * 0.65)
    sign = BigGlyphL(ctx, "∫", px, 1.7)
    parts = [(sign, 0.0)]
    if box.definite:
        lims = StackL(Gap(0.0), _slot_row(ctx, box, 1, box.hi, cpx), _slot_row(ctx, box, 0, box.lo, cpx), px, gap=0.5)
        parts.append((lims, 0.0))
    parts += [(Gap(0.06 * px), 0.0), (RowL(ctx, box.body, px), 0.0), (Gap(0.12 * px), 0.0),
              (GlyphL(ctx, "d", px, ctx.color, italic=True), 0.0), (RowL(ctx, box.var, px), 0.0)]
    return HSeq(parts)


def LimitL(ctx, box, px):
    cpx = max(10.0, px * 0.7)
    tiny = max(9.0, px * 0.55)
    below = HSeq([(RowL(ctx, box.var, cpx), 0.0), (GlyphL(ctx, "→", cpx, ctx.color), 0.0),
                  (RowL(ctx, box.point, cpx), 0.0), (_slot_row(ctx, box, 2, box.dir, tiny), -0.3 * cpx)])
    st = StackL(GlyphL(ctx, "lim", px, ctx.color), None, below, px, gap=0.0)
    return HSeq([(st, 0.0), (Gap(0.06 * px), 0.0), (DelimL(ctx, box.body, px, "("), 0.0)])


def SubVarL(ctx, box, px):
    cpx = max(10.0, px * 0.7)
    return HSeq([(RowL(ctx, box.base, px), 0.0), (RowL(ctx, box.sub, cpx), 0.25 * px)])


class PiecewiseL(LBox):
    def __init__(self, ctx, box, px):
        self.ctx, self.px = ctx, px
        n = len(box.rows)
        self.cells = []
        for i, (v, c) in enumerate(box.rows):
            cv = RowL(ctx, v, px)
            cc = RowL(ctx, c, px, optional=(2 * i + 1) in optional_slots(box))
            self.cells.append((cv, GlyphL(ctx, ",", px, ctx.color, rpad=0.15 * px), cc))
        self.c0 = max(c[0].w for c in self.cells)
        self.rgap = 0.18 * px
        self.dw = 0.42 * px
        self.lw = max(1.0, px / 16)
        inner_w = self.c0 + max(c[1].w + c[2].w for c in self.cells)
        inner_h = sum(max(c[0].a, c[2].a) + max(c[0].d, c[2].d) for c in self.cells) + self.rgap * max(0, n - 1)
        self.w = self.dw + 0.1 * px + inner_w + 0.08 * px
        h = inner_h + 0.12 * px
        self.a = AXIS * px + h / 2
        self.d = max(0.0, h / 2 - AXIS * px)

    def _cells(self, x, y):
        cy = y - self.a + 0.06 * self.px
        for cv, comma, cc in self.cells:
            a = max(cv.a, cc.a)
            base = cy + a
            x0 = x + self.dw + 0.1 * self.px
            yield cv, x0, base
            yield comma, x0 + self.c0, base
            yield cc, x0 + self.c0 + comma.w, base
            cy = base + max(cv.d, cc.d) + self.rgap

    def paint(self, p, x, y):
        _delim(p, "{", x, self.dw, y - self.a, y + self.d, self.lw, self.ctx.color)
        for b, bx, by in self._cells(x, y):
            b.paint(p, bx, by)

    def carets(self, x, y, out):
        for b, bx, by in self._cells(x, y):
            b.carets(bx, by, out)


class SystemL(LBox):
    def __init__(self, ctx, box, px):
        self.ctx, self.px = ctx, px
        self.cells = [RowL(ctx, r, px) for r in box.rows]
        self.rgap = 0.18 * px
        self.dw = 0.42 * px
        self.lw = max(1.0, px / 16)
        inner_w = max((c.w for c in self.cells), default=0.0)
        inner_h = sum(c.a + c.d for c in self.cells) + self.rgap * max(0, len(self.cells) - 1)
        self.w = self.dw + 0.1 * px + inner_w + 0.08 * px
        h = inner_h + 0.12 * px
        self.a = AXIS * px + h / 2
        self.d = max(0.0, h / 2 - AXIS * px)

    def _cells(self, x, y):
        cy = y - self.a + 0.06 * self.px
        for c in self.cells:
            base = cy + c.a
            yield c, x + self.dw + 0.1 * self.px, base
            cy = base + c.d + self.rgap

    def paint(self, p, x, y):
        _delim(p, "{", x, self.dw, y - self.a, y + self.d, self.lw, self.ctx.color)
        for c, cx, base in self._cells(x, y):
            c.paint(p, cx, base)

    def carets(self, x, y, out):
        for c, cx, base in self._cells(x, y):
            c.carets(cx, base, out)


def layout_box(ctx, box, px, prev=None) -> LBox:
    if isinstance(box, System):
        return SystemL(ctx, box, px)
    if isinstance(box, Piecewise):
        return PiecewiseL(ctx, box, px)
    if isinstance(box, LogBase):
        return LogL(ctx, box, px)
    if isinstance(box, BigOp):
        return BigOpL(ctx, box, px)
    if isinstance(box, Deriv):
        return DerivL(ctx, box, px)
    if isinstance(box, Integral):
        return IntegralL(ctx, box, px)
    if isinstance(box, Limit):
        return LimitL(ctx, box, px)
    if isinstance(box, SubVar):
        return SubVarL(ctx, box, px)
    if isinstance(box, Sup):
        return SupL(ctx, box, px, prev)
    if isinstance(box, Sub):
        return SubL(ctx, box, px)
    if isinstance(box, Frac):
        return FracL(ctx, box, px)
    if isinstance(box, NRoot):
        return SqrtL(ctx, box, px, index=box.index)
    if isinstance(box, Sqrt):
        return SqrtL(ctx, box, px)
    if isinstance(box, Abs):
        return DelimL(ctx, box.row, px, "|")
    if isinstance(box, Paren):
        return DelimL(ctx, box.row, px, box.kind)
    if isinstance(box, Matrix):
        return MatrixL(ctx, box, px)
    return LBox()


def layout(row, font_px=20, color=TEXT_COLOR, top=True, readonly=False, fonts=None) -> RowL:
    """Arma la caja de dibujo de una fila (top=True: una fila vacía no dibuja la cajita)."""
    return RowL(Ctx(color, readonly, fonts), _row(row), float(font_px), top=top)
