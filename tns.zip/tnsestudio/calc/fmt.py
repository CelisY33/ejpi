"""
fmt.py - Pasa los resultados del motor (SymPy) a filas 2D de mathview, según la configuración
(dígitos, formato exponencial, Real/Rectangular/Polar, ángulo, ⅈ o j).
"""
from __future__ import annotations

import math

import re

import sympy as sp

from . import units
from .engine import Done, Report, Settings, TIList
from .rows import Abs, Frac, Matrix, NRoot, Paren, Piecewise, Row, Sqrt, Sup

P_ADD, P_MUL, P_NEG, P_POW, P_ATOM = 1, 2, 2, 3, 4
NEG = "\u2011"      # signo negativo corto (como la TI); la resta usa "−"

FUNC_NAMES = {"re": "real", "im": "imag", "arg": "angle", "conjugate": "conj", "log": "ln",
              "asin": "sin⁻¹", "acos": "cos⁻¹", "atan": "tan⁻¹", "asec": "sec⁻¹", "acsc": "csc⁻¹",
              "acot": "cot⁻¹", "asinh": "sinh⁻¹", "acosh": "cosh⁻¹", "atanh": "tanh⁻¹",
              "factorial": "!", "floor": "floor", "ceiling": "ceiling", "sign": "sign",
              "Min": "min", "Max": "max", "binomial": "nCr", "FallingFactorial": "nPr"}


_DE_CONST = re.compile(r"[cn]\d+")


def _left_to_right(args):
    """x=-2 or x=2, x<-2 or x>2: de izquierda a derecha en la recta (como la TI)."""
    def key(a):
        try:
            rel = [r for r in ([a] if isinstance(a, sp.Rel) else list(a.atoms(sp.Rel)))]
            vals = [complex(sp.N(r.rhs)) for r in rel if r.rhs.is_number]
            vals = [(v.real, v.imag) for v in vals]
            return (0,) + min(vals) if vals else (1, 0.0, 0.0)
        except (TypeError, ValueError):
            return (1, 0.0, 0.0)
    try:
        return sorted(args, key=key)
    except TypeError:
        return list(args)


class Formatter:
    def __init__(self, settings: Settings, cplx: str = "", approx=False, unit_hint=None):
        self.s = settings
        self.cplx = cplx or settings.cplx
        self.approx = approx
        self.unit_hint = unit_hint          # "VA" o "var": lo que se escribió (tienen las mismas dimensiones que W)

    # ------------------------------------------------ entrada principal
    def lines(self, value, unit_tokens=None) -> list[Row]:
        value = self._deg_view(value)
        if self.approx:
            value = self._exp_view(value)
        if isinstance(value, Done):
            return [Row(["Hecho"])]
        if isinstance(value, str):
            return [Row(list(value) if getattr(value, "num", None) is not None else ['"' + value + '"'])]
        if isinstance(value, Report):
            out = []
            for name, v in value:
                r = Row(list(name))
                r.extend(["="])
                r.extend(self.value_row(v))
                out.append(r)
            return out
        if self.approx and isinstance(value, sp.Basic) and value.is_Integer and value == 0:
            value = sp.Float(0)                      # la TI muestra 0. en modo aproximado
        if unit_tokens:
            r = self.row(self._unit_dec(value), P_MUL)
            r.append("·")
            r.extend(self.unit_row(unit_tokens))
            return [r]
        return [self.value_row(value)]

    _TRIG = None

    def _deg_view(self, v):
        """En Grado/Gradián, sin(π·x/180) se muestra sin(x) y 180·sin⁻¹(x)/π como sin⁻¹(x) (como la TI)."""
        if self.s.angle not in ("Grado", "Gradián"):
            return v
        if isinstance(v, (TIList,)):
            return TIList(self._deg_view(x) for x in v)
        if isinstance(v, Report):
            return Report((k, self._deg_view(x)) for k, x in v)
        if isinstance(v, sp.MatrixBase):
            return v.applyfunc(self._deg_view)
        if not isinstance(v, sp.Basic) or not v.has(sp.sin, sp.cos, sp.tan, sp.sec, sp.csc, sp.cot,
                                                    sp.asin, sp.acos, sp.atan, sp.asec, sp.acsc, sp.acot):
            return v
        if self.cplx == "Polar" and v.is_number and v.has(sp.I):
            return v                                 # 80∠-110: complex_row saca módulo y ángulo
        k = sp.pi / (180 if self.s.angle == "Grado" else 200)
        trig = (sp.sin, sp.cos, sp.tan, sp.sec, sp.csc, sp.cot)
        inv = {sp.asin: "sin⁻¹", sp.acos: "cos⁻¹", sp.atan: "tan⁻¹", sp.asec: "sec⁻¹", sp.acsc: "csc⁻¹",
               sp.acot: "cot⁻¹"}

        def clean(u):
            u = sp.expand(u)
            if u.is_number:
                u = sp.N(u, 15)
            return u.xreplace({f: sp.Integer(round(float(f))) for f in u.atoms(sp.Float)
                               if abs(float(f) - round(float(f))) < 1e-9})

        def t_fix(t):
            if t.args[0].is_number and not self.approx:
                u = sp.simplify(t.args[0] / k)     # cos(π) en Grado sigue siendo cos(π) (no cos(π²/180))
                return sp.Function(t.func.__name__)(u)
            u = clean(t.args[0] / k)
            if u.has(sp.pi) and self.approx:      # cos(2·t) de deSolve -> cos(114.592·t), como la TI
                u = u.xreplace({sp.pi: sp.Float(sp.pi.evalf(15))})
                u = sp.expand(u).evalf(15)
            return sp.Function(t.func.__name__)(u)
        try:
            v = v.replace(lambda t: isinstance(t, trig) and (not t.args[0].is_number or not self.approx), t_fix)

            def i_fix(t):
                fs = [a for a in t.args if type(a) in inv]
                if len(fs) != 1:
                    return t
                f = fs[0]
                rest = clean(t / f * k)
                if rest.has(sp.pi):
                    return t
                return rest * sp.Function(inv[type(f)])(*f.args)
            v = v.replace(lambda t: isinstance(t, sp.Mul) and any(type(a) in inv for a in t.args), i_fix)
        except Exception:  # noqa: BLE001
            pass
        return v

    def _exp_view(self, v):
        """Modo aproximado como la TI: ℯ^(-2·t) -> (0.135335)^t, ℯ^(x+1) -> 2.71828·(2.71828)^x."""
        if isinstance(v, TIList):
            return TIList(self._exp_view(x) for x in v)
        if isinstance(v, Report):
            return Report((k, self._exp_view(x)) for k, x in v)
        if isinstance(v, sp.MatrixBase):
            return v.applyfunc(self._exp_view)
        if not isinstance(v, sp.Basic) or not v.has(sp.exp):
            return v

        def conv(ex):
            try:
                arg = sp.expand(ex.args[0])
                if arg.has(sp.I) or not arg.free_symbols or units.has_units(arg):
                    return ex
                const = sp.Integer(0)
                parts = []
                for term in sp.Add.make_args(arg):
                    c, m = term.as_coeff_Mul()
                    if m == 1:
                        const += c
                    elif c.is_real:
                        parts.append(sp.Pow(sp.Float(sp.exp(c).evalf(15), 15), m, evaluate=False))
                    else:
                        return ex
                if const != 0:
                    parts.insert(0, sp.Float(sp.exp(const).evalf(15), 15))
                return sp.Mul(*parts, evaluate=False) if len(parts) > 1 else parts[0]
            except Exception:  # noqa: BLE001
                return ex
        try:
            return v.replace(lambda e: isinstance(e, sp.exp), conv)
        except Exception:  # noqa: BLE001
            return v

    def value_row(self, v) -> Row:
        if isinstance(v, sp.Basic) and units.has_units(v) and not isinstance(v, (sp.Rel, sp.MatrixBase)):
            try:
                num, u = units.split(v)
            except units.UnitError:
                return self.row(v)
            mag = None
            try:
                if num.is_number:
                    mag = abs(complex(sp.N(num)))
            except (TypeError, ValueError):
                mag = None
            auto = getattr(self.s, "autoprefix", False) or self.s.expfmt == "Prefijo"
            fac, toks = units.best_unit(u, mag if auto else None, prefer=self.unit_hint)
            num = num / fac
            num = self._unit_dec(num, fac != 1)
            if self.approx:
                num = sp.N(num, 15)
            if toks and all(e < 0 for _, e in toks) and num.is_real and num.is_number:
                pos = [(n, -e) for n, e in toks]     # 1/(2·_m) y no 1/2·1/_m
                neg = num < 0
                a = abs(num)
                if isinstance(a, sp.Rational) and not a.is_Integer:
                    top, den = Row([str(a.p)]), Row([str(a.q), "·"])
                else:
                    top, den = self.row(a), Row()
                den.extend(self.unit_row(pos))
                return Row(([NEG] if neg else []) + [Frac(top, den)])
            r = self.row(num, P_MUL + 0.5 if num.has(sp.I) else P_MUL)
            r.append("·")
            r.extend(self.unit_row(toks))
            return r
        return self.row(v)

    def _unit_dec(self, num, scaled=True):
        """Con unidades, 503/100·_m se muestra 5.03·_m y 52752792631/50000000·_J como 1055.06·_J (TI)."""
        if (not self.approx and isinstance(num, sp.Rational) and not num.is_Integer
                and (scaled or num.q >= 10) and set(sp.factorint(num.q)) <= {2, 5}):
            return sp.Float(num, 15)
        return num

    def unit_row(self, toks) -> Row:
        """_m/_s como en la TI: las unidades con exponente negativo van abajo de una fracción."""
        def part(items):
            r = Row()
            for i, (n, e) in enumerate(items):
                if i:
                    r.append("·")
                r.append("_" + n)
                if e != 1:
                    r.append(Sup(Row([str(e)])))
            return r
        pos = [(n, e) for n, e in toks if e > 0]
        neg = [(n, -e) for n, e in toks if e < 0]
        if not neg:
            return part(pos)
        return Row([Frac(part(pos) if pos else Row(["1"]), part(neg))])

    # ------------------------------------------------ números
    def float_str(self, x: float) -> Row:
        d = self.s.digits
        if x == 0:
            return Row(["0." if self.approx else "0"])
        if math.isinf(x):
            return Row(["∞" if x > 0 else NEG + "∞"])
        if math.isnan(x):
            return Row(["undef"])
        neg = x < 0
        ax = abs(x)
        fixed = d.startswith("Fijo")
        nd = int(d[4:]) if fixed else (int(d[8:]) if d[8:] else 12)
        nd = max(nd, 1) if not fixed else nd
        ef = self.s.expfmt
        e10 = int(math.floor(math.log10(ax))) if ax > 0 else 0
        sci = ef in ("Científico", "Ingeniería")
        if not sci:
            if fixed:
                sci = ax >= 1e12 or (ax < 10 ** (-nd) / 2)
            else:                   # como la TI: 0.000123 (Flotante6 = 6 decimales) y 4.ᴇ-7 si se haría 0
                sci = e10 >= nd or float("%.*f" % (nd, ax)) == 0
        if sci:
            if ef == "Ingeniería":
                e10 = (e10 // 3) * 3
            m = ax / 10 ** e10
            if fixed:
                ms = "%.*f" % (nd, m)
                if float(ms) >= 10 and ef != "Ingeniería":
                    e10 += 1
                    ms = "%.*f" % (nd, ax / 10 ** e10)
                if "." not in ms:
                    ms += "."
            else:
                ms = self._sig(m, nd)
                if float(ms) >= 10 and ef != "Ingeniería":
                    e10 += 1
                    ms = self._sig(ax / 10 ** e10, nd)
            return Row([(NEG if neg else "") + ms + "ᴇ" + str(e10).replace("-", NEG)])
        if fixed:
            s = "%.*f" % (nd, ax)
            if "." not in s:
                s += "."                                 # Fijo0: 3. (como la TI)
        elif ax < 1:
            s = ("%.*f" % (nd, ax)).rstrip("0")
            if float(s) >= 1:
                s = "1."
        else:
            s = self._sig(ax, nd)
        return Row([(NEG if neg else "") + s])

    def big_float(self, x) -> Row:
        import mpmath
        d = self.s.digits
        nd = int(d[8:]) if d.startswith("Flotante") and d[8:] else (int(d[4:]) if d.startswith("Fijo") else 12)
        nd = max(nd, 1)
        v = mpmath.mpf(sp.Float(x, 30)._mpf_)
        if v == 0:
            return Row(["0."])
        neg = v < 0
        v = abs(v)
        e10 = int(mpmath.floor(mpmath.log10(v)))
        m = float(v / mpmath.power(10, e10))
        ms = self._sig(m, nd)
        if float(ms) >= 10:
            e10 += 1
            ms = self._sig(float(v / mpmath.power(10, e10)), nd)
        return Row([(NEG if neg else "") + ms + "ᴇ" + str(e10).replace("-", NEG)])

    @staticmethod
    def _sig(x, nd):
        s = "%.*g" % (nd, x)
        if "e" in s:
            s = "%.*f" % (max(0, nd - 1 - int(math.floor(math.log10(x)))), x)
        if "." in s:
            s = s.rstrip("0")
        else:
            s += "."
        return s

    def number(self, x) -> Row:
        """x: número real de SymPy."""
        if isinstance(x, sp.Float) or (self.approx and not x.is_Integer):
            fx = float(x)
            if fx != 0.0 and (math.isinf(fx) or abs(fx) < 1e-300) or (fx == 0.0 and x.is_nonzero):
                return self.big_float(x)            # fuera del rango de los float: 1.5ᴇ400, 7.59ᴇ-478
            return self.float_str(fx)
        if x.is_Integer:
            return Row([str(int(x))] if x >= 0 else [NEG + str(-int(x))])
        if x.is_Rational:
            r = Row()
            if x < 0:
                r.append(NEG)
            r.append(Frac(Row([str(abs(x.p))]), Row([str(x.q)])))
            return r
        return self.row(x)

    def complex_row(self, z) -> Row:
        """z: número complejo (no real)."""
        mode = self.cplx
        if mode == "Polar":
            if self.approx or z.atoms(sp.Float):
                c = complex(sp.N(z, 15))
                rr = abs(c)
                th = math.atan2(c.imag, c.real)
                th = float(self._from_rad(th))
                r = self.float_str(rr)
                r.append(" ∠ ")
                r.extend(self.float_str(th))
            else:
                c = complex(sp.N(z, 15))
                thn = math.atan2(c.imag, c.real) / (math.pi if self.s.angle == "Radián" else 1)
                thn = float(self._from_rad(thn)) if self.s.angle != "Radián" else thn
                from fractions import Fraction
                fr = Fraction(thn).limit_denominator(360)
                nice = abs(thn - fr) < 1e-9          # 30°, -110°, π/7… (si no, decimal directo sin simplificar)
                rr = sp.simplify(sp.Abs(z)) if nice else None
                th = sp.simplify(self._from_rad(sp.arg(z))) if nice else sp.Float(1.5)
                if not nice or not (th.is_Rational or (th / sp.pi).is_Rational):
                    # ángulo sin forma exacta: los dos en decimal, (180.003 ∠ 0.318307), no √32401 con 0.318307
                    c = complex(sp.N(z, 15))
                    r = self.float_str(abs(c))
                    r.append(" ∠ ")
                    r.extend(self.float_str(float(self._from_rad(math.atan2(c.imag, c.real)))))
                    return Row([Paren(r)])
                r = self.row(rr, P_POW)
                r.append(" ∠ ")
                r.extend(self.row(th, P_POW))
            return Row([Paren(r)])
        re_, im_ = sp.expand_complex(z).as_real_imag()
        if not (self.approx or z.atoms(sp.Float)):
            re_, im_ = sp.simplify(re_), sp.simplify(im_)
        if self.approx or z.atoms(sp.Float):
            re_, im_ = sp.N(re_, 15), sp.N(im_, 15)
        r = Row()
        if re_ != 0:
            r.extend(self.row(re_, P_ADD))
            neg = im_.could_extract_minus_sign() if not isinstance(im_, sp.Float) else im_ < 0
            r.append("−" if neg else "+")
            im_ = -im_ if neg else im_
        elif im_.could_extract_minus_sign():
            r.append(NEG)
            im_ = -im_
        if im_ != 1:
            r.extend(self.row(im_, P_MUL))
            if not self.approx:
                r.append("·")
        r.append(self.iu())
        return r

    def iu(self):
        return "j" if self.s.imag_j else "ⅈ"

    def _from_rad(self, x):
        a = self.s.angle
        if a == "Grado":
            return x * 180 / sp.pi
        if a == "Gradián":
            return x * 200 / sp.pi
        return x

    # ------------------------------------------------ expresiones
    def row(self, e, ctx=0) -> Row:
        """Fila para e; ctx = precedencia que necesita el padre (pone paréntesis si hace falta)."""
        r, prec = self._row(e)
        if prec < ctx:
            return Row([Paren(r)])
        return r

    def _row(self, e):
        if isinstance(e, Done):
            return Row(["Hecho"]), P_ATOM
        if isinstance(e, str):
            return Row(list(e) if getattr(e, "num", None) is not None else ['"' + e + '"']), P_ATOM
        if isinstance(e, TIList):
            r = Row(["{"])
            for i, x in enumerate(e):
                if i:
                    r.append(",")
                r.extend(self.value_row(x))
            r.append("}")
            return r, P_ATOM
        if isinstance(e, Report):
            r = Row()
            for i, (k, v) in enumerate(e):
                if i:
                    r.append(", ")
                r.extend(list(k))
                r.append("=")
                r.extend(self.value_row(v))
            return r, P_ATOM
        if isinstance(e, sp.MatrixBase):
            rows = [[self.value_row(e[i, j]) for j in range(e.cols)] for i in range(e.rows)]
            return Row([Matrix(rows)]), P_ATOM
        if isinstance(e, (int, float)):
            e = sp.sympify(e)
        if e is sp.true or e == sp.true:
            return Row(["true"]), P_ATOM
        if e is sp.false or e == sp.false:
            return Row(["false"]), P_ATOM
        if isinstance(e, sp.Piecewise):           # { x, x>0 ; -x, Else } como la TI
            rows = [[self.value_row(v), Row(list("Else")) if c is sp.true else self.value_row(c)]
                    for v, c in e.args]
            box = Piecewise()
            box.rows = rows
            return Row([box]), P_ATOM
        if isinstance(e, sp.Or):
            return self._join(_left_to_right(e.args), " or "), 0
        if isinstance(e, sp.And):
            return self._join(e.args, " and "), 0
        if isinstance(e, sp.Not):
            r = Row(["not "])
            r.extend(self.row(e.args[0], P_ATOM))
            return r, 0
        if isinstance(e, sp.Rel):
            op = {"==": "=", "!=": "≠", "<": "<", ">": ">", "<=": "≤", ">=": "≥"}[e.rel_op]
            r = self.value_row(e.lhs)
            r.append(op)
            r.extend(self.value_row(e.rhs))
            return r, 0
        if e is sp.nan:
            return Row(["undef"]), P_ATOM
        if e.is_number and not isinstance(e, sp.Symbol):
            try:
                is_c = e.has(sp.I) or (self.approx and sp.im(sp.N(e)) != 0)
            except (TypeError, ValueError):
                is_c = False
            if is_c:
                zz = sp.N(e, 15) if self.approx else e
                try:                                    # sin⁻¹(3+4ⅈ) sin forma a+bⅈ: se muestra tal cual
                    _parts = sp.expand_complex(zz).as_real_imag()
                    _rect = not any(p_.has(sp.re, sp.im) for p_ in _parts)
                except Exception:  # noqa: BLE001
                    _rect = False
                if _rect and sp.im(zz) != 0 and not zz.has(sp.Symbol):
                    r = self.complex_row(zz)
                    prec = P_ATOM if self.cplx == "Polar" else (P_ADD if sp.re(zz) != 0 else P_MUL)
                    if self.cplx == "Polar":
                        return r, P_ATOM
                    return r, prec
                if self.approx:
                    e = sp.re(zz)
        if e is sp.oo:
            return Row(["∞"]), P_ATOM
        if e is sp.S.NegativeInfinity:
            return Row([NEG + "∞"]), P_NEG
        if e is sp.zoo:
            return Row(["undef"]), P_ATOM
        if e.is_Number:
            r = self.number(e)
            neg = bool(r) and isinstance(r[0], str) and r[0].startswith(NEG)
            return r, (P_NEG if neg else (P_MUL if isinstance(r[-1], Sup) or any(isinstance(x, Frac) for x in r) else P_ATOM))
        if isinstance(e, sp.Symbol):
            n = e.name
            if n.startswith("_") or _DE_CONST.fullmatch(n):      # c1, c2… van en negrita (como la TI)
                return Row([n]), P_ATOM
            return Row(list(n) if len(n) <= 12 else [n]), P_ATOM
        if e is sp.pi:
            return Row(["π"]), P_ATOM
        if e is sp.E:
            return Row(["ℯ"]), P_ATOM
        if e is sp.I:
            return Row([self.iu()]), P_ATOM
        if e is sp.oo:
            return Row(["∞"]), P_ATOM
        if e is sp.zoo or e is sp.S.NegativeInfinity:
            return Row([NEG + "∞" if e is sp.S.NegativeInfinity else "undef"]), P_ATOM
        if isinstance(e, sp.Add):
            return self._add(e), P_ADD
        if isinstance(e, sp.Mul):
            return self._mul(e)
        if isinstance(e, sp.Pow):
            return self._pow(e)
        if isinstance(e, sp.Abs):
            return Row([Abs(self.row(e.args[0]))]), P_ATOM
        if isinstance(e, sp.exp):
            r = Row(["ℯ"])
            r.append(Sup(self.row(e.args[0])))
            return r, P_POW
        if isinstance(e, sp.factorial):
            r = self.row(e.args[0], P_ATOM)
            r.append("!")
            return r, P_POW
        if isinstance(e, sp.log) and len(e.args) == 1:
            return self._func("ln", e.args), P_ATOM
        if isinstance(e, sp.Function) or isinstance(e, sp.Expr) and e.args:
            name = getattr(e.func, "__name__", str(e.func))
            name = FUNC_NAMES.get(name, name)
            return self._func(name, e.args), P_ATOM
        return Row([str(e)]), P_ATOM

    def _func(self, name, args):
        r = Row([name])
        inner = Row()
        for i, a in enumerate(args):
            if i:
                inner.append(",")
            inner.extend(self.value_row(a))
        r.append(Paren(inner))
        return r

    def _join(self, args, sep):
        r = Row()
        for i, a in enumerate(args):
            if i:
                r.append(sep)
            r.extend(self.row(a, 0))
        return r

    def _add(self, e):
        try:
            terms = list(e.args) if all(t.is_number for t in e.args) else e.as_ordered_terms()
            # los términos con funciones (ln, sin, ℯ^…) van después de los polinomiales, como la TI
            # y las constantes al final (x+5, c1·(0.367879)^t+5.); entre funciones, por nombre (cos antes que sin)
            def nbase(t):           # (7.38906)^x antes que (0.135335)^x, como la TI
                bs = [float(p.base) for p in t.atoms(sp.Pow) if p.base.is_Float and not p.exp.is_number]
                return -max(bs) if bs else 0.0
            terms.sort(key=lambda t: (2, 0.0, "") if t.is_number else
                       ((1, nbase(t), ",".join(sorted(type(f).__name__ for f in t.atoms(sp.Function))))
                        if t.atoms(sp.Function) else (0, nbase(t), "1" if _DE_CONST.fullmatch(str(t)) else "")))
        except Exception:  # noqa: BLE001
            terms = list(e.args)
        r = Row()
        for i, t in enumerate(terms):
            neg = self._is_neg(t)
            if i == 0:
                if neg:
                    r.append(NEG)
                    r.extend(self.row(-t, P_MUL))
                else:
                    r.extend(self.row(t, P_ADD))
            else:
                r.append("−" if neg else "+")
                r.extend(self.row(-t if neg else t, P_MUL))
        return r

    @staticmethod
    def _is_neg(t):
        if t.is_Number:
            return t < 0 if t.is_real else False
        if isinstance(t, sp.Mul):
            c = t.args[0]
            return c.is_Number and c.is_real and c < 0
        return False

    def _mul(self, e):
        if self._is_neg(e):
            inner = self.row(-e, P_MUL)
            if len(inner) == 1 and isinstance(inner[0], Frac):     # −1./(x+c1): el signo va arriba
                inner[0].num.insert(0, NEG)
                return inner, P_MUL
            r = Row([NEG])
            r.extend(inner)
            return r, P_NEG
        coeff, rest = e.as_coeff_Mul()
        num_f, den_f = [], []
        for f in sp.Mul.make_args(rest):
            if isinstance(f, sp.Pow) and f.exp.is_Number and f.exp < 0:
                den_f.append(sp.Pow(f.base, -f.exp))
            else:
                num_f.append(f)
        if coeff != 1:
            if coeff.is_Rational and not coeff.is_Integer and not self.approx:
                if coeff.p != 1:
                    num_f.insert(0, sp.Integer(coeff.p))
                den_f.insert(0, sp.Integer(coeff.q))
            else:
                num_f.insert(0, coeff)
        if den_f:
            def prod(fs):
                if not fs:
                    return sp.Integer(1)
                return fs[0] if len(fs) == 1 else sp.Mul(*fs, evaluate=False)
            return Row([Frac(self.row(prod(num_f)), self.row(prod(den_f)))]), P_MUL
        # como la TI: número, luego lo demás, y al final las potencias con exponente simbólico
        def mkey(f):
            if f.is_Number:
                return 0
            if isinstance(f, (sp.Pow, sp.exp)) and not f.as_base_exp()[1].is_number:
                return 1.5 if f.as_base_exp()[0].is_Number else 2       # (0.367879)^t antes que cos(…)
            if isinstance(f, sp.Function) and not isinstance(f, sp.exp):
                return 1.7
            return 1
        if num_f and all(f.is_Integer or (isinstance(f, sp.Pow) and f.base.is_Integer and f.exp.is_Integer)
                         for f in num_f):
            num_f.sort(key=lambda f: int(f.base) if isinstance(f, sp.Pow) else int(f))   # factor(360) = 2³·3²·5
        else:
            num_f.sort(key=mkey)
            def _sym(f):                             # a, b², x… en orden alfabético: 3·a²·b (TI)
                b = f.base if isinstance(f, sp.Pow) else f
                return b.name.lower() if isinstance(b, sp.Symbol) else None
            pos = [i for i, f in enumerate(num_f) if _sym(f) is not None]
            for i, f in zip(pos, sorted((num_f[i] for i in pos), key=_sym)):
                num_f[i] = f
        r = Row()
        for i, f in enumerate(num_f):
            fr = self.row(f, P_MUL + 0.5 if not f.is_Number else P_MUL)
            if i:
                r.append("·")
            r.extend(fr)
        return r, P_MUL

    def _pow(self, e):
        b, x = e.args
        if x.is_Float and float(x) in (0.5, -0.5):                 # x^0.5 -> √x (como la TI)
            x = sp.Rational(1, 2) if float(x) > 0 else sp.Rational(-1, 2)
            if x < 0:
                return Row([Frac(Row(["1." if self.approx else "1"]), Row([Sqrt(self.row(b))]))]), P_MUL
        if x == sp.Rational(1, 2):
            return Row([Sqrt(self.row(b))]), P_ATOM
        if x.is_Rational and x.p == 1 and x.q > 2:
            return Row([NRoot(Row([str(x.q)]), self.row(b))]), P_ATOM
        if x.is_Number and x < 0 and (not self.approx or x.is_Integer):
            den = b if x == -1 else sp.Pow(b, -x, evaluate=False)
            return Row([Frac(Row(["1." if self.approx else "1"]), self.row(den))]), P_MUL
        if b is sp.E:
            r = Row(["ℯ"])
        elif b.is_Float and not x.is_number:
            r = Row([Paren(self.row(b))])                  # (0.135335)^t como la TI
        else:
            r = self.row(b, P_ATOM)
        r.append(Sup(self.row(x)))
        return r, P_POW


def format_result(res, settings: Settings) -> list[Row]:
    f = Formatter(settings, res.cplx, res.approx, getattr(res, "unit_hint", None))
    toks = res.extra if res.target is not None else None
    return f.lines(res.value, toks)


def approx_hint(res, settings: Settings):
    """En modo Auto, una segunda línea ≈ decimal cuando el resultado exacto no es entero."""
    v = res.value
    if res.approx or settings.mode != "Auto" or not isinstance(v, sp.Basic):
        return None
    try:
        if not v.is_number or v.is_Integer or v.has(sp.oo, sp.zoo, sp.nan):
            return None
        re_, im_ = sp.expand_complex(v).as_real_imag()
        if re_.is_Integer and im_.is_Integer:
            return None
    except Exception:  # noqa: BLE001
        return None
    f = Formatter(settings, res.cplx, True)
    r = Row(["≈"])
    r.extend(f.row(sp.N(v, 15)))
    return r


def plain_text(rows) -> str:
    from .rows import to_linear
    return "\n".join(to_linear(r) for r in rows)
