"""
engine.py - Motor de la calculadora de TNS Estudio (SymPy por debajo).

Lee texto lineal al estilo TI-Nspire y lo evalúa:
    a:=5            variables (también 5→a y Define)
    f(x):=x^2+1     funciones
    @i  ó  ⅈ        unidad imaginaria (i y j quedan libres como variables)
    230∠30          fasores (el ángulo en el modo actual: Grado / Radián / Gradián)
    2_km, 5_kV      unidades con guion bajo; conversión con ▸ (3_kWh▸_J)
    ▸Rect ▸Polar ▸Decimal
    solve(x^2=4,x), factor, expand, derivative, ∫, limit, Σ, matrices [[1,2][3,4]], listas {1,2}
    cuadripolo\\convert("z",…,"y"), delta2y(…), y2delta(…), par(…)
"""
from __future__ import annotations

import math
import re
import random
import unicodedata
from dataclasses import dataclass, field

import sympy as sp
from sympy.core.function import AppliedUndef

from . import elec, units
from .units import UnitError


class CalcError(Exception):
    pass


class SyntaxErr(CalcError):
    """Error de escritura (la TI muestra "Sintaxis" y deja la línea como estaba)."""


# ---------------------------------------------------------------- configuración
@dataclass
class Settings:
    digits: str = "Flotante6"       # Flotante, Flotante1..12, Fijo0..12
    angle: str = "Grado"            # Radián, Grado, Gradián
    expfmt: str = "Normal"          # Normal, Científico, Ingeniería
    cplx: str = "Polar"             # Real, Rectangular, Polar
    mode: str = "Aproximado"        # Auto, Exacto, Aproximado
    vector: str = "Rectangular"
    base: str = "Decimal"
    unitsys: str = "SI"
    imag_j: bool = False            # mostrar la unidad imaginaria como j
    autoprefix: bool = False        # 2300_W -> 2.3_kW (la TI no lo hace: queda en la unidad del SI)

    def short(self) -> str:
        a = {"Radián": "RAD", "Grado": "GRA", "Gradián": "GRD"}.get(self.angle, self.angle)
        return "%s · %s · %s · %s%s" % (a, self.cplx, self.mode, self.digits,
                                        " · Prefijo" if self.expfmt == "Prefijo" else "")


class TIList(list):
    """Lista de la TI: {1,2,3}."""


class Report(list):
    """Resultado de varias líneas con nombre: [(nombre, valor), …]."""


class DMSText(str):
    """Resultado de ▸DMS: 45°30'0\" (texto sin comillas; num = el valor en grados)."""
    num = None

    @classmethod
    def of(cls, x):
        try:
            f = float(sp.N(x, 20))
        except (TypeError, ValueError):
            raise CalcError("▸DMS necesita un número")
        if not math.isfinite(f):
            raise CalcError("▸DMS necesita un número finito")
        sg = "-" if f < 0 else ""
        f = abs(f)
        d = int(f)
        m_ = int((f - d) * 60)
        sec = round(((f - d) * 60 - m_) * 60, 4)
        if sec >= 60:
            sec -= 60
            m_ += 1
        if m_ >= 60:
            m_ -= 60
            d += 1
        ss = ("%.4f" % sec).rstrip("0").rstrip(".")
        out = cls('%s%d°%d\'%s"' % (sg, d, m_, ss))
        out.num = x
        return out


class BaseText(str):
    """Resultado de ▸Base2 / ▸Base16: 0b1010, 0hFF (texto sin comillas)."""
    num = None

    @classmethod
    def of(cls, x, base):
        x = sp.sympify(x)
        if not x.is_number:
            raise CalcError("▸Base%d necesita un número" % base)
        k = int(sp.floor(sp.re(x) + sp.Rational(1, 2))) if not x.is_Integer else int(x)
        if base == 10:
            t = str(k)
        else:
            if k < 0:
                k &= (1 << 64) - 1                    # complemento a 2 de 64 bits, como la TI
            t = ("0b" + format(k, "b")) if base == 2 else ("0h" + format(k, "X"))
        out = cls(t)
        out.num = sp.Integer(k)
        return out


class Done:
    """'Hecho' (Define, DelVar…)."""


DONE = Done()


@dataclass
class Result:
    text: str
    value: object
    approx: bool = False
    note: str = ""
    target: object = None           # (factor, tokens) si se pidió ▸unidad
    cplx: str = ""                  # forzado por ▸Rect / ▸Polar
    is_def: bool = False
    extra: list = field(default_factory=list)
    temp: tuple = (None, None)      # (unidad de origen, de destino) si es una temperatura
    unit_hint: object = None        # VA / var: cómo mostrar potencias (mismas dimensiones que W)


# ---------------------------------------------------------------- lectura
SPECIAL = {"π": sp.pi, "ℯ": sp.E, "ⅈ": sp.I, "∞": sp.oo, "?": sp.Symbol("?")}
OPS1 = set("+-*/^()[]{},;=≠<>≤≥→▸∠°!|ᵀ%√∫ΣΠ'&ʳᵍ″")
UNIT_CHARS = set("µμΩÅ°")

_REPL = [("ΣInt(", "sigmaint("), ("ΣPrn(", "sigmaprn("), ("\u2011", "-"), ("@E", "ᴇ"), ("@t", "ᵀ"), ("@d", "°"), ("′", "'"), ("=:", "→"), ("@i", "ⅈ"), ("@<", "∠"), ("@>", "▸"), ("@e", "ℯ"), ("->", "→"), (">=", "≥"), ("<=", "≤"),
         ("/=", "≠"), ("<>", "≠"), ("−", "-"), ("·", "*"), ("×", "*"), ("÷", "/"), ("**", "^"),
         ("²", "^2"), ("³", "^3"), ("√", "√"), (" ", " "), (" ", " ")]
for _f in ("sin", "cos", "tan", "sec", "csc", "cot", "sinh", "cosh", "tanh"):
    _REPL.insert(0, (_f + "⁻¹", "a" + _f))
_REPL.append(("⁻¹", "^(-1)"))


def _ddx(s):
    """d/dx(expr) escrito en una línea -> derivative(expr,x)."""
    for _ in range(20):
        m = re.search(r"(?<![A-Za-z0-9_])d/d([A-Za-z])\(", s)
        if not m:
            return s
        i = m.end()
        d = 1
        j = i
        while j < len(s) and d:
            d += {"(": 1, ")": -1}.get(s[j], 0)
            j += 1
        if d:
            return s
        s = s[:m.start()] + "derivative(" + s[i:j - 1] + "," + m.group(1) + ")" + s[j:]
    return s


def preprocess(s: str) -> str:
    for a, b in _REPL:
        s = s.replace(a, b)
    s = _ddx(s)
    s = re.sub(r"(?i)list▸mat\(", "listtomat(", s)
    s = re.sub(r"(?i)mat▸list\(", "mattolist(", s)
    return s


STAT_CMDS = {"onevar", "twovar", "linregmx", "linregbx", "quadreg", "cubicreg", "quartreg", "powerreg",
             "expreg", "lnreg", "medmed", "sinreg", "multreg", "logistic", "logisticd"}


def _stat_key(nm):
    t = unicodedata.normalize("NFC", nm).lower()
    for a, b in (("₁", "1"), ("₃", "3"), ("²", "2"), ("x̄", "xbar"), ("ȳ", "ybar"), ("ӯ", "ybar"), ("y\u0304", "ybar")):
        t = t.replace(a, b)
    return t


def tokenize(text: str):
    s = preprocess(text)
    n = len(s)
    i = 0
    out = []
    while i < n:
        c = s[i]
        if c.isspace():
            i += 1
            continue
        if c == "0" and i + 2 < n and s[i + 1] in "bBhH":          # 0b1010, 0hFF (TI)
            dig = "01" if s[i + 1] in "bB" else "0123456789abcdefABCDEF"
            j = i + 2
            while j < n and s[j] in dig:
                j += 1
            if j > i + 2 and not (j < n and (s[j].isalnum() or s[j] == "_")):
                out.append(("num", str(int(s[i + 2:j], 2 if s[i + 1] in "bB" else 16))))
                i = j
                continue
        if c.isdigit() or (c == "." and i + 1 < n and s[i + 1].isdigit()):
            j = i
            while j < n and s[j].isdigit():
                j += 1
            if j < n and s[j] == ".":
                j += 1
                while j < n and s[j].isdigit():
                    j += 1
            if j < n and s[j] in "Eᴇ":
                k = j + 1
                if k < n and s[k] in "-+":
                    k += 1
                if k < n and s[k].isdigit():
                    while k < n and s[k].isdigit():
                        k += 1
                    j = k
            out.append(("num", s[i:j].replace("ᴇ", "E")))
            i = j
            continue
        if c == "_":
            j = i + 1
            while j < n and (((s[j].isalnum() or s[j] in UNIT_CHARS) and s[j] not in SPECIAL) or
                             (s[j] == "'" and s[i + 1:j] in units.PREFIXES and "'" not in s[i + 1:j]
                              and j + 1 < n and (s[j + 1].isalpha() or s[j + 1] in "Ωµμ"))):
                j += 1
            if j == i + 1:
                raise SyntaxErr("Falta el nombre de la unidad después de _")
            out.append(("unit", s[i + 1:j]))
            i = j
            continue
        if c == '"' and out and out[-1][0] == "num" and (
                (len(out) > 1 and out[-2] in (("op", "'"), ("op", "°"))) or s.find('"', i + 1) < 0):
            out.append(("op", "″"))                      # segundos: 30°15'30"
            i += 1
            continue
        if c == '"':
            j = s.find('"', i + 1)
            if j < 0:
                raise SyntaxErr("Falta cerrar las comillas")
            out.append(("str", s[i + 1:j]))
            i = j + 1
            continue
        if c in "ʳᵍ":
            out.append(("op", c))
            i += 1
            continue
        if c in "ΣΠ∏∑":
            out.append(("op", {"∏": "Π", "∑": "Σ"}.get(c, c)))
            i += 1
            continue
        if c in SPECIAL:
            out.append(("const", c))
            i += 1
            continue
        if c == "ᵀ":
            out.append(("op", "ᵀ"))
            i += 1
            continue
        if c.isalpha():
            j = i
            while j < n and (s[j].isalnum() or s[j] == "_") and s[j] not in SPECIAL and s[j] != "ᵀ":
                j += 1
            name = s[i:j]
            if name.lower() == "stat" and j + 1 < n and s[j] == "." and (s[j + 1].isalpha() or s[j + 1] in "Σ"):
                k = j + 1                                 # stat.r, stat.x̄, stat.Σx², stat.Q₁X…
                while k < n and (s[k].isalnum() or s[k] in "²³₁₃\u0304" or unicodedata.category(s[k])[0] == "M"):
                    k += 1
                out.append(("id", s[i:k]))
                i = k
                continue
            if j < n and s[j] == "\\" and j + 1 < n and s[j + 1].isalpha():
                k = j + 1
                while k < n and (s[k].isalnum() or s[k] == "_"):
                    k += 1
                name = s[i:k]
                j = k
            out.append(("id", name))
            i = j
            continue
        if s.startswith(":=", i):
            out.append(("op", ":="))
            i += 2
            continue
        if c == "." and i + 1 < n and s[i + 1] in "+-*/^":
            out.append(("op", "." + s[i + 1]))
            i += 2
            continue
        if c in OPS1:
            out.append(("op", c))
            i += 1
            continue
        raise SyntaxErr("No entiendo el carácter «%s»" % c)
    out.append(("end", ""))
    return out


KEYWORDS = {"and", "or", "xor", "not"}


# ---------------------------------------------------------------- ayudas
def _is_list(x):
    return isinstance(x, TIList)


def bcast(f, a, b):
    if _is_list(a) and _is_list(b):
        if len(a) != len(b):
            raise CalcError("Las listas tienen distinto largo")
        return TIList(f(x, y) for x, y in zip(a, b))
    if _is_list(a):
        return TIList(f(x, b) for x in a)
    if _is_list(b):
        return TIList(f(a, y) for y in b)
    return f(a, b)


def bmap(f, a):
    if _is_list(a):
        return TIList(f(x) for x in a)
    if isinstance(a, sp.MatrixBase):
        return a.applyfunc(f)
    return f(a)


def _num(x):
    if isinstance(x, str):
        raise CalcError("Se esperaba un número y llegó el texto \"%s\"" % x)
    if isinstance(x, Report):
        raise CalcError("Ese resultado tiene varias partes; usa una sola")
    return x


def _int(x, what="un entero"):
    x = sp.sympify(x)
    if not x.is_integer:
        try:
            if x.is_number and float(x) == int(float(x)):
                return int(float(x))
        except (TypeError, ValueError):
            pass
        raise CalcError("Se esperaba %s" % what)
    return int(x)


def _float(x):
    try:
        return float(sp.N(x))
    except (TypeError, ValueError):
        raise CalcError("Se esperaba un valor numérico")


def has_float(v) -> bool:
    if isinstance(v, (TIList, Report)):
        return any(has_float(x[1] if isinstance(v, Report) else x) for x in v)
    if isinstance(v, sp.MatrixBase):
        return any(has_float(x) for x in v)
    if isinstance(v, sp.Basic):
        return bool(v.atoms(sp.Float))
    return False


def _chop_rel(xs):
    """En una lista o matriz, lo que es 1ᴇ-13 veces el más grande es ruido: 3.78ᴇ-124∠… -> 0."""
    try:
        mags = [abs(complex(x)) for x in xs if isinstance(x, sp.Basic) and x.is_number]
        top = max(mags) if mags else 0.0
        if top == 0:
            return list(xs)
        out = []
        for x in xs:
            if isinstance(x, sp.Basic) and x.is_number and x.atoms(sp.Float) and abs(complex(x)) < 1e-12 * top:
                out.append(sp.Float(0))
            else:
                out.append(x)
        return out
    except (TypeError, ValueError, OverflowError):
        return list(xs)


def approx(v, n=15):
    if isinstance(v, TIList):
        return TIList(_chop_rel([approx(x, n) for x in v]))
    if isinstance(v, Report):
        return Report((k, approx(x, n)) for k, x in v)
    if isinstance(v, sp.MatrixBase):
        m = v.applyfunc(lambda x: approx(x, n))
        return sp.ImmutableMatrix(m.rows, m.cols, _chop_rel(list(m)))
    if isinstance(v, (sp.And, sp.Or, sp.Not)):
        return v.func(*[approx(a, n) for a in v.args])
    if isinstance(v, sp.Rel):                 # x=… : se aproxima cada lado (y se limpian los restos 0.e-22ⅈ)
        try:
            return v.func(approx(v.lhs, n), approx(v.rhs, n), evaluate=False)
        except Exception:  # noqa: BLE001
            pass
    if isinstance(v, sp.Basic):
        try:
            return int_exponents(_chop(v.evalf(n)))
        except Exception:  # noqa: BLE001
            return v
    return v


def _chop(v):
    """Restos numéricos: 1.+0.e-22ⅈ -> 1., 3.03ᴇ-21 de ángulo -> 0 (la TI no los muestra)."""
    try:
        if v.is_number:
            re_, im_ = v.as_real_imag()
            mag = abs(complex(v)) if (re_ != 0 or im_ != 0) else 0.0
            if mag == 0:
                return sp.Float(0)
            tol = 1e-13 * mag
            re2 = sp.Float(0) if abs(float(re_)) < tol else re_
            im2 = sp.Float(0) if abs(float(im_)) < tol else im_
            if re2 is not re_ or im2 is not im_:
                return re2 + sp.I * im2 if float(im2) != 0.0 else re2
        return v
    except (TypeError, ValueError, OverflowError):
        return v


def _intify(e):
    """Floats enteros (3.0) -> enteros (3), dentro de un exponente."""
    if isinstance(e, sp.Float):
        return sp.Integer(int(e)) if float(e).is_integer() else e
    if not isinstance(e, sp.Basic) or e.is_Atom:
        return e
    return e.func(*[_intify(a) for a in e.args])


def int_exponents(e):
    """Como la TI en modo aproximado: x² y y^(-3·x) quedan con exponentes exactos."""
    if not isinstance(e, sp.Basic) or e.is_Atom or not e.atoms(sp.Float):
        return e
    args = [int_exponents(a) for a in e.args]
    if isinstance(e, sp.Pow):
        return sp.Pow(args[0], _intify(args[1]))
    try:
        return e.func(*args)
    except Exception:  # noqa: BLE001
        return e


def tidy_calc(e):
    """Resultados de derivadas/integrales: agrupa el factor común con exponente simbólico,
    como hace la TI: (40·x−60·x²·ln(y))·y^(-3·x)."""
    try:
        if not isinstance(e, sp.Expr) or not isinstance(e, sp.Add):
            return e
        pw = [t for t in sp.expand(e).atoms(sp.Pow, sp.exp) if not t.as_base_exp()[1].is_number]
        if not pw:
            return e
        c = sp.collect(sp.expand(e), pw)
        return c if sp.count_ops(c) <= sp.count_ops(e) else e
    except Exception:  # noqa: BLE001
        return e


def to_exact(v):
    if isinstance(v, TIList):
        return TIList(to_exact(x) for x in v)
    if isinstance(v, Report):
        return Report((k, to_exact(x)) for k, x in v)
    if isinstance(v, sp.MatrixBase):
        return v.applyfunc(to_exact)
    if isinstance(v, sp.Basic) and v.atoms(sp.Float):
        return sp.nsimplify(v, rational=True)
    return v


def tidy(v):
    """Ordena los números complejos exactos: (1+ⅈ)^2 -> 2ⅈ."""
    if isinstance(v, TIList):
        return TIList(tidy(x) for x in v)
    if isinstance(v, Report):
        return Report((k, tidy(x)) for k, x in v)
    if isinstance(v, sp.MatrixBase):
        return v.applyfunc(tidy)
    if isinstance(v, (sp.And, sp.Or)):
        return v.func(*[tidy(a) for a in v.args])
    if isinstance(v, sp.Equality):
        return sp.Eq(v.lhs, tidy(v.rhs), evaluate=False)
    if isinstance(v, sp.Expr) and (v.has(sp.I) or (v.is_number and any(
            p.base == -1 and p.exp.is_Rational for p in v.atoms(sp.Pow)))):
        try:                                       # (-8)^(1/3) = 2·(-1)^(1/3) -> 1+√3·ⅈ
            if v.is_number or units.has_units(v):
                w = sp.expand_complex(v)
                if not w.atoms(sp.Float):
                    if w.is_number:                  # parte real e imaginaria por separado (sin √(negativo))
                        re_, im_ = w.as_real_imag()
                        w2 = sp.simplify(re_) + sp.simplify(im_) * sp.I
                        w = w2 if not any(p.base.is_negative for p in w2.atoms(sp.Pow)
                                          if p.base.is_number) else w
                    else:
                        w = sp.simplify(w)
                return w
        except Exception:  # noqa: BLE001
            return v
    return v


def _auto_simp(v):
    if isinstance(v, TIList):
        return TIList(_auto_simp(x) for x in v)
    if isinstance(v, sp.MatrixBase):
        return v.applyfunc(_auto_simp)
    if not isinstance(v, sp.Expr) or not v.free_symbols or units.has_units(v):
        return v
    try:
        w = v
        if any(p.exp.is_Integer and p.exp < 0 and p.base.is_Add for p in w.atoms(sp.Pow)):
            c = sp.cancel(w)
            if sp.count_ops(c) < sp.count_ops(w) and (not w.is_Add or sp.fraction(c)[1] == 1):
                w = sp.factor_terms(c)
        if w.has(sp.I) and sp.count_ops(w) < 2000:
            # constantes complejas exactas dentro de expresiones con variables (componentes simétricas):
            # ℯ^(2πⅈ/3) -> -1/2+√3/2ⅈ, y luego se racionaliza: zm·(9/2+3√3/2ⅈ)/(27/2+9√3/2ⅈ) = zm/3
            reps = {}
            for a_ in w.atoms(sp.exp, sp.Pow):
                if not a_.is_number:
                    continue
                if isinstance(a_, sp.exp) and a_.args[0].has(sp.I) and (a_.args[0] / (sp.I * sp.pi)).is_Rational \
                        or isinstance(a_, sp.Pow) and a_.base == -1 and a_.exp.is_Rational:
                    c = sp.expand_complex(a_)
                    if not c.has(sp.cos, sp.sin):
                        reps[a_] = c
            w2 = w.xreplace(reps) if reps else w
            if any(p.exp.is_negative and p.base.is_Add and p.base.is_number for p in w2.atoms(sp.Pow)):
                w2 = sp.radsimp(w2)
            syms = sorted(w2.free_symbols, key=str)
            c = sp.collect(sp.expand(w2), syms) if all(w2.is_polynomial(x) for x in syms) else \
                (sp.expand(w2) if w2 is not w else w)
            if sp.count_ops(c) < sp.count_ops(w):
                w = c
        trig = w.atoms(sp.sin, sp.cos)
        if any(isinstance(f.args[0], sp.Add) and f.args[0].has(sp.pi) and f.args[0].free_symbols for f in trig) \
                and sp.count_ops(w) < 300:
            # cos(θ-2π/3) y compañía (Park, fasores espaciales): se expanden y se juntan, como la TI
            w2 = w.xreplace({e: sp.expand_complex(e) for e in w.atoms(sp.exp) if e.is_number})
            c1 = sp.expand(sp.expand_trig(w2))
            best = min([w, c1, sp.trigsimp(c1)], key=sp.count_ops)
            w = best
        trig = w.atoms(sp.sin, sp.cos)
        if trig and sp.count_ops(w) < 150 and any(isinstance(t, sp.Mul) and len(t.atoms(sp.sin, sp.cos)) >= 1
                                                  for t in sp.preorder_traversal(w)) \
                and {f.args[0] for f in trig if isinstance(f, sp.sin)} & {f.args[0] for f in trig if isinstance(f, sp.cos)}:
            c = sp.trigsimp(sp.expand(w))            # v·(2v·cos t−v·sin t−2)·cos t+… = 2v²−2v·cos t

            def ntrig(z):
                return sum(1 for t in sp.preorder_traversal(z) if isinstance(t, (sp.sin, sp.cos)))
            if ntrig(c) < ntrig(w) and sp.count_ops(c) < sp.count_ops(w):
                w = c
        sq = [p for p in w.atoms(sp.Pow) if p.exp == 2 and isinstance(p.base, (sp.sin, sp.cos))]
        if any(isinstance(p.base, sp.sin) for p in sq) and any(isinstance(p.base, sp.cos) for p in sq):
            c = sp.trigsimp(w)
            if sp.count_ops(c) < sp.count_ops(w):
                w = c
        return w
    except Exception:  # noqa: BLE001
        return v


def _assume(v, rels):
    """expr | x>0: se simplifica suponiendo el signo (√(x²)|x>0 = x)."""
    rep = {}
    for c in rels:
        c = c.reversed if (isinstance(c, sp.Rel) and c.rhs.is_Symbol and not c.lhs.is_Symbol) else c
        if not (isinstance(c, sp.Rel) and c.lhs.is_Symbol and c.rhs.is_number):
            continue
        x, b = c.lhs, c.rhs
        try:
            if isinstance(c, (sp.StrictGreaterThan, sp.GreaterThan)) and b >= 0:
                rep[x] = sp.Dummy(x.name, positive=True)
            elif isinstance(c, (sp.StrictLessThan, sp.LessThan)) and b <= 0:
                rep[x] = sp.Dummy(x.name, negative=True)
        except TypeError:
            continue
    if not rep:
        return v
    back = {d: x for x, d in rep.items()}
    try:
        return sp.simplify(sp.sympify(v).xreplace(rep)).xreplace(back)
    except Exception:  # noqa: BLE001
        return v


def _real_view(v):
    if isinstance(v, TIList):
        return TIList(_real_view(x) for x in v)
    if isinstance(v, sp.MatrixBase):
        return v.applyfunc(_real_view)
    if not isinstance(v, sp.Basic) or isinstance(v, sp.Rel) and False:
        return v
    try:
        syms = [x for x in v.free_symbols if isinstance(x, sp.Symbol) and not x.name.startswith("_")
                and x.is_real is None]
        if not syms or not v.has(sp.log, sp.Pow):
            return v
        if not (v.has(sp.log) or any(not p.exp.is_Integer for p in v.atoms(sp.Pow))):
            return v
        rv = {x: sp.Dummy(x.name, real=True) for x in syms}
        back = {b: a for a, b in rv.items()}
        w = v.xreplace(rv)
        w = w.replace(lambda t: isinstance(t, sp.log) and isinstance(t.args[0], sp.exp), lambda t: t.args[0].args[0])
        w = w.replace(lambda t: (isinstance(t, sp.Pow) and isinstance(t.base, sp.Pow) and t.base.exp.is_Integer
                                 and t.base.exp % 2 == 1 and t.exp * t.base.exp == 1),
                      lambda t: t.base.base)          # (x³)^(1/3) = x
        return w.xreplace(back)
    except Exception:  # noqa: BLE001
        return v


def has_imag(v) -> bool:
    if isinstance(v, (TIList,)):
        return any(has_imag(x) for x in v)
    if isinstance(v, Report):
        return any(has_imag(x) for _, x in v)
    if isinstance(v, sp.MatrixBase):
        return any(has_imag(x) for x in v)
    if isinstance(v, sp.Basic):
        return v.has(sp.I)
    return False


# ---------------------------------------------------------------- motor
class Engine:
    def __init__(self, settings: Settings | None = None):
        self.settings = settings or Settings()
        self.vars: dict[str, object] = {}         # nombre en minúsculas -> valor
        self.funcs: dict[str, tuple] = {}         # nombre -> (parámetros, cuerpo)
        self.names: dict[str, str] = {}           # minúsculas -> como se escribió
        self.symbols: dict[str, sp.Symbol] = {}
        self.ans = sp.Integer(0)
        self.de_n = 0                              # constantes c1, c2… de deSolve (como la TI)
        self.progs: dict = {}                      # Func/Prgm definidos con Define … Func … EndFunc
        self.var_hints: dict = {}                  # variable -> "VA"/"var"/"W" (cómo mostrar potencias)
        self.disp_out: list = []                   # lo que mostró Disp
        self._fn = build_functions(self)

    # ---- símbolos y variables
    def symbol(self, name):
        k = name.lower()
        if k not in self.symbols:
            self.names.setdefault(k, name)
            self.symbols[k] = sp.Symbol(self.names[k])
        return self.symbols[k]

    def is_function(self, name):
        k = name.lower()
        return k in self.funcs or k in self._fn or k in self.progs

    def lookup(self, name):
        k = name.lower()
        if k == "ans":
            return self.ans
        if k in self.vars:
            return self.vars[k]
        if k in ("pi",):
            return sp.pi
        if k == "true":
            return sp.true
        if k == "false":
            return sp.false
        if k == "undef":
            return sp.nan
        if k in self._fn:
            raise CalcError("%s es una función: escribe %s(…)" % (name, name))
        return self.symbol(name)

    def stat_var(self, name):
        """stat.r, stat.x̄, stat.RegEqn… de la última estadística (OneVar, LinRegMx…)."""
        rep = getattr(self, "last_stat", None)
        want = _stat_key(name[5:])
        if rep:
            for nm, v in rep:
                if _stat_key(nm) == want:
                    return v
        if rep is None:
            raise CalcError("Todavía no hay resultados estadísticos (usa OneVar, LinRegMx…)")
        raise CalcError("La última estadística no tiene %s" % name)

    def store(self, name, value):
        k = name.lower()
        if k in self._fn or k in ("ans", "pi", "true", "false"):
            raise CalcError("%s es un nombre reservado" % name)
        self.names[k] = name
        self.funcs.pop(k, None)
        self.vars[k] = value

    def delete(self, name):
        k = name.lower()
        self.vars.pop(k, None)
        self.funcs.pop(k, None)
        self.progs.pop(k, None)

    def clear_az(self):
        for k in [k for k in self.vars if len(k) == 1 and "a" <= k <= "z"]:
            del self.vars[k]

    def user_names(self):
        return sorted([self.names.get(k, k) for k in self.vars]
                      + ["%s(%s)" % (p.name, ",".join(p.params)) for p in self.progs.values()]
                      + ["%s(%s)" % (self.names.get(k, k), ",".join(str(p) for p in v[0]))
                         for k, v in self.funcs.items()], key=str.lower)

    # ---- ángulos
    def to_rad(self, x):
        a = self.settings.angle
        if a == "Grado":
            return x * sp.pi / 180
        if a == "Gradián":
            return x * sp.pi / 200
        return x

    def from_rad(self, x):
        a = self.settings.angle
        if a == "Grado":
            return x * 180 / sp.pi
        if a == "Gradián":
            return x * 200 / sp.pi
        return x

    def degrees(self, x):
        """30° -> en las unidades del modo actual."""
        a = self.settings.angle
        if a == "Grado":
            return x
        if a == "Gradián":
            return x * sp.Rational(200, 180)
        return x * sp.pi / 180

    def polar(self, r, th):
        t = self.to_rad(th)
        return sp.expand(r * (sp.cos(t) + sp.I * sp.sin(t)))

    # ---- evaluar
    def evaluate(self, text: str, force_approx=False) -> Result:
        m = re.match(r"^\s*define\s+([^\s(=]+)\s*\(([^)]*)\)\s*=(.*)$", text, re.I | re.S)
        if m and not re.match(r"\s*(func|prgm)\b", m.group(3), re.I):
            try:
                return self._evaluate(text, force_approx)
            except CalcError as ex:
                if "índice" not in str(ex):
                    raise
            # Define g(k)=m[k,1]: el índice depende del parámetro -> se calcula al llamar (como un Func)
            return self._evaluate("Define %s(%s)=Func:Return %s:EndFunc" % (m.group(1), m.group(2), m.group(3)),
                                  force_approx)
        return self._evaluate(text, force_approx)

    def _evaluate(self, text: str, force_approx=False) -> Result:
        if not text.strip():
            raise CalcError("Escribe algo para calcular")
        from . import program
        if re.match(r"^\s*define\b.*=\s*(func|prgm)\b", text, re.I | re.S):
            try:
                pr = program.define(text)
            except program.ProgError as ex:
                raise SyntaxErr(str(ex))
            if pr is None:
                raise SyntaxErr("Falta EndFunc / EndPrgm al final")
            k = pr.name.lower()
            if k in self._fn:
                raise CalcError("%s ya es una función de la calculadora" % pr.name)
            self.funcs.pop(k, None)
            self.vars.pop(k, None)
            self.progs[k] = pr
            self.names[k] = pr.name
            return Result(text=text, value=DONE, is_def=True)
        if "^()" in text or "()/()" in text or "(()/" in text or "/())" in text or "√()" in text:
            raise SyntaxErr("Hay una cajita vacía (exponente, fracción o raíz)")
        toks = tokenize(text)
        p = Parser(self, toks)
        try:
            value, info = p.statement()
        except CalcError:
            raise
        except UnitError as e:
            raise CalcError(str(e))
        except elec.ElecError as e:
            raise CalcError(str(e))
        except ZeroDivisionError:
            raise CalcError("División por cero")
        except RecursionError:
            raise CalcError("La expresión es demasiado compleja")
        except (TypeError, ValueError, AttributeError, NotImplementedError, sp.SympifyError) as e:
            raise CalcError(_explain(e))
        except (sp.PolynomialError, sp.polys.polyerrors.BasePolynomialError) as e:
            raise CalcError("Eso no es un polinomio válido para esta función (revisa los argumentos)")
        except (IndexError, KeyError, OverflowError, sp.polys.polyerrors.ComputationFailed) as e:
            raise CalcError(_explain(e))
        def _tl(v):                                   # una función devolvió una lista de Python
            return TIList(_tl(x) for x in v) if type(v) in (list, tuple, TIList) else v
        if type(value) in (list, tuple, TIList):
            value = _tl(value)
        res = Result(text=text, value=value, is_def=info.get("def", False),
                     target=info.get("target"), cplx=info.get("cplx", ""))
        res.temp = (info.get("temp_src"), info.get("temp_tgt"))
        h = info.get("force_hint") or info.get("unit_hint")
        try:
            pw = isinstance(value, sp.Expr) and units.has_units(value) and \
                units.dims(sp.simplify(value)) == units.dims(units.W_)
            if pw and value.has(sp.I) and not info.get("force_hint"):
                h = "VA"                     # P + j·Q (W + j·var) es potencia aparente: VA
        except Exception:  # noqa: BLE001
            pw = False
        res.unit_hint = h if h in ("VA", "var") else None
        if info.get("assigned"):
            nm = info["assigned"].lower()
            if pw and h in ("VA", "var", "W"):
                self.var_hints[nm] = h
            else:
                self.var_hints.pop(nm, None)
        if isinstance(value, (Done, str)):
            return res
        st = self.settings
        hf = has_float(value)
        want_approx = (force_approx or st.mode == "Aproximado" or info.get("decimal")
                       or (st.mode == "Auto" and (hf or info.get("dec"))))
        try:
            units.check(value) if isinstance(value, sp.Basic) else None
            if want_approx:
                value = approx(value)
            elif st.mode == "Exacto":
                value = to_exact(value)
        except UnitError as e:
            raise CalcError(str(e))
        value = tidy(value)
        if not want_approx:
            value = _auto_simp(value)                # (x²-1)/(x-1) = x+1, sin²+cos² = 1 (la TI lo hace sola)
        if st.cplx == "Real" and not res.cplx:
            value = _real_view(value)                # ln(ℯ^x) = x, √(x²) = |x| con x real (como la TI)
        if info.get("assigned") and want_approx and (info.get("dec") or hf) and st.mode != "Exacto":
            self.store(info["assigned"], value)      # a:=0.5 guarda 0.5 (no 1/2), como la TI
        elif info.get("assigned") and not info.get("def") and isinstance(value, (sp.Basic, TIList)) \
                and info["assigned"].lower() in self.vars:
            self.vars[info["assigned"].lower()] = value   # se guarda lo que se ve: a:=ℯ^(2πⅈ/3) -> -1/2+√3/2·ⅈ
        if st.cplx == "Real" and not res.cplx and has_imag(value) and not _input_has_imag(text):
            raise CalcError("El resultado no es real (cambia «Real o complejo» a Rectangular o Polar)")
        res.value = value
        res.approx = bool(want_approx)
        if res.target is not None:
            self._apply_target(res)
        if not info.get("noans"):
            self.ans = value
        return res

    def _apply_target(self, res):
        fac, toks = res.target
        v = res.value
        if not isinstance(v, sp.Basic):
            raise CalcError("Solo se pueden convertir unidades de un valor")
        src, tgt = res.temp
        if src and tgt and units.dims(sp.simplify(v)) == units.dims(units.K):
            num = sp.simplify(v / units.lookup(src))
            if num.is_number:                     # 100_°C▸_°F = 212·_°F (como la TI)
                num = sp.nsimplify(num, rational=True) if num.atoms(sp.Float) else num
                out = units.temp_convert(num, src, tgt)
                res.value = approx(out) if res.approx else sp.nsimplify(out) if out.is_Float else out
                res.extra = toks
                return
        num = sp.simplify(v / fac)
        if units.has_units(num):
            raise CalcError("Las unidades no son compatibles con %s"
                            % units.describe(units.dims(sp.simplify(v))))
        res.value = approx(num) if res.approx else num
        res.extra = toks


def _input_has_imag(text):
    return any(t in text for t in ("ⅈ", "@i", "∠", "@<")) or bool(
        re.search(r"\bc(solve|zeros|polyroots|factor)\s*\(", text, re.I))   # cSolve… siempre dan complejos


def _is_unit_value(v):
    """v ya es solo una unidad (_m, _m/_s): la que sigue se multiplica normalmente."""
    try:
        return isinstance(v, sp.Expr) and v != 1 and units.has_units(v) and units.split(v)[0] == 1
    except Exception:  # noqa: BLE001
        return False


def _explain(e) -> str:
    msg = str(e)
    if "not callable" in msg:
        return "Eso no es una función"
    if "NoneType" in msg:
        return "Falta completar un argumento"
    if "expecting bool or Boolean" in msg:
        return "and, or y not necesitan condiciones (true o false)"
    if "Matrix Power" in msg or "Matrix power" in msg:
        return "Esa potencia de matriz no está definida (la matriz debe ser cuadrada)"
    if "for +:" in msg or "for -:" in msg or "for *:" in msg or "for /:" in msg or "sequence by" in msg:
        if "str" in msg:
            return "No se puede hacer cuentas con texto"
        return "Esa operación no está definida para esos tipos (matriz, lista, número…)"
    if "Invalid comparison" in msg or "cannot determine truth value" in msg.lower():
        return "No se puede comparar eso (¿números complejos o sin valor?)"
    if "Matrix size mismatch" in msg or "ShapeError" in type(e).__name__ or "dimensions" in msg:
        return "Las dimensiones de las matrices no coinciden"
    if "non-invertible" in msg.lower() or "not invertible" in msg.lower():
        return "La matriz no es invertible (determinante 0)"
    return "No pude calcular eso (%s)" % msg[:120]


# ---------------------------------------------------------------- parser
class Parser:
    def __init__(self, eng: Engine, toks):
        self.e = eng
        self.t = toks
        self.i = 0
        self.bound: dict[str, sp.Symbol] = {}
        self.info: dict = {}
        self.in_de = 0          # dentro de deSolve(: y(0) e y'(0) son condiciones, no productos

    # tokens
    def peek(self, k=0):
        return self.t[min(self.i + k, len(self.t) - 1)]

    def next(self):
        tok = self.t[self.i]
        self.i += 1
        return tok

    def at(self, kind, val=None, k=0):
        tk = self.peek(k)
        return tk[0] == kind and (val is None or tk[1] == val)

    def at_op(self, *vals):
        tk = self.peek()
        return tk[0] == "op" and tk[1] in vals

    def at_word(self, *words):
        tk = self.peek()
        return tk[0] == "id" and tk[1].lower() in words

    def expect(self, val):
        tk = self.next()
        if tk[0] != "op" or tk[1] != val:
            got = tk[1] or "el final"
            raise SyntaxErr("Se esperaba «%s» y encontré «%s»" % (val, got))

    # ---- sentencia
    def statement(self):
        if self.at_word("define"):
            self.next()
            return self._assign(define=True)
        if self.at_word("delvar"):
            self.next()
            while True:
                tk = self.next()
                if tk[0] != "id":
                    raise CalcError("DelVar necesita nombres de variables")
                self.e.delete(tk[1])
                if not self.at_op(","):
                    break
                self.next()
            self._end()
            return DONE, {"def": True, "noans": True}
        depth = 0
        for tk in self.t:
            if tk[0] == "op" and tk[1] in "([{":
                depth += 1
            elif tk[0] == "op" and tk[1] in ")]}":
                depth -= 1
            elif tk == ("op", ":=") and depth == 0:
                return self._assign()
        v = self.expr()
        if self.at_op("→"):
            self.next()
            tk = self.next()
            if tk[0] != "id":
                raise CalcError("Después de → va el nombre de una variable")
            self._end()
            self.e.store(tk[1], v)
            self.info["assigned"] = tk[1]
            return v, self.info
        self._end()
        return v, self.info

    def _end(self):
        if not self.at("end"):
            tk = self.peek()
            raise SyntaxErr("Sobra «%s» al final" % tk[1])

    def _assign(self, define=False):
        tk = self.next()
        if tk[0] != "id":
            raise CalcError("Antes de := va un nombre (por ejemplo a:=5 o f(x):=x^2)")
        name = tk[1]
        if self.at_op("[") and not define:          # l[2]:=9, m[1,2]:=5
            cur = self.e.vars.get(name.lower())
            if not isinstance(cur, (TIList, sp.MatrixBase)):
                raise CalcError("%s no es una lista ni una matriz" % name)
            self.next()
            ix = [self.expr()]
            while self.at_op(","):
                self.next()
                ix.append(self.expr())
            self.expect("]")
            self._eq(False)
            v = self.expr()
            self._end()
            ks = [_int(a, "un índice entero") for a in ix]
            if isinstance(cur, TIList):
                if len(ks) != 1 or not 1 <= ks[0] <= len(cur) + 1:
                    raise CalcError("Índice fuera de rango")
                new = list(cur)
                if ks[0] == len(cur) + 1:
                    new.append(v)                        # la TI deja agregar uno al final
                else:
                    new[ks[0] - 1] = v
                new = TIList(new)
            else:
                if len(ks) != 2 or not (1 <= ks[0] <= cur.rows and 1 <= ks[1] <= cur.cols):
                    raise CalcError("Índice fuera de rango (usa m[fila,columna])")
                m = sp.Matrix(cur)
                m[ks[0] - 1, ks[1] - 1] = v
                new = sp.ImmutableMatrix(m)
            self.e.store(name, new)
            self.info["assigned"] = name
            return new, self.info
        if self.at_op("("):
            self.next()
            params = []
            while not self.at_op(")"):
                p = self.next()
                if p[0] != "id":
                    raise CalcError("Los parámetros de la función deben ser nombres")
                params.append(p[1])
                if self.at_op(","):
                    self.next()
            self.expect(")")
            self._eq(define)
            syms = [sp.Symbol(p) for p in params]
            self.bound = {p.lower(): s for p, s in zip(params, syms)}
            body = self.expr()
            self._end()
            if self.info.get("dec") and self.e.settings.mode != "Exacto":
                body = approx(body)                    # f(x):=0.5·x se queda con 0.5 (la TI lo muestra así)
            k = name.lower()
            if k in self.e._fn:
                raise CalcError("%s ya es una función de la calculadora" % name)
            self.e.vars.pop(k, None)
            self.e.names[k] = name
            self.e.funcs[k] = (syms, body)
            return DONE, {"def": True, "noans": True}
        self._eq(define)
        v = self.expr()
        self._end()
        self.e.store(name, v)
        self.info["assigned"] = name
        if define:
            return DONE, {"def": True, "noans": True}
        return v, self.info

    def _eq(self, define):
        if define:
            self.expect("=")
        else:
            self.expect(":=")

    # ---- expresiones
    def expr(self):
        v = self.with_()
        while self.at_op("▸"):
            self.next()
            v = self.conversion(v)
        return v

    def conversion(self, v):
        if self.at("id"):
            w = self.next()[1].lower()
            if w in ("rect", "rectangular"):
                self.info["cplx"] = "Rectangular"
                return v
            if w == "polar":
                self.info["cplx"] = "Polar"
                return v
            if w in ("decimal", "dec"):
                self.info["decimal"] = True
                return v
            if w == "rad":
                return v
            if w in ("base2", "base16", "base10"):
                self.info["noans"] = True
                return bmap(lambda x: BaseText.of(x, int(w[4:])), v)
            if w == "dms":
                if isinstance(v, (sp.MatrixBase, str)):
                    raise CalcError("▸DMS es para números o listas de números")
                deg = v if self.e.settings.angle == "Grado" else bmap(lambda x: self.e.to_rad(x) * 180 / sp.pi, v)
                self.info["noans"] = True
                return bmap(lambda x: DMSText.of(x), deg)
            if w == "ln":
                return bmap(lambda x: sp.expand_log(sp.sympify(x).rewrite(sp.log), force=True), v)
            if w == "exp":
                return bmap(lambda x: sp.sympify(x).rewrite(sp.exp), v)
            if w == "sin":
                return bmap(lambda x: sp.sympify(x).rewrite(sp.sin), v)
            if w == "cos":
                return bmap(lambda x: sp.sympify(x).rewrite(sp.cos), v)
            if w == "logbase":
                self.expect("(")
                b = self.expr()
                self.expect(")")
                return bmap(lambda x: sp.sympify(x).rewrite(sp.log).replace(
                    sp.log, lambda a: sp.log(a, b)), v)
            raise CalcError("No conozco la conversión ▸%s" % w)
        # ▸ unidad
        fac = sp.Integer(1)
        toks = []
        sign = 1
        first = True
        while True:
            if self.at("unit"):
                name = self.next()[1]
                ex = 1
                if self.at_op("^"):
                    self.next()
                    neg = 1
                    par = self.at_op("(")
                    if par:
                        self.next()
                    if self.at_op("-"):
                        self.next()
                        neg = -1
                    tk = self.next()
                    if tk[0] != "num":
                        raise CalcError("El exponente de una unidad debe ser un número")
                    ex = neg * sp.Rational(tk[1])
                    if par:
                        self.expect(")")
                ex = ex * sign
                fac = fac * units.lookup(name) ** ex
                toks.append((name, ex))
                sign = 1
                first = False
            elif self.at_op("/") and not first:
                self.next()
                sign = -1
            elif self.at_op("*") and not first:
                self.next()
            elif self.at_op("(") and not first:
                raise CalcError("Escribe la unidad sin paréntesis, por ejemplo ▸_km/_hr")
            else:
                break
        if not toks:
            raise CalcError("Después de ▸ va una unidad (▸_km) o Rect, Polar, Decimal")
        if len(toks) == 1 and toks[0][1] == 1 and toks[0][0] in units.TEMPS:
            self.info["temp_tgt"] = toks[0][0]
        self.info["target"] = (fac, toks)
        return v

    def with_(self):
        v = self.or_()
        if self.at_op("|"):
            self.next()
            cond = self.or_()
            subs, rels = {}, []
            for c in (cond.args if isinstance(cond, sp.And) else [cond]):
                if isinstance(c, sp.Equality):
                    subs[c.lhs] = c.rhs
                elif c is sp.true:
                    continue
                elif isinstance(c, sp.Rel):
                    rels.append(c)
                else:
                    raise CalcError("Después de | van igualdades o condiciones, por ejemplo x=2 o 0<x<40")
            ls = getattr(self.e, "last_solve", None)
            if rels and ls is not None and ls.get("result") is v:
                v = self.e.solve_in(ls, rels)          # solve(…)|0<x<40 (como la TI)
            elif rels and isinstance(v, (sp.Or, sp.Equality, sp.And)):
                v = self.e.filter_sols(v, rels)
            elif rels and isinstance(v, sp.Basic):
                v = _assume(v, rels)                   # √(x^2)|x>0 = x
            if subs:
                v = bmap(lambda a: sp.sympify(a).subs(subs), v) if not isinstance(v, Report) else v
        return v

    @staticmethod
    def _ints(*vals):
        return all(isinstance(x, sp.Integer) for x in vals)

    def or_(self):
        v = self.and_()
        while self.at_word("or", "xor"):
            w = self.next()[1].lower()
            b = self.and_()
            if self._ints(v, b):
                v = sp.Integer(int(v) | int(b) if w == "or" else int(v) ^ int(b))
            else:
                v = sp.Or(v, b) if w == "or" else sp.Xor(v, b)
        return v

    def and_(self):
        v = self.not_()
        while self.at_word("and"):
            self.next()
            b = self.not_()
            v = sp.Integer(int(v) & int(b)) if self._ints(v, b) else sp.And(v, b)
        return v

    def not_(self):
        if self.at_word("not"):
            self.next()
            a = self.not_()
            return sp.Integer(~int(a)) if self._ints(a) else sp.Not(a)
        return self.rel()

    def rel(self):
        a = self.add()
        if self.at_op("=", "≠", "<", ">", "≤", "≥"):
            op = self.next()[1]
            b = self.add()
            f = {"=": sp.Eq, "≠": sp.Ne, "<": sp.Lt, ">": sp.Gt, "≤": sp.Le, "≥": sp.Ge}[op]
            if isinstance(a, str) or isinstance(b, str):    # "a"="a" -> true
                if op not in ("=", "≠"):
                    raise CalcError("Los textos solo se comparan con = o ≠")
                return sp.true if (a == b) == (op == "=") else sp.false
            try:
                if isinstance(a, sp.MatrixBase) or isinstance(b, sp.MatrixBase):
                    return sp.true if (op == "=") == (a == b) else sp.false
                r = bcast(lambda x, y: f(x, y), a, b)
                while self.at_op("<", ">", "≤", "≥") and op in "<>≤≥":     # 0<x<40
                    op = self.next()[1]
                    c = self.add()
                    f = {"<": sp.Lt, ">": sp.Gt, "≤": sp.Le, "≥": sp.Ge}[op]
                    r = sp.And(r, f(b, c))
                    b = c
                return r
            except TypeError:
                raise CalcError("No se pueden comparar números complejos con < o >")
        return a

    def add(self):
        v = self.phasor()
        while self.at_op("+", "-", ".+", ".-", "&"):
            op = self.next()[1]
            b = self.phasor()
            if op == "&":
                v = str(v) + str(b) if isinstance(v, str) or isinstance(b, str) else v * b
            elif op in ("+", ".+"):
                v = self._binop(v, b, lambda x, y: x + y, elem=op == ".+")
            else:
                v = self._binop(v, b, lambda x, y: x - y, elem=op == ".-")
        return v

    def _binop(self, a, b, f, elem=False):
        _num(a)
        _num(b)
        if elem and isinstance(a, sp.MatrixBase) and not isinstance(b, sp.MatrixBase):
            return a.applyfunc(lambda x: f(x, b))
        if elem and isinstance(b, sp.MatrixBase) and not isinstance(a, sp.MatrixBase):
            return b.applyfunc(lambda y: f(a, y))
        if isinstance(a, sp.MatrixBase) != isinstance(b, sp.MatrixBase) and f(1, 1) in (0, 2) and \
                not _is_list(a) and not _is_list(b):
            m = a if isinstance(a, sp.MatrixBase) else b
            if not m.is_square:                       # TI: matriz ± número suma en la diagonal (solo cuadradas)
                raise CalcError("Matriz ± número solo vale con matrices cuadradas (usa .+ para cada elemento)")
            k = sp.eye(m.rows)
            if isinstance(a, sp.MatrixBase):
                return sp.ImmutableMatrix(f(a, b * k))
            return sp.ImmutableMatrix(f(a * k, b))
        return bcast(f, a, b)

    def starts_primary(self):
        tk = self.peek()
        if tk[0] == "unit" and getattr(self, "_no_unit", False):
            return False
        if tk[0] in ("num", "unit", "const", "str"):
            return True
        if tk[0] == "id":
            return tk[1].lower() not in KEYWORDS
        return tk[0] == "op" and tk[1] in ("(", "{", "[", "√", "∫", "Σ", "Π")

    def mul(self):
        v = self.angle()
        while True:
            if self.at_op("*", "/", ".*", "./"):
                op = self.next()[1]
                b = self.angle()
                if op == "*":
                    v = self._mul(v, b)
                elif op == ".*":
                    v = self._elem(v, b, lambda x, y: x * y)
                elif op == "./":
                    v = self._elem(v, b, lambda x, y: x / y)
                else:
                    v = self._div(v, b)
            elif self.starts_primary():
                v = self._mul(v, self.angle())
            else:
                return v

    def _mul(self, a, b):
        _num(a)
        _num(b)
        return bcast(lambda x, y: x * y, a, b)

    def _div(self, a, b):
        _num(a)
        _num(b)
        if isinstance(b, sp.MatrixBase):
            return a * b.inv()

        def d(x, y):
            if y == 0:
                return sp.nan                   # la TI muestra undef
            return x / y
        return bcast(d, a, b)

    def _elem(self, a, b, f):
        if isinstance(a, sp.MatrixBase) and isinstance(b, sp.MatrixBase):
            if a.shape != b.shape:
                raise CalcError("Las matrices deben tener el mismo tamaño")
            return sp.ImmutableMatrix(a.rows, a.cols, [f(x, y) for x, y in zip(a, b)])
        if isinstance(a, sp.MatrixBase):
            return a.applyfunc(lambda x: f(x, b))
        if isinstance(b, sp.MatrixBase):
            return b.applyfunc(lambda y: f(a, y))
        return bcast(f, a, b)

    def phasor(self):
        """r∠θ: el ángulo es todo el término que sigue (230∠-30, 1∠π/4, 10∠30+5∠-60)."""
        v = self.mul()
        if self.at_op("∠"):
            self.next()
            self._no_unit = True                # el ángulo termina antes de la unidad: 23∠58_V = (23∠58)·_V
            try:
                th = self.mul()
            finally:
                self._no_unit = False
            _num(v)
            _num(th)
            unit = sp.Integer(1)
            if self.at("unit"):
                unit = self.mul()
            if isinstance(th, sp.Expr) and units.has_units(th):
                th, u2 = units.split(th)
                unit = unit * u2
            v = bcast(lambda r, t: self.e.polar(r, t), v, th)
            if unit != 1:
                v = bmap(lambda x: x * unit, v)
        return v

    def angle(self):
        return self.unary()

    def unary(self):
        if self.at_op("-"):
            self.next()
            v = self.unary()
            _num(v)
            return bmap(lambda x: -x, v) if not isinstance(v, sp.MatrixBase) else -v
        if self.at_op("+"):
            self.next()
            return self.unary()
        return self.power()

    def power(self):
        base = self.postfix()
        if self.at_op("^", ".^"):
            op = self.next()[1]
            ex = self.unary()
            _num(base)
            _num(ex)
            if isinstance(base, sp.MatrixBase) and op == "^":
                n = sp.sympify(ex)
                if n == -1:
                    if base.det() == 0:
                        raise CalcError("La matriz no es invertible (determinante 0)")
                    return base.inv()
                return base ** _int(n, "un exponente entero para la matriz")
            if op == ".^":
                return self._elem(base, ex, lambda x, y: x ** y)
            return bcast(lambda x, y: self._pow(x, y), base, ex)
        return base

    def _pow(self, x, y):
        if x == 0 and sp.sympify(y).is_negative:
            return sp.nan
        try:
            xs, ys = sp.sympify(x), sp.sympify(y)
            if (self.e.settings.cplx == "Real" and xs.is_number and xs.is_real and xs.is_negative
                    and ys.is_Rational and not ys.is_Integer and ys.q % 2 == 1):
                return -((-xs) ** ys) if ys.p % 2 == 1 else (-xs) ** ys
        except (TypeError, ValueError, AttributeError):
            pass
        return x ** y

    def postfix(self):
        v = self.primary()
        while self.at_op("[") and isinstance(v, (TIList, sp.MatrixBase, str)) and not self.at("op", "[", 1):
            v = self._index(v)                       # l[2], m[1,2], m[1]  (como la TI)
        while self.at_op("!", "°", "ᵀ", "%", "'", "ʳ", "ᵍ", "″"):
            op = self.next()[1]
            if op != "ᵀ" and not (op == "'" and isinstance(v, sp.Symbol)):
                _num(v)
            if op == "!":
                v = bmap(lambda x: sp.gamma(x + 1) if (sp.sympify(x).is_Rational and not sp.sympify(x).is_Integer)
                         else sp.factorial(x), v)          # (1/2)! = √π/2
            elif op == "°":
                d = v                                   # 30°15'30" = 30+15/60+30/3600 grados
                if self.at("num") and self.at("op", "'", 1):
                    _num(d)
                    d = d + self.primary() / 60
                    self.next()
                if self.at("num") and self.at("op", "″", 1):
                    _num(d)
                    d = d + self.primary() / 3600
                    self.next()
                v = bmap(lambda x: self.e.degrees(x), d)
            elif op == "″":
                v = bmap(lambda x: self.e.degrees(x / 3600), v)
            elif op == "ᵀ":
                if not isinstance(v, sp.MatrixBase):
                    raise CalcError("ᵀ (trasponer) es para matrices")
                v = v.T
            elif op == "%":
                v = bmap(lambda x: x / 100, v)
            elif op == "'":
                if isinstance(v, sp.Symbol) and not v.name.startswith("_"):
                    v = sp.Symbol(v.name + "'")          # y' y'' (prima, como la TI)
                else:
                    v = bmap(lambda x: self.e.degrees(x / 60), v)
            elif op == "ʳ":                             # radianes -> unidades del modo
                v = bmap(lambda x: self.e.from_rad(x), v)
            elif op == "ᵍ":                             # gradianes -> unidades del modo
                v = bmap(lambda x: self.e.from_rad(x * sp.pi / 200), v)
        if self.in_de and isinstance(v, sp.Symbol) and v.name.endswith("'") and self.at_op("("):
            v = self._applied(v.name)
        while self.at("unit") and not getattr(self, "_no_unit", False) and not _is_unit_value(v):
            u = self.primary()
            if self.at_op("^"):
                self.next()
                u = u ** self.unary()
            _num(v)
            v = self._mul(v, u)
        return v

    def _index(self, v):
        self.expect("[")
        ix = [self.expr()]
        while self.at_op(","):
            self.next()
            ix.append(self.expr())
        self.expect("]")
        ks = [_int(a, "un índice entero") for a in ix]
        try:
            if isinstance(v, sp.MatrixBase):
                if len(ks) == 1:
                    if not 1 <= ks[0] <= v.rows:
                        raise IndexError
                    return sp.ImmutableMatrix(v[ks[0] - 1, :]) if v.rows > 1 or v.cols == 1 else v[0, ks[0] - 1]
                if not (1 <= ks[0] <= v.rows and 1 <= ks[1] <= v.cols):
                    raise IndexError
                return v[ks[0] - 1, ks[1] - 1]
            if len(ks) != 1 or not 1 <= ks[0] <= len(v):
                raise IndexError
            return v[ks[0] - 1]
        except IndexError:
            raise CalcError("Índice fuera de rango")

    def _tmpcnv(self, k):
        """tmpCnv(100_°C,_°F) = 212·_°F (valor absoluto); ΔtmpCnv convierte una diferencia."""
        self.expect("(")
        saved = self.info.pop("temp_src", None)
        v = self.expr()
        src = self.info.pop("temp_src", None)
        if saved:
            self.info["temp_src"] = saved
        self.expect(",")
        tk = self.next()
        if tk[0] != "unit" or tk[1] not in units.TEMPS:
            raise CalcError("tmpCnv(valor_°C, _°F): el segundo argumento es una unidad de temperatura")
        self.expect(")")
        if src is None:
            raise CalcError("tmpCnv necesita una temperatura con unidad, por ejemplo tmpCnv(100_°C,_°F)")
        tgt = tk[1]
        num = sp.sympify(v) / units.lookup(src)
        if units.has_units(sp.simplify(num)):
            raise CalcError("tmpCnv necesita una temperatura con unidad, por ejemplo tmpCnv(100_°C,_°F)")
        if k == "tmpcnv":
            out = units.temp_convert(num, src, tgt)
        else:
            out = num * units.TEMPS[src][0] / units.TEMPS[tgt][0]
        self.info["target"] = (units.lookup(tgt), [(tgt, 1)])
        return out * units.lookup(tgt)

    def _applied(self, name):
        """y(0) o y'(0) dentro de deSolve: la función evaluada en un punto."""
        self.expect("(")
        arg = self.expr()
        self.expect(")")
        return sp.Function(name)(arg)

    # ---- primarios
    def primary(self):
        tk = self.next()
        kind, val = tk
        if kind == "num":
            if "." in val or "E" in val:
                self.info["dec"] = True               # el resultado se muestra en decimal (Auto)
                try:
                    q = sp.Rational(val)              # exacto en base 10, como la TI: 1-0.9-0.1 = 0.
                    if abs(q.q) < 10 ** 40 and abs(q.p) < 10 ** 1200:
                        return q
                except (TypeError, ValueError):
                    pass
                return sp.Float(val, 15)              # 1E3 = 1000. (la TI lo deja decimal)
            return sp.Integer(val)
        if kind == "unit":
            low = val.replace("'", "").lower()
            hint = "var" if low.endswith("var") else "VA" if low.endswith("va") else "W" if low.endswith("w") else None
            if hint:
                prev = self.info.get("unit_hint")
                self.info["unit_hint"] = hint if prev in (None, hint) else "-"
            if val in units.TEMPS:
                self.info.setdefault("temp_src", val)
            return units.lookup(val)
        if kind == "const":
            return SPECIAL[val]
        if kind == "str":
            return val
        if kind == "op":
            if val == "(":
                v = self.expr()
                self.expect(")")
                return v
            if val == "{":
                items = []
                while not self.at_op("}"):
                    items.append(self.expr())
                    if self.at_op(","):
                        self.next()
                    elif not self.at_op("}"):
                        raise SyntaxErr("En una lista los elementos van separados por comas")
                self.next()
                return TIList(items)
            if val == "[":
                return self.matrix()
            if val == "√":
                if self.at_op("("):
                    self.next()
                    v = self.expr()
                    self.expect(")")
                else:
                    v = self.power()
                return bmap(lambda x: self.e._fn["sqrt"][0](x), v)
            if val in ("∫", "Σ", "Π"):
                name = {"∫": "integral", "Σ": "sum_", "Π": "product_"}[val]
                return self.call(name, val)
            if val == "-":
                self.i -= 1
                return self.unary()
            raise SyntaxErr("No esperaba «%s» aquí" % val)
        if kind == "id":
            k = val.lower()
            if k in self.bound:
                return self.bound[k]
            if k in ("tmpcnv", "δtmpcnv") and self.at_op("("):
                return self._tmpcnv(k)
            if self.at_op("(") and k in self.e.progs:
                from . import program
                self.expect("(")
                args = []
                while not self.at_op(")"):
                    if self.at("end"):
                        raise SyntaxErr("Falta cerrar el paréntesis de %s(" % val)
                    args.append(self.expr())
                    if self.at_op(","):
                        self.next()
                self.next()
                return program.call(self.e, self.e.progs[k], args)
            if self.at_op("(") and (k in self.e._fn or k in self.e.funcs or "\\" in k):
                return self.call(k, val)
            if k in STAT_CMDS and not self.at("end") and not self.at_op(":") and not self.at_op(")"):
                args = [self.expr()]                   # forma de comando: OneVar {1,2,3}  /  LinRegMx L1,L2
                while self.at_op(","):
                    self.next()
                    args.append(self.expr())
                return self._apply(k, val, args)
            if k.startswith("stat."):
                v = self.e.stat_var(val)
                if self.at_op("(") and isinstance(v, sp.Basic) and not isinstance(v, (sp.MatrixBase,)):
                    self.next()                         # stat.RegEqn(4)
                    a = self.expr()
                    self.expect(")")
                    return v.subs(sp.Symbol("x"), a)
                return v
            if k in self.e.var_hints and k in self.e.vars:
                h = self.e.var_hints[k]
                prev = self.info.get("unit_hint")
                self.info["unit_hint"] = h if prev in (None, h) else "-"
            if self.in_de and self.at_op("(") and k not in self.e.vars:
                return self._applied(self.e.lookup(val).name if k in self.e.symbols else val)
            if "\\" in k:
                raise CalcError("No conozco la función de librería %s" % val)
            if (self.at_op("(") and len(k) > 1 and k not in self.e.vars and k not in self.e.funcs
                    and k not in ("pi", "ans", "true", "false") and not self.in_de):
                self.expect("(")                       # función que no existe: queda escrita, foo(2) (TI)
                args = []
                while not self.at_op(")"):
                    if self.at("end"):
                        raise SyntaxErr("Falta cerrar el paréntesis de %s(" % val)
                    args.append(self.expr())
                    if self.at_op(","):
                        self.next()
                self.next()
                if not all(isinstance(a, sp.Expr) for a in args):
                    raise CalcError("No conozco la función %s" % val)
                return sp.Function(val)(*args)
            return self.e.lookup(val)
        if kind == "end":
            raise SyntaxErr("La expresión está incompleta")
        raise SyntaxErr("No esperaba «%s»" % val)

    def matrix(self):
        rows = []
        if self.at_op("["):
            while self.at_op("["):
                self.next()
                row = []
                while not self.at_op("]"):
                    row.append(self.expr())
                    if self.at_op(","):
                        self.next()
                self.next()
                rows.append(row)
                if self.at_op(","):
                    self.next()
            self.expect("]")
        else:
            row = []
            while not self.at_op("]"):
                row.append(self.expr())
                if self.at_op(","):
                    self.next()
                elif self.at_op(";"):
                    self.next()
                    rows.append(row)
                    row = []
                elif not self.at_op("]"):
                    raise SyntaxErr("En una matriz los elementos van separados por comas")
            self.next()
            rows.append(row)
        if not rows or any(len(r) != len(rows[0]) for r in rows) or not rows[0]:
            raise CalcError("Todas las filas de la matriz deben tener el mismo largo")
        return sp.ImmutableMatrix(rows)

    def call(self, k, shown):
        if k in ("real", "re"):
            self.info["force_hint"] = "W"
        elif k in ("imag", "im"):
            self.info["force_hint"] = "var"
        if k in ("exact", "approxfraction", "approxrational"):
            saved = self.info.get("dec")             # exact(0.25) = 1/4 aunque se escribió un decimal
            try:
                return self._call(k, shown)
            finally:
                self.info["dec"] = saved
        if k in ("desolve", "seqgen"):                # y(0), u(n-1): funciones de la incógnita
            self.in_de += 1
            try:
                return self._call(k, shown)
            finally:
                self.in_de -= 1
        return self._call(k, shown)

    def _call(self, k, shown):
        self.expect("(")
        args = []
        while not self.at_op(")"):
            if self.at("end"):
                raise SyntaxErr("Falta cerrar el paréntesis de %s(" % shown)
            if self.at_op(","):                      # argumento vacío (bal(12,360,6,100000,,,12) como la TI)
                self.next()
                args.append(None)
                if self.at_op(")"):
                    args.append(None)
                continue
            args.append(self.expr())
            if self.at_op(","):
                self.next()
            elif not self.at_op(")"):
                raise SyntaxErr("Los argumentos de %s van separados por comas" % shown)
        self.next()
        return self._apply(k, shown, args)

    def _apply(self, k, shown, args):
        if k in self.e.funcs:
            params, body = self.e.funcs[k]
            if len(args) != len(params):
                raise CalcError("%s necesita %d argumento(s)" % (shown, len(params)))
            if any(_is_list(a) for a in args):
                n = max(len(a) for a in args if _is_list(a))
                return TIList(body.xreplace({p: (a[j] if _is_list(a) else a) for p, a in zip(params, args)})
                              for j in range(n))
            if any(isinstance(a, sp.MatrixBase) for a in args):
                return body.subs(dict(zip(params, args)))
            return body.xreplace(dict(zip(params, args)))
        if k not in self.e._fn:
            raise CalcError("No conozco la función %s" % shown)
        fn, lo, hi = self.e._fn[k]
        if len(args) < lo or (hi is not None and len(args) > hi):
            if lo == hi:
                raise CalcError("%s necesita %d argumento(s)" % (shown, lo))
            raise CalcError("%s necesita entre %d y %s argumentos" % (shown, lo, hi if hi else "más"))
        out = fn(*args)
        if isinstance(out, tuple) and len(out) == 2 and out[0] == "__info__":
            self.info.update(out[1][1])
            return out[1][0]
        return out


# ---------------------------------------------------------------- funciones
def build_functions(E: Engine):
    F = {}

    def reg(names, lo, hi=None, mapped=False):
        hi = lo if hi == "same" else hi

        def deco(fn):
            f = fn
            if mapped:
                def f(*a, _fn=fn):
                    if a and (_is_list(a[0]) or isinstance(a[0], sp.MatrixBase)):
                        return bmap(lambda x: _fn(x, *a[1:]), a[0])
                    return _fn(*a)
            for n in names.split():
                F[n.lower()] = (f, lo, hi)
            return fn
        return deco

    S = sp.sympify

    # ---- trigonometría (según el modo de ángulo)
    for name, f in (("sin", sp.sin), ("cos", sp.cos), ("tan", sp.tan), ("sec", sp.sec),
                    ("csc", sp.csc), ("cot", sp.cot)):
        reg(name, 1, 1, mapped=True)(lambda x, f=f: f(E.to_rad(S(x))))
    for name, f in (("asin arcsin", sp.asin), ("acos arccos", sp.acos), ("atan arctan", sp.atan),
                    ("asec", sp.asec), ("acsc", sp.acsc), ("acot", sp.acot)):
        reg(name, 1, 1, mapped=True)(lambda x, f=f: E.from_rad(f(S(x))))
    for name, f in (("sinh", sp.sinh), ("cosh", sp.cosh), ("tanh", sp.tanh), ("asinh", sp.asinh),
                    ("acosh", sp.acosh), ("atanh", sp.atanh)):
        reg(name, 1, 1, mapped=True)(lambda x, f=f: f(S(x)))

    @reg("atan2", 2, 2)
    def _atan2(y, x):
        return E.from_rad(sp.atan2(S(y), S(x)))

    # ---- números
    reg("ln", 1, 1, mapped=True)(lambda x: sp.nan if S(x).is_zero else sp.log(S(x)))
    reg("exp", 1, 1, mapped=True)(lambda x: sp.exp(S(x)))

    @reg("log", 1, 2)
    def _log(x, b=10):
        def one(v):
            v = S(v)
            if v.is_zero:
                return sp.nan
            r = sp.log(v, b)
            if r.is_number and not r.atoms(sp.Float):
                q = sp.simplify(sp.expand_log(r, force=True))   # log(2,8) = 1/3
                if q.is_Rational:
                    return q
            return r
        return bmap(one, x)

    @reg("sqrt", 1, 1, mapped=True)
    def _sqrt(x):
        x = S(x)
        if units.has_units(x):
            return sp.sqrt(x)
        return sp.sqrt(x)

    @reg("root", 1, 2)
    def _root(x, n=2):
        n = S(n)

        def r(v):
            v = S(v)
            if n.is_integer and n % 2 == 1 and v.is_number and v.is_real and v.is_negative:
                return -sp.root(-v, n)
            return sp.root(v, n)
        return bmap(r, x)

    reg("abs magnitude", 1, 1, mapped=True)(lambda x: sp.Abs(S(x)))
    def _undef_real(f):
        """Como la TI: en conj/real/imag/angle las variables sin valor se toman como reales (las que terminan
        en _ , como z_, son complejas): real(v·ℯ^(ⅈ·t)) = v·cos(t)."""
        def g(x):
            x = S(x)
            if isinstance(x, sp.Basic) and x.free_symbols:
                rep = {a: sp.Symbol(a.name, real=True) for a in x.free_symbols
                       if isinstance(a, sp.Symbol) and not a.name.endswith("_") and a.is_real is None}
                if rep:
                    back = {b: a for a, b in rep.items()}
                    return sp.sympify(f(x.xreplace(rep))).xreplace(back)
            return f(x)
        return g

    reg("conj", 1, 1, mapped=True)(_undef_real(sp.conjugate))
    reg("real", 1, 1, mapped=True)(_undef_real(sp.re))
    reg("imag", 1, 1, mapped=True)(_undef_real(sp.im))
    reg("angle", 1, 1, mapped=True)(_undef_real(lambda x: E.from_rad(sp.arg(x))))
    reg("sign", 1, 1, mapped=True)(lambda x: sp.sign(S(x)))
    reg("floor int", 1, 1, mapped=True)(lambda x: sp.floor(S(x)))
    reg("ceiling", 1, 1, mapped=True)(lambda x: sp.ceiling(S(x)))
    reg("ipart", 1, 1, mapped=True)(lambda x: sp.sign(S(x)) * sp.floor(sp.Abs(S(x))))
    reg("fpart", 1, 1, mapped=True)(lambda x: S(x) - sp.sign(S(x)) * sp.floor(sp.Abs(S(x))))

    @reg("round", 1, 2)
    def _round(x, n=12):
        n = _int(n)
        return bmap(lambda v: sp.Float(round(_float(v), n), 15) if S(v).is_real is not False
                    else sp.Float(round(_float(sp.re(v)), n)) + sp.I * sp.Float(round(_float(sp.im(v)), n)), x)

    @reg("mod", 2, 2)
    def _mod(a, b):
        return bcast(lambda x, y: sp.Mod(x, y) if y != 0 else x, a, b)

    @reg("remain", 2, 2)
    def _remain(a, b):
        def r(x, y):
            if y == 0:
                return x
            q = x / y
            return x - y * sp.sign(q) * sp.floor(sp.Abs(q))
        return bcast(r, a, b)

    @reg("gcd", 2, 2)
    def _gcd(a, b):
        return bcast(lambda x, y: sp.gcd(x, y), a, b)

    @reg("lcm", 2, 2)
    def _lcm(a, b):
        return bcast(lambda x, y: sp.lcm(x, y), a, b)

    @reg("factor", 1, 2)
    def _factor(x, var=None):
        def f(v):
            v = S(v)
            if v.is_Integer and v != 0:
                fac = sp.factorint(abs(int(v)))
                parts = [sp.Pow(p, e, evaluate=False) if e > 1 else sp.Integer(p) for p, e in fac.items()]
                if not parts:
                    return v
                out = sp.Mul(*parts, evaluate=False) if len(parts) > 1 else parts[0]
                return -out if v < 0 else out
            if v.is_Rational and not v.is_Integer:
                return sp.Mul(_factor(v.p), sp.Pow(_factor(v.q), -1, evaluate=False), evaluate=False)
            return sp.factor(v, *( [var] if var is not None else []))
        return bmap(f, x)

    @reg("cfactor", 1, 2)
    def _cfactor(x, var=None):
        return bmap(lambda v: sp.factor(S(v), extension=sp.I), x)

    @reg("expand", 1, 2)
    def _expand(x, var=None):
        def one(v):
            v = S(v)
            if isinstance(v, sp.Expr) and not isinstance(v, sp.MatrixBase):
                num, den = sp.fraction(sp.together(v))
                syms = [var] if isinstance(var, sp.Symbol) else sorted(den.free_symbols, key=str)
                if den.free_symbols and len(syms) == 1 and v.is_rational_function(*syms):
                    try:                               # expand(1/((x-1)(x+2))) en fracciones parciales (TI)
                        return sp.apart(v, syms[0])
                    except Exception:  # noqa: BLE001
                        pass
            return sp.expand(v)
        return bmap(one, x)

    @reg("simplify", 1, 1)
    def _simplify(x):
        return bmap(lambda v: sp.simplify(S(v)), x)

    @reg("propfrac", 1, 2)
    def _propfrac(x, var=None):
        def f(v):
            v = S(v)
            if v.is_Rational and not v.is_Integer:
                q = int(sp.sign(v) * sp.floor(sp.Abs(v)))
                r = v - q
                return sp.Add(q, r, evaluate=False) if q else r
            return sp.apart(v, var) if var is not None else sp.apart(v)
        return bmap(f, x)

    @reg("isprime", 1, 1)
    def _isprime(x):
        def one(v):
            v = S(v)
            if not v.is_Integer:
                raise CalcError("isPrime necesita un número entero")
            return sp.true if sp.isprime(int(v)) else sp.false
        return bmap(one, x)

    reg("getnum", 1, 1, mapped=True)(lambda x: sp.fraction(sp.together(S(x)))[0])
    reg("getdenom", 1, 1, mapped=True)(lambda x: sp.fraction(sp.together(S(x)))[1])
    reg("comdenom", 1, 2, mapped=True)(lambda x, v=None: sp.together(S(x)))

    @reg("approxfraction", 1, 2)
    def _approxfrac(x, tol=None):
        t = _float(tol) if tol is not None else 5e-14

        def one(v):
            from fractions import Fraction
            fv = Fraction(repr(_float(v)))
            if fv == 0:
                return sp.Integer(0)
            # convergentes de la fracción continua hasta quedar dentro de la tolerancia
            h0, h1, k0, k1 = 0, 1, 1, 0
            r = fv
            for _ in range(60):
                a = r.numerator // r.denominator
                h0, h1 = h1, a * h1 + h0
                k0, k1 = k1, a * k1 + k0
                if abs(Fraction(h1, k1) - fv) <= t * abs(fv) or r == a:
                    break
                r = 1 / (r - a)
            return sp.Rational(h1, k1)
        return bmap(one, x)

    reg("approxrational", 1, 2)(_approxfrac)

    reg("exact", 1, 2, mapped=True)(lambda x, tol=None: sp.nsimplify(S(x), rational=True) if tol is None
                                    else sp.nsimplify(S(x), tolerance=float(tol), rational=True))

    @reg("approx", 1, 1)
    def _approx(x):
        return ("__info__", (x, {"decimal": True}))

    # ---- álgebra
    def _vars_of(v):
        if _is_list(v):
            return list(v)
        return [v]

    def _eqs(e):
        out = []
        for x in (e if _is_list(e) else [e]):
            x = S(x)
            if isinstance(x, sp.Equality):
                out.append(x.lhs - x.rhs)
            elif isinstance(x, sp.And):
                out.extend(_eqs(TIList(x.args)))
            elif isinstance(x, sp.Rel):
                out.append(x)
            else:
                out.append(x)
        return out

    def _real_ok(s):
        try:
            if s.is_number:
                im = sp.im(sp.N(s))
                return abs(float(im)) < 1e-12
        except (TypeError, ValueError):
            pass
        return s.is_real is not False

    def _solve(eqs, vs, cplx):
        ex = _eqs(eqs)
        vs = _vars_of(vs)
        for v in vs:
            if isinstance(v, sp.Rel):
                raise CalcError("El segundo argumento es la variable (x), o x=valor inicial; las condiciones "
                                "van después con | (por ejemplo solve(ec,x)|0<x<40)")
            if not isinstance(v, sp.Symbol):
                raise CalcError("Una de las variables a despejar ya tiene un valor guardado (bórrala con "
                                "DelVar o usa otro nombre; recuerda que y e Y son la misma variable)")
        if any(isinstance(x, sp.Rel) for x in ex):       # desigualdades: solve(x^2>4,x) -> x<-2 or x>2
            if len(vs) != 1:
                raise CalcError("Con desigualdades se despeja una sola variable")
            v = vs[0]
            try:
                r = sp.reduce_inequalities([x if isinstance(x, sp.Rel) else sp.Eq(x, 0) for x in ex], v)
            except (NotImplementedError, ValueError, TypeError):
                raise CalcError("No pude resolver esa desigualdad")
            return _ti_ineq(r, v)
        sols = _giac_solve(ex, vs, cplx)
        if sols and len(ex) == 1 and len(vs) == 1:
            g = _general(ex[0], vs[0])
            if g:
                sols = [{vs[0]: x} for x in g]
        if sols is None and not cplx and any(x.has(sp.Abs, sp.sign, sp.re, sp.im) for x in ex):
            rv = {v: sp.Dummy(v.name, real=True) for v in vs}   # solve(abs(x-1)=3,x): x reales
            back = {b: a for a, b in rv.items()}
            try:
                sols = [{back.get(k, k): sp.sympify(val).xreplace(back) for k, val in d.items()}
                        for d in sp.solve([x.xreplace(rv) for x in ex], list(rv.values()), dict=True)]
            except (NotImplementedError, ValueError, TypeError):
                sols = None
        try:
            if sols is None:
                sols = sp.solve(ex, vs, dict=True)
        except NotImplementedError:
            sols = []
        if not cplx:
            sols = [s for s in sols if all(_real_ok(val) for val in s.values())]
        if not sols and len(ex) == 1 and len(vs) == 1 and _numeric_ok(ex, vs):
            from . import giac as _g
            if not _g.available():               # sin Giac (celular): antes de decir "false", búsqueda numérica
                from . import roots
                try:
                    rs = roots.numeric_roots(ex[0], vs[0], -100, 100, 20000)
                except Exception:  # noqa: BLE001
                    rs = []
                sols = [{vs[0]: sp.Float(r, 15)} for r in rs]
        if not sols:
            if ex and all(e.is_number for e in [sp.simplify(x) for x in ex]):
                return sp.true if all(sp.simplify(x) == 0 for x in ex) else sp.false
            return sp.false
        terms = []
        for s in sols:
            eqs_ = [sp.Eq(v, s[v]) if v in s else sp.true for v in vs]
            terms.append(sp.And(*eqs_) if len(eqs_) > 1 else eqs_[0])
        if len(terms) == 1:
            return terms[0]
        return sp.Or(*terms, evaluate=False) if all(t is not sp.true for t in terms) else sp.Or(*terms)

    def _numeric_ok(ex, vs):
        """Ecuaciones solo en vs, sin unidades ni funciones raras: se pueden resolver por Newton."""
        try:
            return all(isinstance(x, sp.Expr) and x.free_symbols <= set(vs) and not units.has_units(x)
                       and not x.has(AppliedUndef, sp.Piecewise, sp.Integral, sp.Derivative) for x in ex)
        except Exception:  # noqa: BLE001
            return False

    def _numeric_system(ex, vs):
        from . import roots
        r = roots.system_roots(ex, vs)
        return r or None

    def _general(ex, v):
        """Como la TI: con funciones trigonométricas, la solución general con n1, n2… enteros
        (solve(sin(x)=1/2,x) -> x=2·n1·π+π/6 or x=2·n1·π+5π/6)."""
        from . import giac
        try:
            if not (ex.has(sp.sin, sp.cos, sp.tan, sp.sec, sp.csc, sp.cot) and giac.available()) \
                    or units.has_units(ex) or ex.free_symbols != {v}:
                return None
            trig = [f for f in ex.atoms(sp.sin, sp.cos, sp.tan, sp.sec, sp.csc, sp.cot) if f.has(v)]
            if not trig:
                return None
            flo = bool(ex.atoms(sp.Float))
            g = giac.solve_general(sp.nsimplify(ex, rational=True) if flo else ex, v, 4)
            ns = sorted({t for x in g for t in sp.sympify(x).free_symbols if t != v}, key=str)
            if not ns or any(not (t.name.startswith("n") and t.name[1:].isdigit()) for t in ns):
                return None
            out = []
            names = {}
            for x in g:
                x = sp.sympify(x)
                for t in sorted(x.free_symbols, key=str):
                    if t not in names:
                        names[t] = sp.Symbol("n%d" % (len(names) + 1), integer=True)
                x = x.xreplace(names)
                n = [t for t in x.free_symbols][0] if x.free_symbols else None
                if n is not None and x.is_polynomial(n) and sp.degree(x, n) == 1:
                    per, off = [sp.simplify(c_) for c_ in sp.Poly(sp.expand(x), n).all_coeffs()]
                    p_, o_ = abs(float(sp.N(per))), float(sp.N(off))
                    k = 0
                    if o_ <= -p_ / 2 - 1e-12 or o_ > p_ + 1e-12:  # 147.203 y no -212.797: desfase en (-T/2, T]
                        k = -math.floor((o_ + p_ / 2) / p_)
                    if flo:
                        x = sp.Float(float(sp.N(per)), 15) * n + sp.Float(o_ + k * p_, 15)
                    else:
                        x = per * n + sp.simplify(off + k * abs(per))
                out.append(sp.N(x, 15) if flo else x)
            return out
        except Exception:  # noqa: BLE001
            return None

    def _poly_numeric(ex, vs, cplx):
        """Un polinomio con decimales en una variable: raíces con NumPy (como la TI con decimales: numérico).
        Evita que SymPy se quede pegado buscando la forma exacta (0.2x⁶−1.3x⁴+2x²−0.5=0). None = no aplica."""
        if len(ex) != 1 or len(vs) != 1:
            return None
        e, v = ex[0], vs[0]
        try:
            if not (e.free_symbols <= {v} and e.is_polynomial(v)):
                return None
            if not e.atoms(sp.Float) and sp.degree(e, v) < 5:
                return None                      # exacto y de grado ≤ 4: SymPy da la forma exacta
            co = [complex(sp.N(c)) for c in sp.Poly(sp.expand(e), v).all_coeffs()]
        except (sp.PolynomialError, TypeError, ValueError):
            return None
        if len(co) < 2:
            return None
        import numpy as np
        rts = np.roots(co)
        scale = max(1.0, max(abs(r) for r in rts)) if len(rts) else 1.0
        out = []
        for r in rts:
            if abs(r.imag) <= 1e-9 * scale:
                out.append(sp.Float(float(r.real), 15))
            elif cplx:
                out.append(sp.Float(float(r.real), 15) + sp.I * sp.Float(float(r.imag), 15))
        out.sort(key=lambda z: (float(sp.re(z)), float(sp.im(z))))
        dedup = []
        for z in out:
            if not dedup or abs(complex(z) - complex(dedup[-1])) > 1e-9 * scale:
                dedup.append(z)
        return [{v: z} for z in dedup]

    def _giac_solve(ex, vs, cplx):
        """Giac primero (rápido, y pasa solo a numérico); None = usar SymPy."""
        from . import giac
        if (len(vs) >= 2 and not cplx and _numeric_ok(ex, vs) and any(x.atoms(sp.Float) for x in ex)
                and not all(x.is_polynomial(*vs) for x in ex)):
            r = _numeric_system(ex, vs)              # sistema no lineal con decimales (como la TI: numérico)
            if r:
                return r
        try:
            if not giac.available():
                return _poly_numeric(ex, vs, cplx)    # sin Giac (celular): polinomios con decimales en numérico
            if any(units.has_units(x) or x.has(AppliedUndef, sp.Piecewise, sp.Integral, sp.Derivative)
                   or isinstance(x, (sp.MatrixBase, TIList)) for x in ex):
                return None
            return giac.solve(ex, vs, cplx)
        except giac.GiacCancelled:
            raise CalcError("Cálculo cancelado")
        except giac.GiacTimeout:
            if not cplx and _numeric_ok(ex, vs):
                if len(vs) >= 2:
                    r = _numeric_system(ex, vs)
                else:
                    from . import roots
                    rs = roots.numeric_roots(ex[0], vs[0], -100, 100, 20000)
                    r = [{vs[0]: sp.Float(x, 15)} for x in rs] or None
                if r:
                    return r
            raise CalcError("La ecuación tardó demasiado en resolverse (más de %d s). Prueba con nSolve "
                            "o dando un intervalo." % giac.TIMEOUT)
        except (giac.GiacError, TypeError, ValueError):
            return None

    def _ti_ineq(r, v):
        """Forma de la TI: x>2, x<-2 or x>2, -2<x and x<2 (sin el x<∞ de SymPy)."""
        if isinstance(r, sp.Or):
            parts = [_ti_ineq(a, v) for a in r.args]

            def where(a):                            # de izquierda a derecha: x<-2 or x>2
                try:
                    nums = [float(x) for x in a.atoms(sp.Number)]
                    return min(nums) if nums else 0.0
                except (TypeError, ValueError):
                    return 0.0
            parts.sort(key=where)
            return sp.Or(*parts, evaluate=False)
        if isinstance(r, sp.And):
            keep = [a for a in r.args if not (isinstance(a, sp.Rel) and (a.has(sp.oo) or a.has(-sp.oo)))]
            if not keep:
                return sp.true
            keep = [_ti_ineq(a, v) for a in keep]
            return keep[0] if len(keep) == 1 else sp.And(*keep, evaluate=False)
        if isinstance(r, sp.Rel) and not r.lhs.has(v) and r.rhs == v:
            return r.reversed                       # 3<x -> x>3
        return r

    def _solve_entry(e, v, cplx):
        if isinstance(v, sp.Equality) and isinstance(v.lhs, sp.Symbol) and S(v.rhs).is_number:
            return _solve_guess(e, v.lhs, v.rhs)       # solve(ec, x=0): la más cercana a 0 (TI)
        r = _solve(e, v, cplx)
        E.last_solve = {"e": e, "v": v, "cplx": cplx, "result": r}
        return r

    def _solve_guess(e, v, guess):
        from . import roots
        ex = _eqs(e)
        if len(ex) != 1:
            raise CalcError("Con un valor inicial (x=…) se resuelve una sola ecuación")
        span = 360.0 if E.settings.angle == "Grado" else (400.0 if E.settings.angle == "Gradián" else 2 * math.pi)
        r = roots.nearest(ex[0], v, float(sp.N(guess)), span)
        if r is None:
            return sp.false
        return ("__info__", (sp.Eq(v, sp.Float(r, 15)), {"decimal": True}))

    def _solve_in(ls, rels):
        """solve(…)|0<x<40: las soluciones en el intervalo (exactas si Giac las da, y numéricas)."""
        from . import giac, roots
        ex = _eqs(ls["e"])
        vs = _vars_of(ls["v"])
        if len(ex) != 1 or len(vs) != 1:
            return _filter_sols(ls["result"], rels)
        v = vs[0]
        lo, hi, los, his, other = -math.inf, math.inf, False, False, []
        for c in rels:
            c = c.reversed if (isinstance(c, sp.Rel) and c.rhs == v and c.lhs != v) else c
            if isinstance(c, (sp.StrictLessThan, sp.LessThan, sp.StrictGreaterThan, sp.GreaterThan)) \
                    and c.lhs == v and c.rhs.is_number:
                b = float(sp.N(c.rhs))
                if isinstance(c, (sp.StrictLessThan, sp.LessThan)):
                    if b < hi or (b == hi and isinstance(c, sp.StrictLessThan)):
                        hi, his = b, isinstance(c, sp.StrictLessThan)
                else:
                    if b > lo or (b == lo and isinstance(c, sp.StrictGreaterThan)):
                        lo, los = b, isinstance(c, sp.StrictGreaterThan)
            else:
                other.append(c)
        exact = []
        try:
            if giac.available() and not units.has_units(ex[0]):
                exact = roots.enumerate_general(giac.solve_general(ex[0], v), v, lo, hi)
        except giac.GiacError:
            exact = []
        if not exact:
            prev = ls["result"]
            exact = [a.rhs for a in (prev.args if isinstance(prev, sp.Or) else [prev])
                     if isinstance(a, sp.Equality) and a.lhs == v]
        span = hi - lo if math.isfinite(hi - lo) else None
        if span is None:                              # intervalo abierto hacia un lado: una ventana
            w = 720.0 if E.settings.angle == "Grado" else (800.0 if E.settings.angle == "Gradián" else 4 * math.pi)
            a = lo if math.isfinite(lo) else (hi - w if math.isfinite(hi) else -w)
            b = hi if math.isfinite(hi) else (lo + w if math.isfinite(lo) else w)
        else:
            a, b = lo, hi
        approx = roots.numeric_roots(ex[0], v, a, b)
        vals = roots.merge(exact, approx, lo, hi, los, his)
        res = [sp.Eq(v, x) for x in vals]
        res = _filter_sols(sp.Or(*res, evaluate=False) if len(res) > 1 else (res[0] if res else sp.false), other)
        return res

    def _filter_sols(r, rels):
        if not rels or r is sp.false:
            return r
        parts = r.args if isinstance(r, sp.Or) else [r]
        keep = []
        for p in parts:
            sub = {a.lhs: a.rhs for a in (p.args if isinstance(p, sp.And) else [p]) if isinstance(a, sp.Equality)}
            ok = True
            for c in rels:
                t = S(c).xreplace(sub)
                if t is sp.false or (t is not sp.true and t.is_number is False and t == sp.false):
                    ok = False
                elif t is not sp.true and t.free_symbols == set():
                    try:
                        ok = ok and bool(t)
                    except TypeError:
                        pass
            if ok:
                keep.append(p)
        if not keep:
            return sp.false
        return keep[0] if len(keep) == 1 else sp.Or(*keep, evaluate=False)

    E.solve_in = _solve_in
    E.filter_sols = _filter_sols
    reg("solve", 2, 2)(lambda e, v: _solve_entry(e, v, False))
    reg("csolve", 2, 2)(lambda e, v: _solve_entry(e, v, True))

    @reg("linsolve", 2, 2)
    def _linsolve(e, v):
        return _solve(e, v, True)

    def _zeros(e, v, cplx):
        vs = list(v) if _is_list(v) else [v]
        if not all(isinstance(a, sp.Symbol) for a in vs):
            raise CalcError("El segundo argumento de zeros es la variable (o una lista de variables)")
        if _is_list(e) or len(vs) > 1:                 # zeros({x+y-3,x-y-1},{x,y}) -> [[2,1]] (TI)
            es = [S(a) for a in (e if _is_list(e) else [e])]
            es = [a.lhs - a.rhs if isinstance(a, sp.Equality) else a for a in es]
            sols = _giac_solve(es, vs, cplx)
            if sols is None:
                sols = sp.solve(es, vs, dict=True)
            rows = [[d.get(a, a) for a in vs] for d in sols]
            if not cplx:
                rows = [r for r in rows if all(_real_ok(x) for x in r)]
            return sp.ImmutableMatrix(rows) if rows else TIList()
        v = vs[0]
        e = S(e)
        ex = e.lhs - e.rhs if isinstance(e, sp.Equality) else e
        gs = _giac_solve([ex], [v], cplx)
        if gs is not None:
            return TIList(d[v] for d in gs if cplx or _real_ok(d[v]))
        sols = sp.solve(ex, v)
        if not cplx:
            sols = [s for s in sols if _real_ok(s)]
        return TIList(sols)

    reg("zeros", 2, 2)(lambda e, v: _zeros(e, v, False))
    reg("czeros", 2, 2)(lambda e, v: _zeros(e, v, True))

    def _nsolve_sys(e, v):
        """nSolve(ec1 and ec2,{x,y}) o con estimaciones {x=1,y=0.5}: Newton desde la estimación."""
        import mpmath
        from . import roots
        eqs = list(e.args) if isinstance(e, sp.And) else ([S(a) for a in e] if _is_list(e) else [e])
        eqs = [a.lhs - a.rhs if isinstance(a, sp.Equality) else S(a) for a in eqs]
        vs, guess = [], []
        for a in (list(v) if _is_list(v) else [v]):
            if isinstance(a, sp.Equality):
                vs.append(a.lhs)
                guess.append(_float(a.rhs))
            elif isinstance(a, sp.Symbol):
                vs.append(a)
                guess.append(None)
            else:
                raise CalcError("nSolve: las variables van como {x,y} o con estimación {x=1,y=2}")
        if len(eqs) != len(vs):
            raise CalcError("nSolve necesita tantas ecuaciones como variables")
        sol = None
        if all(g is not None for g in guess):
            try:
                f = sp.lambdify(vs, eqs, modules="mpmath")
                r = mpmath.findroot(lambda *xs: f(*xs), guess)
                r = [complex(x) for x in (r if hasattr(r, "__len__") else [r])]
                if all(abs(x.imag) < 1e-10 for x in r):
                    sol = {a: sp.Float(x.real, 15) for a, x in zip(vs, r)}
            except (ValueError, ZeroDivisionError, TypeError):
                sol = None
        if sol is None:
            cands = roots.system_roots(eqs, vs)
            if cands:
                g0 = [g if g is not None else 0.0 for g in guess]
                sol = min(cands, key=lambda d: sum((float(d[a]) - g) ** 2 for a, g in zip(vs, g0)))
        if sol is None:
            raise CalcError("nSolve no encontró solución (prueba con otras estimaciones {x=…,y=…})")
        return ("__info__", (sp.And(*[sp.Eq(a, sol[a]) for a in vs], evaluate=False), {"decimal": True}))

    @reg("nsolve", 2, 4)
    def _nsolve(e, v, lo=None, hi=None):
        guess = 0
        if isinstance(e, sp.And) or _is_list(e) or (_is_list(v) and len(list(v)) > 1):
            return _nsolve_sys(e, v)
        if _is_list(v) and len(list(v)) == 1:
            v = list(v)[0]
        e = S(e)
        if isinstance(v, sp.Equality):
            v, guess = v.lhs, v.rhs
        ex = e.lhs - e.rhs if isinstance(e, sp.Equality) else e
        try:
            if lo is not None and hi is not None:
                r = sp.nsolve(ex, v, (_float(lo), _float(hi)), solver="bisect")
            else:
                r = sp.nsolve(ex, v, _float(guess))
        except (ValueError, ZeroDivisionError):
            raise CalcError("nSolve no encontró solución cerca de %s" % guess)
        return ("__info__", (r, {"decimal": True}))

    @reg("completesquare", 2, 2)
    def _csq(e, v):
        e = S(e)
        p = sp.Poly(e, v)
        if p.degree() != 2:
            raise CalcError("completeSquare es para expresiones de grado 2")
        a, b, c = p.all_coeffs()
        return a * (v + b / (2 * a)) ** 2 + (c - b ** 2 / (4 * a))

    def _lr(e, n, left):
        if isinstance(e, str):
            k = len(e) if n is None else max(0, _int(n))
            return e[:k] if left else (e[len(e) - k:] if k else "")
        if _is_list(e):
            k = len(e) if n is None else max(0, _int(n))
            return TIList(list(e)[:k] if left else (list(e)[len(e) - k:] if k else []))
        e = S(e)
        if not isinstance(e, sp.Rel):
            raise CalcError("left/right: usa una lista, un texto o una ecuación")
        return e.lhs if left else e.rhs

    reg("left", 1, 2)(lambda e, n=None: _lr(e, n, True))
    reg("right", 1, 2)(lambda e, n=None: _lr(e, n, False))

    reg("texpand", 1, 1, mapped=True)(lambda x: sp.expand_trig(S(x)))
    reg("tcollect", 1, 1, mapped=True)(lambda x: sp.trigsimp(S(x)))

    def _polyvar(p, v):
        p = S(p)
        if v is None:
            fs = sorted(p.free_symbols, key=str)
            if len(fs) != 1:
                raise CalcError("Indica la variable del polinomio")
            v = fs[0]
        return p, v

    @reg("polyroots", 1, 2)
    def _polyroots(p, v=None):
        p, v = _polyvar(p, v)
        return TIList(sorted([r for r in sp.Poly(p, v).nroots() if abs(sp.im(r)) < 1e-12],
                             key=lambda r: float(sp.re(r))))

    @reg("cpolyroots", 1, 2)
    def _cpolyroots(p, v=None):
        p, v = _polyvar(p, v)
        return TIList(sp.Poly(p, v).nroots())

    reg("polycoeffs", 1, 2)(lambda p, v=None: TIList(sp.Poly(*_polyvar(p, v)).all_coeffs()))
    reg("polydegree", 1, 2)(lambda p, v=None: sp.Integer(sp.Poly(*_polyvar(p, v)).degree()))
    reg("polyquotient", 2, 3)(lambda p, q, v=None: sp.div(S(p), S(q), *([v] if v is not None else []))[0])
    reg("polyremainder", 2, 3)(lambda p, q, v=None: sp.div(S(p), S(q), *([v] if v is not None else []))[1])
    reg("polygcd", 2, 2)(lambda p, q: sp.gcd(S(p), S(q)))

    # ---- cálculo
    @reg("derivative deriv diff", 2, 3)
    def _der(e, v, n=1):
        if isinstance(v, sp.Equality):
            var, at = v.lhs, v.rhs
            return bmap(lambda x: sp.diff(S(x), var, _int(n)).subs(var, at), e)
        def d1(x):
            x = S(x)
            if isinstance(v, sp.Symbol) and x.has(sp.Abs, sp.sign):
                r = sp.Dummy(v.name, real=True)          # d/dx(|x|) = sign(x), no re/im
                return tidy_calc(sp.diff(x.xreplace({v: r}), r, _int(n)).xreplace({r: v}))
            return tidy_calc(sp.diff(x, v, _int(n)))
        return bmap(d1, e)

    @reg("integral integrate", 2, 4)
    def _int_(e, v, a=None, b=None):
        def f(x):
            x = S(x)
            if a is None:
                if isinstance(v, sp.Symbol) and x.has(sp.Abs, sp.sign):
                    rr = sp.Dummy(v.name, real=True)     # ∫|x|dx por tramos
                    r = sp.integrate(x.xreplace({v: rr}), rr).xreplace({rr: v})
                else:
                    r = sp.integrate(x, v)
            else:
                r = sp.integrate(x, (v, a, b))
            if r.has(sp.Integral):
                if a is not None:
                    return sp.Float(sp.N(sp.Integral(x, (v, a, b))), 15)
                from . import giac
                try:
                    if giac.available() and not units.has_units(x):
                        return tidy_calc(giac.integrate(x, v))
                except giac.GiacError:
                    pass
                raise CalcError("No encontré una primitiva exacta")
            return tidy_calc(r)
        return bmap(f, e)

    reg("nint", 4, 4)(lambda e, v, a, b: sp.Float(sp.N(sp.Integral(S(e), (v, a, b))), 15))

    @reg("limit lim", 3, 4)
    def _limit(e, v, a, d=None):
        dirn = "+-"
        if d is not None:
            dirn = "+" if _float(d) > 0 else "-"
        try:
            return sp.limit(S(e), v, a, dirn)
        except ValueError:
            l1, l2 = sp.limit(S(e), v, a, "+"), sp.limit(S(e), v, a, "-")
            return l1 if l1 == l2 else sp.nan

    @reg("sum_", 4, 4)
    def _sigma(e, k, a, b):
        return sp.summation(S(e), (k, a, b)).doit()

    @reg("product_", 4, 4)
    def _pi(e, k, a, b):
        return sp.product(S(e), (k, a, b)).doit()

    def _ext(e, v, a, b, mx):
        e = S(e)
        lo = a if a is not None else -sp.oo
        hi = b if b is not None else sp.oo
        cands = [c for c in sp.solve(sp.diff(e, v), v) if _real_ok(c)]
        cands = [c for c in cands if (lo == -sp.oo or c >= lo) and (hi == sp.oo or c <= hi)]
        if a is not None:
            cands += [lo]
        if b is not None:
            cands += [hi]
        if not cands:
            raise CalcError("No encontré un %s" % ("máximo" if mx else "mínimo"))
        vals = [(e.subs(v, c), c) for c in cands]
        best = (max if mx else min)(vals, key=lambda t: float(sp.N(t[0])))
        return sp.Eq(v, best[1])

    reg("fmin", 2, 4)(lambda e, v, a=None, b=None: _ext(e, v, a, b, False))
    reg("fmax", 2, 4)(lambda e, v, a=None, b=None: _ext(e, v, a, b, True))

    @reg("tangentline", 3, 3)
    def _tan(e, v, p):
        e = S(e)
        m = sp.diff(e, v).subs(v, p)
        return sp.expand(m * (v - p) + e.subs(v, p))

    @reg("normalline", 3, 3)
    def _norm(e, v, p):
        e = S(e)
        m = sp.diff(e, v).subs(v, p)
        if m == 0:
            raise CalcError("La normal es vertical (x=%s)" % p)
        return sp.expand(-(v - p) / m + e.subs(v, p))

    @reg("arclen", 4, 4)
    def _arclen(e, v, a, b):
        x = sp.integrate(sp.sqrt(1 + sp.diff(S(e), v) ** 2), (v, a, b))
        return x if not x.has(sp.Integral) else sp.Float(sp.N(x), 15)

    @reg("taylor", 3, 4)
    def _taylor(e, v, n, p=0):
        return sp.series(S(e), v, p, _int(n) + 1).removeO()

    @reg("series", 3, 4)
    def _series(e, v, n, p=0):
        return sp.series(S(e), v, p, _int(n) + 1).removeO()

    reg("dominantterm", 2, 3)(lambda e, v, p=0: sp.series(S(e), v, p, 2).removeO().as_ordered_terms()[0])

    @reg("impdif", 3, 4)
    def _impdif(eq, x, y, n=1):
        eq = S(eq)
        F_ = eq.lhs - eq.rhs if isinstance(eq, sp.Equality) else eq
        return sp.simplify(sp.idiff(F_, y, x, _int(n)))

    @reg("nderivative", 2, 3)
    def _nder(e, veq, n=1):
        if not isinstance(veq, sp.Equality):
            raise CalcError("Usa nDerivative(expr, x=valor)")
        return sp.Float(sp.N(sp.diff(S(e), veq.lhs, _int(n)).subs(veq.lhs, veq.rhs)), 15)

    @reg("centraldiff", 2, 3)
    def _cdiff(e, v, h=sp.Rational(1, 1000)):
        if isinstance(v, sp.Equality):
            var, at = v.lhs, v.rhs
            return (S(e).subs(var, at + h) - S(e).subs(var, at - h)) / (2 * h)
        return (S(e).subs(v, v + h) - S(e).subs(v, v - h)) / (2 * h)

    # ---- probabilidad
    reg("ncr", 2, 2)(lambda n, r: bcast(lambda a, b: sp.expand_func(sp.binomial(a, b)) if (
        not S(a).is_number and S(b).is_Integer) else sp.binomial(a, b), n, r))
    reg("npr", 2, 2)(lambda n, r: bcast(lambda a, b: sp.FallingFactorial(a, b), n, r))
    reg("rand", 0, 1)(lambda n=None: (sp.Float(random.random(), 15) if n is None
                                      else TIList(sp.Float(random.random(), 15) for _ in range(_int(n)))))
    reg("randint", 2, 3)(lambda a, b, n=None: (sp.Integer(random.randint(_int(a), _int(b))) if n is None
                                               else TIList(sp.Integer(random.randint(_int(a), _int(b)))
                                                           for _ in range(_int(n)))))
    reg("randnorm", 2, 3)(lambda mu, s_, n=None: sp.Float(random.gauss(_float(mu), _float(s_)), 15))

    import mpmath as mp

    def _f(x):
        return ("__info__", (sp.Float(x, 15), {"decimal": True}))

    reg("normpdf", 1, 3)(lambda x, mu=0, s_=1: _f(mp.npdf(_float(x), _float(mu), _float(s_))))
    reg("normcdf", 2, 4)(lambda a, b, mu=0, s_=1: _f(mp.ncdf(_float(b) if b != -sp.oo else -mp.inf, _float(mu), _float(s_))
                                                    - mp.ncdf(_float(a) if a != -sp.oo else -mp.inf, _float(mu), _float(s_))))

    @reg("invnorm", 1, 3)
    def _invnorm(p, mu=0, s_=1):
        return _f(_float(mu) + _float(s_) * mp.sqrt(2) * mp.erfinv(2 * _float(p) - 1))

    def _tcdf(x, df):
        x = mp.mpf(x)
        return 1 - mp.betainc(df / 2, mp.mpf(1) / 2, 0, df / (df + x * x), regularized=True) / 2 if x >= 0 \
            else mp.betainc(df / 2, mp.mpf(1) / 2, 0, df / (df + x * x), regularized=True) / 2

    reg("tpdf", 2, 2)(lambda x, df: _f(mp.gamma((_float(df) + 1) / 2) / (mp.sqrt(_float(df) * mp.pi) * mp.gamma(_float(df) / 2))
                                       * (1 + _float(x) ** 2 / _float(df)) ** (-(_float(df) + 1) / 2)))
    reg("tcdf", 3, 3)(lambda a, b, df: _f(_tcdf(_float(b), _float(df)) - _tcdf(_float(a), _float(df))))
    reg("invt", 2, 2)(lambda p, df: _f(mp.findroot(lambda x: _tcdf(x, _float(df)) - _float(p), 0)))

    def _chicdf(x, df):
        return mp.gammainc(df / 2, 0, x / 2, regularized=True) if x > 0 else 0

    reg("chi2pdf", 2, 2)(lambda x, df: _f(mp.mpf(_float(x)) ** (_float(df) / 2 - 1) * mp.exp(-_float(x) / 2)
                                                / (2 ** (_float(df) / 2) * mp.gamma(_float(df) / 2))))
    reg("chi2cdf", 3, 3)(lambda a, b, df: _f(_chicdf(_float(b), _float(df)) - _chicdf(_float(a), _float(df))))

    @reg("binompdf", 2, 3)
    def _binompdf(n, p, x=None):
        n_ = _int(n)
        if x is None:
            return TIList(sp.Float(mp.binomial(n_, k) * _float(p) ** k * (1 - _float(p)) ** (n_ - k), 15) for k in range(n_ + 1))
        return _f(mp.binomial(n_, _int(x)) * _float(p) ** _int(x) * (1 - _float(p)) ** (n_ - _int(x)))

    @reg("binomcdf", 2, 4)
    def _binomcdf(n, p, lo=None, hi=None):
        n_ = _int(n)
        if lo is not None and hi is None:
            lo, hi = 0, lo
        lo = 0 if lo is None else _int(lo)
        hi = n_ if hi is None else _int(hi)
        return _f(sum(mp.binomial(n_, k) * _float(p) ** k * (1 - _float(p)) ** (n_ - k) for k in range(lo, hi + 1)))

    reg("poisspdf", 2, 2)(lambda lam, x: _f(mp.exp(-_float(lam)) * _float(lam) ** _int(x) / mp.factorial(_int(x))))
    reg("poisscdf", 2, 3)(lambda lam, a, b=None: _f(sum(mp.exp(-_float(lam)) * _float(lam) ** k / mp.factorial(k)
                                                       for k in (range(0, _int(a) + 1) if b is None
                                                                 else range(_int(a), _int(b) + 1)))))
    reg("geompdf", 2, 2)(lambda p, x: _f(_float(p) * (1 - _float(p)) ** (_int(x) - 1)))
    reg("geomcdf", 2, 3)(lambda p, a, b=None: _f((1 - (1 - _float(p)) ** _int(a)) if b is None
                                                 else ((1 - _float(p)) ** (_int(a) - 1) - (1 - _float(p)) ** _int(b))))

    # ---- listas y estadística
    def _lst(x):
        if _is_list(x):
            return list(x)
        if isinstance(x, sp.MatrixBase):
            return list(x)
        raise CalcError("Se esperaba una lista {…}")

    def _mean(x, fr=None):
        xs = _lst(x)
        if fr is None:
            return sp.Add(*xs) / len(xs)
        fs = _lst(fr)
        if len(fs) != len(xs):
            raise CalcError("La lista de frecuencias debe tener el mismo largo")
        return sp.Add(*[a * b for a, b in zip(xs, fs)]) / sp.Add(*fs)

    reg("mean", 1, 2)(_mean)
    reg("median", 1, 1)(lambda x: _median(_lst(x)))
    reg("sum", 1, 1)(lambda x: sp.Add(*_lst(x)))
    reg("product prod", 1, 3)(lambda x, a=None, b=None: sp.Mul(*_lst(x)[(_int(a) - 1 if a else 0):(_int(b) if b else None)]))
    reg("min", 1, 2)(lambda a, b=None: sp.Min(*_lst(a)) if b is None else bcast(sp.Min, a, b))
    reg("max", 1, 2)(lambda a, b=None: sp.Max(*_lst(a)) if b is None else bcast(sp.Max, a, b))

    def _var(x, pop):
        L = _lst(x)
        m_ = sp.Add(*L) / len(L)
        return sp.Add(*[(v - m_) ** 2 for v in L]) / (len(L) - (0 if pop else 1))

    reg("varsamp", 1, 1)(lambda x: sp.simplify(_var(x, False)))
    reg("varpop", 1, 1)(lambda x: sp.simplify(_var(x, True)))
    reg("stdevsamp", 1, 1)(lambda x: sp.sqrt(sp.simplify(_var(x, False))))
    reg("stdevpop", 1, 1)(lambda x: sp.sqrt(sp.simplify(_var(x, True))))

    # ---- estadística y regresiones (como la TI: OneVar, TwoVar, LinRegMx…)
    def _nums(x, what="lista"):
        L = _lst(x)
        try:
            return [float(sp.N(v)) for v in L]
        except (TypeError, ValueError):
            raise CalcError("La %s debe tener solo números" % what)

    def _freq(xs, fr):
        if fr is None:
            return xs, [1.0] * len(xs)
        fl = _nums(fr, "lista de frecuencias")
        if len(fl) != len(xs):
            raise CalcError("La lista de frecuencias debe tener el mismo largo")
        return xs, fl

    def _quart(v):
        v = sorted(v)
        n = len(v)
        med = _med(v)
        lo, hi = v[: n // 2], v[(n + 1) // 2:]
        return (_med(lo) if lo else med), med, (_med(hi) if hi else med)

    def _med(v):
        n = len(v)
        return v[n // 2] if n % 2 else (v[n // 2 - 1] + v[n // 2]) / 2

    def _F(x):
        return sp.Float(x, 15)

    def _stat(rep):
        E.last_stat = Report(rep)
        return E.last_stat

    @reg("onevar", 1, 2)
    def _onevar(x, fr=None):
        xs, fl = _freq(_nums(x), fr)
        exp = [v for v, f in zip(xs, fl) for _ in range(int(round(f)))]
        n = sum(fl)
        if n == 0:
            raise CalcError("La lista está vacía")
        sx_ = sum(v * f for v, f in zip(xs, fl))
        sxx = sum(v * v * f for v, f in zip(xs, fl))
        m = sx_ / n
        ss = sum(f * (v - m) ** 2 for v, f in zip(xs, fl))
        q1, med, q3 = _quart(exp or xs)
        return _stat([("x̄", _F(m)), ("Σx", _F(sx_)), ("Σx²", _F(sxx)),
                      ("sx", _F(math.sqrt(ss / (n - 1))) if n > 1 else sp.nan), ("σx", _F(math.sqrt(ss / n))),
                      ("n", _F(n)), ("MinX", _F(min(xs))), ("Q₁X", _F(q1)), ("MedianX", _F(med)),
                      ("Q₃X", _F(q3)), ("MaxX", _F(max(xs))), ("SSX", _F(ss))])

    def _xy(X, Yl):
        xs, ys = _nums(X, "lista X"), _nums(Yl, "lista Y")
        if len(xs) != len(ys):
            raise CalcError("Las listas X e Y deben tener el mismo largo")
        if len(xs) < 2:
            raise CalcError("Se necesitan al menos 2 datos")
        return xs, ys

    @reg("twovar", 2, 2)
    def _twovar(X, Yl):
        xs, ys = _xy(X, Yl)
        n = len(xs)
        mx, my = sum(xs) / n, sum(ys) / n
        ssx = sum((v - mx) ** 2 for v in xs)
        ssy = sum((v - my) ** 2 for v in ys)
        sxy = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
        r = sxy / math.sqrt(ssx * ssy) if ssx and ssy else float("nan")
        return _stat([("x̄", _F(mx)), ("Σx", _F(sum(xs))), ("Σx²", _F(sum(v * v for v in xs))),
                      ("sx", _F(math.sqrt(ssx / (n - 1)))), ("σx", _F(math.sqrt(ssx / n))), ("n", _F(n)),
                      ("ȳ", _F(my)), ("Σy", _F(sum(ys))), ("Σy²", _F(sum(v * v for v in ys))),
                      ("sy", _F(math.sqrt(ssy / (n - 1)))), ("σy", _F(math.sqrt(ssy / n))),
                      ("Σxy", _F(sum(a * b for a, b in zip(xs, ys)))), ("r", _F(r)),
                      ("MinX", _F(min(xs))), ("MaxX", _F(max(xs))), ("MinY", _F(min(ys))), ("MaxY", _F(max(ys)))])

    XS = sp.Symbol("x")

    def _save_eq(expr):
        E.funcs["regeqn"] = ([XS], expr)
        E.names["regeqn"] = "RegEqn"

    def _r(xs, ys):
        n = len(xs)
        mx, my = sum(xs) / n, sum(ys) / n
        sxy = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
        ssx = sum((a - mx) ** 2 for a in xs)
        ssy = sum((b - my) ** 2 for b in ys)
        return sxy / math.sqrt(ssx * ssy) if ssx and ssy else float("nan")

    def _poly(X, Yl, deg, names):
        import numpy as np
        xs, ys = _xy(X, Yl)
        if len(xs) <= deg:
            raise CalcError("Se necesitan al menos %d datos" % (deg + 1))
        c = np.polyfit(xs, ys, deg)
        big = max(1e-300, float(np.max(np.abs(c))))
        c = np.where(np.abs(c) < 1e-10 * big, 0.0, c)               # ruido numérico -> 0
        pred = np.polyval(c, xs)
        ssr = float(np.sum((np.array(ys) - pred) ** 2))
        sst = float(np.sum((np.array(ys) - np.mean(ys)) ** 2))
        r2 = 1 - ssr / sst if sst else 1.0
        expr = sp.Add(*[_F(ci) * XS ** (deg - i) for i, ci in enumerate(c)])
        _save_eq(expr)
        out = [("RegEqn", expr)] + [(nm, _F(ci)) for nm, ci in zip(names, c)]
        return c, r2, out

    @reg("linregmx", 2, 2)
    def _linregmx(X, Yl):
        xs, ys = _xy(X, Yl)
        c, r2, out = _poly(X, Yl, 1, ["m", "b"])
        r = _r(xs, ys)
        return _stat(out + [("r²", _F(r * r)), ("r", _F(r))])

    @reg("linregbx", 2, 2)
    def _linregbx(X, Yl):
        xs, ys = _xy(X, Yl)
        c, r2, out = _poly(X, Yl, 1, ["b", "a"])
        expr = _F(c[1]) + _F(c[0]) * XS
        _save_eq(expr)
        r = _r(xs, ys)
        return _stat([("RegEqn", expr), ("a", _F(c[1])), ("b", _F(c[0])), ("r²", _F(r * r)), ("r", _F(r))])

    for _nm, _deg, _ls in (("quadreg", 2, "abc"), ("cubicreg", 3, "abcd"), ("quartreg", 4, "abcde")):
        def _mk(deg=_deg, ls=_ls):
            def f(X, Yl):
                c, r2, out = _poly(X, Yl, deg, list(ls))
                return _stat(out + [("R²", _F(r2))])
            return f
        reg(_nm, 2, 2)(_mk())

    def _translin(X, Yl, tx, ty, what):
        xs, ys = _xy(X, Yl)
        try:
            u = [tx(v) for v in xs]
            w = [ty(v) for v in ys]
        except ValueError:
            raise CalcError("Para %s los datos deben ser positivos" % what)
        n = len(u)
        mu, mw = sum(u) / n, sum(w) / n
        b = sum((a - mu) * (c - mw) for a, c in zip(u, w)) / sum((a - mu) ** 2 for a in u)
        a = mw - b * mu
        r = _r(u, w)
        return a, b, r

    @reg("powerreg", 2, 2)
    def _powerreg(X, Yl):
        a, b, r = _translin(X, Yl, math.log, math.log, "PowerReg")
        expr = _F(math.exp(a)) * XS ** _F(b)
        _save_eq(expr)
        return _stat([("RegEqn", expr), ("a", _F(math.exp(a))), ("b", _F(b)), ("r²", _F(r * r)), ("r", _F(r))])

    @reg("expreg", 2, 2)
    def _expreg(X, Yl):
        a, b, r = _translin(X, Yl, lambda v: v, math.log, "ExpReg")
        expr = _F(math.exp(a)) * _F(math.exp(b)) ** XS
        _save_eq(expr)
        return _stat([("RegEqn", expr), ("a", _F(math.exp(a))), ("b", _F(math.exp(b))), ("r²", _F(r * r)), ("r", _F(r))])

    @reg("lnreg", 2, 2)
    def _lnreg(X, Yl):
        a, b, r = _translin(X, Yl, math.log, lambda v: v, "LnReg")
        expr = _F(a) + _F(b) * sp.log(XS)
        _save_eq(expr)
        return _stat([("RegEqn", expr), ("a", _F(a)), ("b", _F(b)), ("r²", _F(r * r)), ("r", _F(r))])

    def _lm(model, p0, xs, ys, it=200):
        """Levenberg–Marquardt simple (sin SciPy)."""
        import numpy as np
        p = np.array(p0, float)
        X, Yv = np.array(xs, float), np.array(ys, float)
        lam = 1e-3

        def res(pp):
            with np.errstate(all="ignore"):
                return model(X, pp) - Yv
        r = res(p)
        cost = float(np.sum(r * r))
        for _ in range(it):
            J = np.empty((len(X), len(p)))
            for k in range(len(p)):
                h = 1e-7 * max(1.0, abs(p[k]))
                dp = p.copy()
                dp[k] += h
                J[:, k] = (res(dp) - r) / h
            A = J.T @ J
            g = J.T @ r
            try:
                step = np.linalg.solve(A + lam * np.diag(np.diag(A) + 1e-12), -g)
            except np.linalg.LinAlgError:
                break
            pn = p + step
            rn = res(pn)
            cn = float(np.sum(rn * rn))
            if np.isfinite(cn) and cn < cost:
                p, r, cost = pn, rn, cn
                lam = max(lam / 3, 1e-12)
                if np.max(np.abs(step)) < 1e-12 * (1 + np.max(np.abs(p))):
                    break
            else:
                lam *= 4
                if lam > 1e12:
                    break
        return p, cost

    def _r2(ys, cost):
        my = sum(ys) / len(ys)
        sst = sum((v - my) ** 2 for v in ys)
        return 1 - cost / sst if sst else 1.0

    @reg("medmed", 2, 2)
    def _medmed(X, Yl):
        xs, ys = _xy(X, Yl)
        pts = sorted(zip(xs, ys))
        n = len(pts)
        if n < 3:
            raise CalcError("Se necesitan al menos 3 datos")
        k, rem = divmod(n, 3)
        sizes = [k, k + 1, k] if rem == 1 else [k + 1, k, k + 1] if rem == 2 else [k, k, k]
        g1, g2, g3 = pts[:sizes[0]], pts[sizes[0]:sizes[0] + sizes[1]], pts[sizes[0] + sizes[1]:]
        md = [(_med(sorted(p[0] for p in g)), _med(sorted(p[1] for p in g))) for g in (g1, g2, g3)]
        m = (md[2][1] - md[0][1]) / (md[2][0] - md[0][0])
        b = sum(y - m * x for x, y in md) / 3
        expr = _F(m) * XS + _F(b)
        _save_eq(expr)
        return _stat([("RegEqn", expr), ("m", _F(m)), ("b", _F(b))])

    @reg("sinreg", 2, 2)
    def _sinreg(X, Yl):
        import numpy as np
        xs, ys = _xy(X, Yl)
        if len(xs) < 4:
            raise CalcError("Se necesitan al menos 4 datos")
        Xa, Ya = np.array(xs), np.array(ys)
        span = max(xs) - min(xs) or 1.0
        best = None
        for bb in np.linspace(2 * math.pi / span * 0.25, 2 * math.pi / span * len(xs) / 2, 400):
            M = np.column_stack([np.sin(bb * Xa), np.cos(bb * Xa), np.ones_like(Xa)])
            c, *_ = np.linalg.lstsq(M, Ya, rcond=None)
            rr = float(np.sum((M @ c - Ya) ** 2))
            if best is None or rr < best[0]:
                best = (rr, bb, c)
        _rr, bb, (cs, cc, dd) = best
        a0, c0 = math.hypot(cs, cc), math.atan2(cc, cs)
        pp, cost = _lm(lambda x_, p_: p_[0] * np.sin(p_[1] * x_ + p_[2]) + p_[3], [a0, bb, c0, dd], xs, ys)
        a, b, c, d = (float(v) for v in pp)
        if a < 0:
            a, c = -a, c + math.pi
        c = (c + math.pi) % (2 * math.pi) - math.pi
        expr = _F(a) * sp.sin(_F(b) * XS + _F(c)) + _F(d)
        _save_eq(expr)
        k = 180 / math.pi if E.settings.angle == "Grado" else 200 / math.pi if E.settings.angle == "Gradián" else 1
        return _stat([("RegEqn", expr), ("a", _F(a)), ("b", _F(b * k)), ("c", _F(c * k)), ("d", _F(d))])

    def _logistic(X, Yl, withd):
        import numpy as np
        xs, ys = _xy(X, Yl)
        Ya = np.array(ys)
        d0 = float(min(ys)) - 1e-3 * (abs(min(ys)) + 1) if withd else 0.0
        c0 = (float(max(ys)) - d0) * 1.05
        z = np.log(np.clip(c0 / np.clip(Ya - d0, 1e-12, None) - 1, 1e-12, None))
        bb, la = np.polyfit(xs, z, 1)
        p0 = [math.exp(la), -bb, c0] + ([d0] if withd else [])
        if withd:
            model = lambda x_, p_: p_[2] / (1 + p_[0] * np.exp(-p_[1] * x_)) + p_[3]  # noqa: E731
        else:
            model = lambda x_, p_: p_[2] / (1 + p_[0] * np.exp(-p_[1] * x_))  # noqa: E731
        pp, cost = _lm(model, p0, xs, ys)
        a, b, c = (float(v) for v in pp[:3])
        expr = _F(c) / (1 + _F(a) * sp.exp(-_F(b) * XS))
        out = [("a", _F(a)), ("b", _F(b)), ("c", _F(c))]
        if withd:
            expr = expr + _F(float(pp[3]))
            out.append(("d", _F(float(pp[3]))))
        _save_eq(expr)
        return _stat([("RegEqn", expr)] + out)

    reg("logistic", 2, 2)(lambda X, Yl: _logistic(X, Yl, False))
    reg("logisticd", 2, 2)(lambda X, Yl: _logistic(X, Yl, True))

    @reg("multreg", 2, None)
    def _multreg(Yl, *Xs):
        import numpy as np
        ys = _nums(Yl, "lista Y")
        cols = [_nums(x, "lista X") for x in Xs]
        if any(len(c) != len(ys) for c in cols):
            raise CalcError("Todas las listas deben tener el mismo largo")
        M = np.column_stack([np.ones(len(ys))] + [np.array(c) for c in cols])
        coef, *_ = np.linalg.lstsq(M, np.array(ys), rcond=None)
        pred = M @ coef
        ssr = float(np.sum((np.array(ys) - pred) ** 2))
        r2 = _r2(ys, ssr)
        xsy = [sp.Symbol("x%d" % (i + 1)) for i in range(len(cols))]
        expr = _F(coef[0]) + sp.Add(*[_F(c) * v for c, v in zip(coef[1:], xsy)])
        return _stat([("RegEqn", expr)] + [("b%d" % i, _F(c)) for i, c in enumerate(coef)] + [("R²", _F(r2))])

    @reg("corrmat", 2, None)
    def _corrmat(*Ls):
        import numpy as np
        cols = [_nums(x) for x in Ls]
        if any(len(c) != len(cols[0]) for c in cols):
            raise CalcError("Todas las listas deben tener el mismo largo")
        C = np.corrcoef(np.array(cols))
        return sp.ImmutableMatrix([[_F(v) for v in row] for row in C])

    @reg("statresults", 0, 0)
    def _statres():
        if getattr(E, "last_stat", None) is None:
            raise CalcError("Todavía no hay resultados estadísticos (usa OneVar, LinRegMx…)")
        return E.last_stat

    # ---- distribuciones que faltaban
    def _bisect(fn, target, lo, hi, it=200):
        for _ in range(it):
            m = (lo + hi) / 2
            if fn(m) < target:
                lo = m
            else:
                hi = m
        return (lo + hi) / 2

    reg("invchi2", 2, 2)(lambda p, df: _f(_bisect(lambda x: float(_chicdf(x, _float(df))), _float(p), 0, 1e6)))

    def _fcdf(x, d1, d2):
        return mp.betainc(d1 / 2, d2 / 2, 0, d1 * x / (d1 * x + d2), regularized=True) if x > 0 else 0

    reg("fpdf", 3, 3)(lambda x, d1, d2: _f(mp.sqrt((_float(d1) * _float(x)) ** _float(d1) * _float(d2) ** _float(d2)
                                                    / (_float(d1) * _float(x) + _float(d2)) ** (_float(d1) + _float(d2)))
                                            / (_float(x) * mp.beta(_float(d1) / 2, _float(d2) / 2))))
    reg("fcdf", 4, 4)(lambda a, b, d1, d2: _f(_fcdf(_float(b), _float(d1), _float(d2)) - _fcdf(_float(a), _float(d1), _float(d2))))
    reg("invf", 3, 3)(lambda p, d1, d2: _f(_bisect(lambda x: float(_fcdf(x, _float(d1), _float(d2))), _float(p), 0, 1e6)))

    @reg("invbinom", 3, 3)
    def _invbinom(cum, n, p):
        n_, pp, c = _int(n), _float(p), _float(cum)
        acc = 0
        for k in range(n_ + 1):
            acc += float(mp.binomial(n_, k)) * pp ** k * (1 - pp) ** (n_ - k)
            if acc >= c - 1e-12:
                return sp.Integer(k)
        return sp.Integer(n_)

    # ---- finanzas (menú 8, como la TI)
    from . import finance as fin

    def _fl(*a):
        return [None if v is None else _float(v) for v in a]

    def _fopt(PpY, CpY, PmtAt):
        p = 1.0 if PpY is None else _float(PpY)
        return p, (p if CpY is None else _float(CpY)), (0 if PmtAt is None else int(_float(PmtAt)))

    def _fin(fn):
        def g(*a):
            try:
                return _F(fn(*a))
            except fin.FinError as ex:
                raise CalcError(str(ex))
            except (OverflowError, ZeroDivisionError):
                raise CalcError("No hay solución con esos valores")
        return g

    reg("tvmfv", 4, 7)(_fin(lambda N, I, PV, Pmt, PpY=None, CpY=None, PmtAt=None:
                            fin.tvm_fv(*_fl(N, I, PV, Pmt), *_fopt(PpY, CpY, PmtAt))))
    reg("tvmpv", 4, 7)(_fin(lambda N, I, Pmt, FV, PpY=None, CpY=None, PmtAt=None:
                            fin.tvm_pv(*_fl(N, I, Pmt, FV), *_fopt(PpY, CpY, PmtAt))))
    reg("tvmpmt", 4, 7)(_fin(lambda N, I, PV, FV, PpY=None, CpY=None, PmtAt=None:
                             fin.tvm_pmt(*_fl(N, I, PV, FV), *_fopt(PpY, CpY, PmtAt))))
    reg("tvmn", 4, 7)(_fin(lambda I, PV, Pmt, FV, PpY=None, CpY=None, PmtAt=None:
                           fin.tvm_n(*_fl(I, PV, Pmt, FV), *_fopt(PpY, CpY, PmtAt))))
    reg("tvmi", 4, 7)(_fin(lambda N, PV, Pmt, FV, PpY=None, CpY=None, PmtAt=None:
                           fin.tvm_i(*_fl(N, PV, Pmt, FV), *_fopt(PpY, CpY, PmtAt))))

    def _amort(NPmt, N, I, PV, Pmt=None, FV=None, PpY=None, CpY=None, PmtAt=None, rnd=None):
        p, c, at = _fopt(PpY, CpY, PmtAt)
        try:
            return fin.amort(_float(NPmt), _float(N), _float(I), _float(PV),
                             None if Pmt is None else _float(Pmt), 0.0 if FV is None else _float(FV),
                             p, c, at, 2 if rnd is None else int(_float(rnd)))
        except fin.FinError as ex:
            raise CalcError(str(ex))

    reg("amorttbl", 4, 10)(lambda *a: sp.ImmutableMatrix([[sp.Integer(r[0]), _F(r[1]), _F(r[2]), _F(r[3])]
                                                          for r in _amort(*a)[1:]]))
    reg("bal", 4, 10)(lambda *a: _F(_amort(*a)[-1][3]))
    reg("sigmaint", 5, 11)(lambda n1, n2, *a: _F(sum(r[1] for r in _amort(n2, *a)[int(_float(n1)):])))
    reg("sigmaprn", 5, 11)(lambda n1, n2, *a: _F(sum(r[2] for r in _amort(n2, *a)[int(_float(n1)):])))
    reg("npv", 3, 4)(_fin(lambda r, cf0, cfs, fr=None: fin.npv(_float(r), _float(cf0), _nums(cfs),
                                                               None if fr is None else _nums(fr))))
    reg("irr", 2, 3)(_fin(lambda cf0, cfs, fr=None: fin.irr(_float(cf0), _nums(cfs), None if fr is None else _nums(fr))))
    reg("mirr", 4, 5)(_fin(lambda f_, r_, cf0, cfs, fr=None: fin.mirr(_float(f_), _float(r_), _float(cf0), _nums(cfs),
                                                                      None if fr is None else _nums(fr))))
    reg("nom", 2, 2)(_fin(lambda e_, c: fin.nom(_float(e_), _float(c))))
    reg("eff", 2, 2)(_fin(lambda n_, c: fin.eff(_float(n_), _float(c))))
    reg("dbd", 2, 2)(lambda a, b: sp.Integer(fin.dbd(_float(a), _float(b))))

    @reg("seq", 4, 5)
    def _seq(e, v, a, b, step=1):
        out = []
        k = S(a)
        guard = 0
        while (k <= b if step > 0 else k >= b) and guard < 10000:
            out.append(S(e).subs(v, k))
            k += step
            guard += 1
        return TIList(out)

    @reg("cumulativesum cumsum", 1, 1)
    def _cumsum(x):
        acc, out = 0, []
        for v in _lst(x):
            acc += v
            out.append(acc)
        return TIList(out)

    reg("deltalist δlist", 1, 1)(lambda x: TIList(b - a for a, b in zip(_lst(x), _lst(x)[1:])))
    reg("sorta", 1, 1)(lambda x: TIList(sorted(_lst(x), key=lambda v: float(sp.N(v)))))
    reg("sortd", 1, 1)(lambda x: TIList(sorted(_lst(x), key=lambda v: -float(sp.N(v)))))

    # ---- textos y listas (como la TI)
    def _seq_of(x, what):
        if isinstance(x, str):
            return x
        if _is_list(x):
            return list(x)
        raise CalcError("%s necesita una lista o un texto" % what)

    @reg("mid", 2, 3)
    def _mid(x, a, n=None):
        v = _seq_of(x, "mid")
        i = _int(a) - 1
        if i < 0:
            raise CalcError("mid: la posición empieza en 1")
        out = v[i:] if n is None else v[i:i + max(0, _int(n))]
        return out if isinstance(v, str) else TIList(out)

    @reg("rotate", 1, 2)
    def _rotate(x, n=None):
        if isinstance(x, sp.Integer) or (isinstance(x, sp.Basic) and x.is_Integer):
            k = -1 if n is None else _int(n)            # rotate(entero): bits de 32 bits
            v = int(x) & 0xFFFFFFFF
            k %= 32
            r = ((v << k) | (v >> (32 - k))) & 0xFFFFFFFF if k else v
            return sp.Integer(r - (1 << 32) if r & 0x80000000 else r)
        v = _seq_of(x, "rotate")
        if not v:
            return x
        k = (-1 if n is None else _int(n)) % len(v)
        out = v[k:] + v[:k]
        return out if isinstance(v, str) else TIList(out)

    @reg("shift", 1, 2)
    def _shift(x, n=None):
        v = _seq_of(x, "shift")
        k = -1 if n is None else _int(n)
        fill = " " if isinstance(v, str) else sp.nan
        L = len(v)
        if k >= 0:
            out = list(v[k:]) + [fill] * min(k, L)
        else:
            out = [fill] * min(-k, L) + list(v[:L + k] if L + k > 0 else [])
        out = out[:L]
        return "".join(out) if isinstance(v, str) else TIList(out)

    @reg("string", 1, 1)
    def _string(x):
        if isinstance(x, str):
            return x
        from .fmt import Formatter
        from .rows import to_linear
        rows = Formatter(E.settings, "", False).lines(x)
        return " ".join(to_linear(r) for r in rows)

    @reg("expr", 1, 1)
    def _expr(t):
        if not isinstance(t, str):
            raise CalcError("expr necesita un texto, por ejemplo expr(\"2+3\")")
        p = Parser(E, tokenize(t))
        v = p.expr()
        if not p.at("end"):
            raise SyntaxErr("No entiendo el texto «%s»" % t)
        return v

    @reg("instring", 2, 3)
    def _instring(src, sub, start=None):
        if not isinstance(src, str) or not isinstance(sub, str):
            raise CalcError("inString(texto, buscado[, inicio])")
        i = src.find(sub, (_int(start) - 1) if start is not None else 0)
        return sp.Integer(i + 1)

    @reg("ord", 1, 1)
    def _ord(t):
        if _is_list(t):
            return TIList(_ord(a) for a in t)
        if not isinstance(t, str) or not t:
            raise CalcError("ord necesita un texto")
        return sp.Integer(ord(t[0]))

    @reg("char", 1, 1)
    def _char(n):
        if _is_list(n):
            return TIList(_char(a) for a in n)
        k = _int(n)
        if not 0 <= k <= 0x10FFFF:
            raise CalcError("char: código fuera de rango")
        return chr(k)

    QM = sp.Symbol("?")

    def _crit(c):
        c = c if isinstance(c, str) else S(c)

        def ok(v):
            if isinstance(c, sp.Basic) and c.has(QM):
                r = c.xreplace({QM: v})
                return r is sp.true or r == sp.true
            return v == c
        return ok

    @reg("countif", 2, 2)
    def _countif(lst, c):
        ok = _crit(c)
        return sp.Integer(sum(1 for v in _lst(lst) if ok(v)))

    @reg("sumif", 2, 3)
    def _sumif(lst, c, other=None):
        ok = _crit(c)
        xs = _lst(lst)
        ys = _lst(other) if other is not None else xs
        if len(ys) != len(xs):
            raise CalcError("sumIf: las listas deben tener el mismo largo")
        return sp.Add(*[y for v, y in zip(xs, ys) if ok(v)])

    @reg("seqgen", 4, 6)
    def _seqgen(expr_, n, u, rng, init=None, step=None):
        if not isinstance(n, sp.Symbol) or not isinstance(u, sp.Symbol):
            raise CalcError("seqGen(Expr, n, u, {n0, nMax}[, {valores iniciales}[, paso]])")
        r = _lst(rng)
        n0, nmax = _int(r[0]), _int(r[1])
        stp = _int(step) if step is not None else 1
        if stp <= 0 or (nmax - n0) / stp > 10000:
            raise CalcError("seqGen: demasiados términos")
        vals = {}
        ini = _lst(init) if init is not None else []
        for j, v in enumerate(ini):
            vals[n0 + j] = v
        uf = sp.Function(u.name)
        ex = S(expr_)

        def rec(m):
            if m in vals:
                return vals[m]
            w = ex.xreplace({n: sp.Integer(m)})
            w = w.replace(lambda t: isinstance(t, AppliedUndef) and t.func.__name__ == u.name,
                          lambda t: rec(_int(t.args[0])))
            vals[m] = sp.simplify(w)
            return vals[m]
        return TIList(rec(m) for m in range(n0, nmax + 1, stp))

    @reg("dim", 1, 1)
    def _dim(x):
        if isinstance(x, sp.MatrixBase):
            return TIList([sp.Integer(x.rows), sp.Integer(x.cols)])
        if isinstance(x, str):
            return sp.Integer(len(x))
        return sp.Integer(len(_lst(x)))

    @reg("augment", 2, 2)
    def _augment(a, b):
        if _is_list(a) and _is_list(b):
            return TIList(list(a) + list(b))
        return sp.ImmutableMatrix(sp.Matrix(a).row_join(sp.Matrix(b)))

    reg("colaugment", 2, 2)(lambda a, b: sp.ImmutableMatrix(sp.Matrix(a).col_join(sp.Matrix(b))))
    reg("listtomat", 1, 2)(lambda x, c=None: sp.ImmutableMatrix(
        [list(_lst(x))[i:i + (_int(c) if c else len(_lst(x)))] for i in range(0, len(_lst(x)), _int(c) if c else len(_lst(x)))]))
    reg("mattolist", 1, 1)(lambda m_: TIList(list(m_)))

    # ---- matrices
    def _mat(x):
        if not isinstance(x, sp.MatrixBase):
            raise CalcError("Se esperaba una matriz")
        return x

    @reg("det", 1, 1)
    def _det(m_):
        m_ = _mat(m_)
        if m_.free_symbols:
            d = m_.det(method="berkowitz")
            syms = sorted(d.free_symbols, key=str)
            if d.is_polynomial(*syms):
                return sp.expand(d)
            return sp.simplify(d) if sp.count_ops(d) < 400 else sp.cancel(d)
        return sp.simplify(m_.det())
    reg("rref", 1, 1)(lambda m_: sp.ImmutableMatrix(_mat(m_).rref()[0]))
    reg("ref", 1, 1)(lambda m_: sp.ImmutableMatrix(_mat(m_).echelon_form()))
    reg("identity", 1, 1)(lambda n: sp.ImmutableMatrix(sp.eye(_int(n))))
    @reg("constructmat", 5, 5)
    def _constructmat(ex, v1, v2, r, c):
        r, c = _int(r), _int(c)
        if r * c > 250000:
            raise CalcError("Matriz demasiado grande")
        ex = S(ex)
        return sp.ImmutableMatrix(r, c, lambda i, j: ex.xreplace({v1: sp.Integer(i + 1), v2: sp.Integer(j + 1)}))

    reg("newmat", 2, 2)(lambda r, c: sp.ImmutableMatrix(sp.zeros(_int(r), _int(c))))
    reg("randmat", 2, 2)(lambda r, c: sp.ImmutableMatrix(_int(r), _int(c),
                                                         lambda i, j: random.randint(-9, 9)))
    reg("diag", 1, 1)(lambda x: (sp.ImmutableMatrix(sp.diag(*_lst(x))) if _is_list(x)
                                 else TIList(_mat(x).diagonal())))
    reg("trace", 1, 1)(lambda m_: _mat(m_).trace())
    reg("norm", 1, 1)(lambda m_: sp.sqrt(sum(sp.Abs(v) ** 2 for v in _mat(m_))))
    reg("rownorm", 1, 1)(lambda m_: sp.Max(*[sum(sp.Abs(v) for v in _mat(m_).row(i)) for i in range(m_.rows)]))
    reg("colnorm", 1, 1)(lambda m_: sp.Max(*[sum(sp.Abs(v) for v in _mat(m_).col(j)) for j in range(m_.cols)]))
    reg("rowdim", 1, 1)(lambda m_: sp.Integer(_mat(m_).rows))
    reg("coldim", 1, 1)(lambda m_: sp.Integer(_mat(m_).cols))

    @reg("submat", 1, 5)
    def _submat(m_, r1=1, c1=1, r2=None, c2=None):
        m_ = _mat(m_)
        r2 = m_.rows if r2 is None else _int(r2)
        c2 = m_.cols if c2 is None else _int(c2)
        return sp.ImmutableMatrix(m_[_int(r1) - 1:r2, _int(c1) - 1:c2])

    @reg("rowswap", 3, 3)
    def _rowswap(m_, a, b):
        M = sp.Matrix(_mat(m_))
        M.row_swap(_int(a) - 1, _int(b) - 1)
        return sp.ImmutableMatrix(M)

    @reg("rowadd", 3, 3)
    def _rowadd(m_, a, b):
        M = sp.Matrix(_mat(m_))
        M[_int(b) - 1, :] = M[_int(b) - 1, :] + M[_int(a) - 1, :]
        return sp.ImmutableMatrix(M)

    @reg("mrow", 3, 3)
    def _mrow(k, m_, r):
        M = sp.Matrix(_mat(m_))
        M[_int(r) - 1, :] = k * M[_int(r) - 1, :]
        return sp.ImmutableMatrix(M)

    @reg("mrowadd", 4, 4)
    def _mrowadd(k, m_, a, b):
        M = sp.Matrix(_mat(m_))
        M[_int(b) - 1, :] = M[_int(b) - 1, :] + k * M[_int(a) - 1, :]
        return sp.ImmutableMatrix(M)

    @reg("simult", 2, 2)
    def _simult(A, B):
        A = _mat(A)
        if A.det() == 0:
            raise CalcError("El sistema no tiene solución única (determinante 0)")
        return sp.ImmutableMatrix(A.inv() * sp.Matrix(B))

    def _np_eig(m_):
        """Matriz numérica: valores y vectores propios con NumPy (rápido aun en 30×30), como la TI en decimal."""
        import numpy as np
        a = np.array([[complex(sp.N(x)) for x in row] for row in m_.tolist()])
        if not np.any(a.imag):
            a = a.real
        w, vec = np.linalg.eig(a)
        order = sorted(range(len(w)), key=lambda i: (-round(w[i].real, 9), round(w[i].imag, 9)))
        return w[order], vec[:, order]

    def _npnum(z):
        z = complex(z)
        tol = 1e-13 * max(1.0, abs(z))
        re_ = 0.0 if abs(z.real) < tol else z.real
        im_ = 0.0 if abs(z.imag) < tol else z.imag
        return sp.Float(re_, 15) + (sp.I * sp.Float(im_, 15) if im_ else 0)

    @reg("eigvl", 1, 1)
    def _eigvl(m_):
        m_ = _mat(m_)
        if m_.rows != m_.cols:
            raise CalcError("La matriz debe ser cuadrada")
        if not m_.free_symbols:
            w, _ = _np_eig(m_)
            return TIList(_npnum(x) for x in w)
        return TIList(sp.N(v) for v, k in m_.eigenvals().items() for _ in range(k))

    @reg("eigvc", 1, 1)
    def _eigvc(m_):
        m_ = _mat(m_)
        if m_.rows != m_.cols:
            raise CalcError("La matriz debe ser cuadrada")
        if not m_.free_symbols:
            _, vec = _np_eig(m_)
            return sp.ImmutableMatrix(m_.rows, m_.cols, lambda i, j: _npnum(vec[i, j]))
        cols = []
        for val, mult, vecs in sp.Matrix(_mat(m_)).eigenvects():
            for v in vecs:
                v = sp.N(v / v.norm())
                cols.append(list(v))
        return sp.ImmutableMatrix(cols).T

    reg("charpoly", 2, 2)(lambda m_, x: _mat(m_).charpoly(x).as_expr())
    reg("unitv", 1, 1)(lambda v: sp.ImmutableMatrix(_mat(v) / sp.sqrt(sum(sp.Abs(x) ** 2 for x in v))))
    @reg("crossp", 2, 2)
    def _crossp(a, b):
        la, lb = list(a), list(b)
        if len(la) not in (2, 3) or len(lb) not in (2, 3):
            raise CalcError("crossP es para vectores de 2 o 3 componentes")
        la += [0] * (3 - len(la))
        lb += [0] * (3 - len(lb))
        c = sp.Matrix(la).cross(sp.Matrix(lb))
        if _is_list(a):
            return TIList(list(c))
        return sp.ImmutableMatrix(c).T if _mat(a).rows == 1 else sp.ImmutableMatrix(c)
    reg("dotp", 2, 2)(lambda a, b: sp.Add(*[x * y for x, y in zip(list(a), list(b))]))

    # ---- eléctrica
    def _report(pairs):
        return Report(pairs)

    reg("delta2y deltay electrica\\delta2y", 3, 3)(lambda a, b, c: _report(elec.delta2y(a, b, c)))
    reg("y2delta ydelta electrica\\y2delta", 3, 3)(lambda a, b, c: _report(elec.y2delta(a, b, c)))

    @reg("electrica\\deltaestrella", 0, 4)
    def _de(*a):
        if len(a) == 4:
            if _int(a[0]) == 1:
                return _report(elec.delta2y(*a[1:]))
            return _report(elec.y2delta(*a[1:]))
        raise CalcError("Aquí es directo: delta2y(Zab,Zbc,Zca) o y2delta(Za,Zb,Zc)")

    reg("par", 1, None)(lambda *zs: elec.par(*zs))
    # por unidad y trifásico
    reg("zbase", 2, 2)(lambda vb, sb: elec.zbase(S(vb), S(sb)))
    reg("ibase", 2, 2)(lambda sb, vb: elec.ibase(S(sb), S(vb)))
    reg("zpu", 3, 3)(lambda z, vb, sb: elec.zpu(S(z), S(vb), S(sb)))
    reg("pu", 2, 2)(lambda x, b: S(x) / S(b))
    def _bases(sb, vb):
        sb, vb = elec.order(S(sb), S(vb), "S", "V")
        return _report([("Sbase", sb), ("Vbase", vb), ("Zbase", elec.zbase(vb, sb)),
                        ("Ibase", elec.ibase(sb, vb)), ("Ybase", 1 / elec.zbase(vb, sb))])
    reg("bases", 2, 2)(_bases)
    reg("frompu", 2, 2)(lambda x, b: S(x) * S(b))
    reg("cambiobase newbase", 5, 5)(lambda z, v1, s1, v2, s2: elec.cambiobase(*(S(a) for a in (z, v1, s1, v2, s2))))
    reg("linea vlinea", 1, 1)(lambda v: bmap(lambda x: elec.linea(S(x)), v))
    reg("fase vfase", 1, 1)(lambda v: bmap(lambda x: elec.fase(S(x)), v))
    reg("pot3f", 3, 3)(lambda vl, il, fp: _report(elec.pot3f(S(vl), S(il), S(fp))))
    reg("scomp", 2, 2)(lambda v, i: elec.scomp(S(v), S(i)))
    reg("s3f", 2, 2)(lambda v, i: elec.s3f(S(v), S(i)))
    reg("cuadripolo\\convert", 6, 6)(lambda t1, a, b, c, d, t2: sp.ImmutableMatrix(elec.convert(t1, a, b, c, d, t2)))
    reg("cuadripolo\\connect", 12, 12)(lambda *a: sp.ImmutableMatrix(elec.connect(*a)))
    reg("cuadripolo\\cperf", 8, 8)(lambda *a: _report(elec.cperf(*a)))

    @reg("cuadripolo\\help", 0, 0)
    def _help():
        return ('convert("z",x11,x12,x21,x22,"y") · cperf("z",x11,x12,x21,x22,ZL,ZS,VS) · '
                'connect("serie"|"paralelo"|"cascada"|"serie-paralelo"|"paralelo-serie",'
                '"z",x11..x22,"y",c11..c22,"z")  —  tipos: z y h g a')

    @reg("desolve", 3, 3)
    def _desolve(ode, x, y):
        """deSolve(y''+y=0 and y(0)=1 and y'(0)=0, x, y) como la TI (hasta 2.º orden, y más)."""
        if not isinstance(x, sp.Symbol) or not isinstance(y, sp.Symbol):
            raise CalcError("deSolve(ecuación, variable independiente, variable dependiente); "
                            "revisa que x e y no tengan un valor guardado")
        f = sp.Function(y.name)(x)
        parts = list(ode.args) if isinstance(ode, sp.And) else [ode]

        def primes(name):
            base = name.rstrip("'")
            return (len(name) - len(base)) if base == y.name else None

        def conv(e):
            rep = {}
            for sym in e.free_symbols:
                n = primes(sym.name) if isinstance(sym, sp.Symbol) else None
                if n is not None:
                    rep[sym] = f if n == 0 else f.diff(x, n)
            return e.xreplace(rep)

        eqs, ics = [], {}
        for p_ in parts:
            if p_ is sp.true:
                continue
            if p_ is sp.false:
                raise CalcError("La ecuación o una condición es siempre falsa")
            lhs = p_.lhs if isinstance(p_, sp.Equality) else None
            if lhs is not None and isinstance(lhs, AppliedUndef) and primes(lhs.func.__name__) is not None:
                n = primes(lhs.func.__name__)
                a = lhs.args[0]
                key = f.subs(x, a) if n == 0 else f.diff(x, n).subs(x, a)
                ics[key] = p_.rhs
                continue
            e = p_ if isinstance(p_, sp.Equality) else sp.Eq(S(p_), 0)
            e = conv(e)
            if not e.has(sp.Derivative):
                raise CalcError("La ecuación debe tener %s' (la derivada de %s)" % (y.name, y.name))
            eqs.append(e)
        if len(eqs) != 1:
            raise CalcError("deSolve resuelve una ecuación diferencial (con condiciones unidas con and)")
        try:
            sol = sp.dsolve(eqs[0], f, ics=ics or None)
        except NotImplementedError:
            raise CalcError("No sé resolver esa ecuación diferencial")
        except ValueError as ex:
            raise CalcError("No pude usar las condiciones (%s)" % str(ex)[:80])
        sols = sol if isinstance(sol, list) else [sol]
        out = []
        for so in sols:
            lhs_, rhs_ = so.lhs, so.rhs
            if lhs_ == f and not rhs_.has(f):
                rhs_ = sp.expand(rhs_) if rhs_.free_symbols & {s for s in rhs_.free_symbols if s.name.startswith("C")} \
                    or ics else rhs_
                rhs_ = sp.expand(rhs_)
            cs = sorted([c for c in (so.free_symbols | rhs_.free_symbols)
                         if isinstance(c, sp.Symbol) and c.name[:1] == "C" and c.name[1:].isdigit()],
                        key=lambda c: _ti_order(rhs_, c))
            rep = {}
            for c in cs:
                E.de_n += 1
                rep[c] = sp.Symbol("c%d" % E.de_n)
            back = {f: y}
            if lhs_ == f:
                out.append(sp.Eq(y, rhs_.xreplace(rep).xreplace(back), evaluate=False))
            else:
                out.append(sp.Eq(lhs_.xreplace(rep).xreplace(back), rhs_.xreplace(rep).xreplace(back),
                                 evaluate=False))
        return out[0] if len(out) == 1 else sp.Or(*out, evaluate=False)

    @reg("when", 3, 4)
    def _when(c, a, b, u=None):
        c = S(c)
        if c is sp.true:
            return a
        if c is sp.false:
            return b
        if u is not None and not c.free_symbols:
            return u
        return sp.Piecewise((S(a), c), (S(b), True))

    @reg("piecewise", 1, None)
    def _piecewise(*a):
        pairs = []
        for k in range(0, len(a), 2):
            val = S(a[k])
            cond = S(a[k + 1]) if k + 1 < len(a) else sp.true
            pairs.append((val, cond))
        return sp.Piecewise(*pairs)

    # fasores
    reg("rect", 1, 1)(lambda x: ("__info__", (x, {"cplx": "Rectangular"})))
    reg("polar", 1, 1)(lambda x: ("__info__", (x, {"cplx": "Polar"})))
    return F


def _ti_order(e, c):
    """Orden en que aparece la constante c (para numerarlas c1, c2… como la TI: cos antes que sin)."""
    terms = sp.Add.make_args(sp.expand(e))
    for k, t in enumerate(sorted(terms, key=lambda t: str(t.subs({s: 1 for s in t.free_symbols
                                                                     if s.name[:1] == "C"})))):
        if t.has(c):
            return k
    return 99


def _median(L):
    L = sorted(L, key=lambda v: float(sp.N(v)))
    n = len(L)
    if n == 0:
        raise CalcError("La lista está vacía")
    return L[n // 2] if n % 2 else (L[n // 2 - 1] + L[n // 2]) / 2


# nombres para el catálogo: nombre -> sintaxis
CATALOG = [
    ("abs", "abs(Valor)", "Valor absoluto o magnitud"), ("angle", "angle(z)", "Ángulo de un complejo"),
    ("approx", "approx(Expr)", "Resultado decimal"), ("approxFraction", "approxFraction(Valor)", "Fracción aproximada"),
    ("arcLen", "arcLen(Expr,x,a,b)", "Longitud de arco"), ("augment", "augment(A,B)", "Junta listas o matrices"),
    ("binomCdf", "binomCdf(n,p,lo,hi)", "Binomial acumulada"), ("binomPdf", "binomPdf(n,p,x)", "Binomial"),
    ("cFactor", "cFactor(Expr)", "Factoriza en los complejos"), ("ceiling", "ceiling(x)", "Entero siguiente"),
    ("charPoly", "charPoly(M,x)", "Polinomio característico"), ("colAugment", "colAugment(A,B)", "Junta por columnas"),
    ("colNorm", "colNorm(M)", "Norma de columnas"), ("comDenom", "comDenom(Expr)", "Denominador común"),
    ("completeSquare", "completeSquare(Expr,x)", "Completa el cuadrado"), ("conj", "conj(z)", "Conjugado"),
    ("cos", "cos(θ)", "Coseno (en el modo de ángulo)"), ("cPolyRoots", "cPolyRoots(Poly,x)", "Raíces complejas"),
    ("crossP", "crossP(a,b)", "Producto vectorial"), ("cSolve", "cSolve(Ecuación,x)", "Resuelve en los complejos"),
    ("cuadripolo\\connect", 'cuadripolo\\connect("serie","z",x11,x12,x21,x22,"z",c11,c12,c21,c22,"z")',
     "Conecta dos cuadripolos (serie, paralelo, cascada, serie-paralelo, paralelo-serie)"),
    ("cuadripolo\\convert", 'cuadripolo\\convert("z",x11,x12,x21,x22,"y")', "Convierte parámetros z, y, h, g, a (ABCD)"),
    ("cuadripolo\\cperf", 'cuadripolo\\cperf("z",x11,x12,x21,x22,ZL,ZS,VS)', "Zin, Zout, ganancias, V y I con fuente y carga"),
    ("cZeros", "cZeros(Expr,x)", "Ceros complejos"),
    ("tvmFV", "tvmFV(N,I,PV,Pmt[,PpY,CpY,PmtAt])", "Valor futuro"),
    ("tvmPV", "tvmPV(N,I,Pmt,FV[,PpY,CpY,PmtAt])", "Valor actual"),
    ("tvmPmt", "tvmPmt(N,I,PV,FV[,PpY,CpY,PmtAt])", "Cantidad de pago"),
    ("tvmN", "tvmN(I,PV,Pmt,FV[,PpY,CpY,PmtAt])", "Número de periodos"),
    ("tvmI", "tvmI(N,PV,Pmt,FV[,PpY,CpY,PmtAt])", "Tasa de interés anual (%)"),
    ("amortTbl", "amortTbl(NPmt,N,I,PV[,Pmt,FV,PpY,CpY,PmtAt,redondeo])", "Tabla de amortización"),
    ("bal", "bal(NPmt,N,I,PV[,Pmt,FV,PpY,CpY,PmtAt])", "Saldo después de NPmt pagos"),
    ("ΣInt", "ΣInt(NPmt1,NPmt2,N,I,PV[,…])", "Interés pagado entre dos pagos"),
    ("ΣPrn", "ΣPrn(NPmt1,NPmt2,N,I,PV[,…])", "Capital pagado entre dos pagos"),
    ("npv", "npv(Tasa,CF0,ListaCF[,Frec])", "Valor presente neto"), ("irr", "irr(CF0,ListaCF[,Frec])", "Tasa interna de retorno"),
    ("mirr", "mirr(TasaFin,TasaReinv,CF0,ListaCF[,Frec])", "TIR modificada"),
    ("nom", "nom(TasaEfectiva,CpY)", "Tasa nominal"), ("eff", "eff(TasaNominal,CpY)", "Tasa efectiva"),
    ("dbd", "dbd(fecha1,fecha2)", "Días entre fechas (MM.DDAA o DDMM.AA)"),
    ("OneVar", "OneVar(Lista[,Frec])", "Estadísticas de una variable (x̄, sx, cuartiles…)"),
    ("TwoVar", "TwoVar(ListaX,ListaY)", "Estadísticas de dos variables"),
    ("LinRegMx", "LinRegMx(X,Y)", "Regresión lineal y=m·x+b (queda en RegEqn(x))"),
    ("LinRegBx", "LinRegBx(X,Y)", "Regresión lineal y=a+b·x"),
    ("QuadReg", "QuadReg(X,Y)", "Regresión cuadrática"), ("CubicReg", "CubicReg(X,Y)", "Regresión cúbica"),
    ("QuartReg", "QuartReg(X,Y)", "Regresión cuártica"), ("PowerReg", "PowerReg(X,Y)", "Regresión potencial a·x^b"),
    ("ExpReg", "ExpReg(X,Y)", "Regresión exponencial a·b^x"), ("LnReg", "LnReg(X,Y)", "Regresión logarítmica a+b·ln(x)"),
    ("statResults", "statResults()", "Últimos resultados estadísticos"),
    ("MedMed", "MedMed(X,Y)", "Línea mediana-mediana"), ("SinReg", "SinReg(X,Y)", "Regresión sinusoidal a·sin(b·x+c)+d"),
    ("Logistic", "Logistic(X,Y)", "Regresión logística c/(1+a·e^(-bx))"), ("LogisticD", "LogisticD(X,Y)", "Logística con d"),
    ("MultReg", "MultReg(Y,X1,X2,…)", "Regresión lineal múltiple"), ("corrMat", "corrMat(L1,L2,…)", "Matriz de correlación"),
    ("invChi2", "invChi2(p,gl)", "χ² inversa"), ("FPdf", "FPdf(x,gl1,gl2)", "Densidad F"),
    ("FCdf", "FCdf(a,b,gl1,gl2)", "F acumulada"), ("invF", "invF(p,gl1,gl2)", "F inversa"),
    ("invBinom", "invBinom(acum,n,p)", "Binomial inversa"),
    ("zbase", "zbase(Vbase,Sbase)", "Impedancia base Vb²/Sb (ej. zbase(13.8_kV,100_MVA))"),
    ("ibase", "ibase(Sbase,Vbase)", "Corriente base Sb/(√3·Vb)"),
    ("zpu", "zpu(Z,Vbase,Sbase)", "Impedancia en por unidad"),
    ("pu", "pu(valor,base)", "Valor en por unidad (valor/base)"),
    ("bases", "bases(Sbase,Vbase)", "Zbase, Ibase e Ybase de una zona (ej. bases(100_MVA,13.8_kV))"),
    ("frompu", "frompu(valorpu,base)", "Desde por unidad (valor·base)"),
    ("cambiobase", "cambiobase(Zpu,Vb1,Sb1,Vb2,Sb2)", "Cambio de base de una impedancia en pu"),
    ("linea", "linea(Vfase)", "Tensión de línea: √3·Vf (con fasor: √3∠30°·Vf)"),
    ("fase", "fase(Vlinea)", "Tensión de fase: Vl/√3 (con fasor: Vl/(√3∠30°))"),
    ("pot3f", "pot3f(VL,IL,fp)", "Potencias trifásicas S, P y Q"),
    ("scomp", "scomp(V,I)", "Potencia compleja S = V·I*"),
    ("s3f", "s3f(Vfase,Ifase)", "Potencia compleja trifásica S = 3·Vf·If*"), ("deSolve", "deSolve(y''+y=0 and y(0)=1,x,y)", "Ecuación diferencial (y', y'', condiciones con and)"), ("delta2y", "delta2y(Zab,Zbc,Zca)", "Δ → Y"),
    ("derivative", "derivative(Expr,x[,n])", "Derivada (también x=a para evaluarla)"),
    ("det", "det(M)", "Determinante"), ("diag", "diag(Lista)", "Matriz diagonal"), ("dim", "dim(Lista o M)", "Tamaño"),
    ("dotP", "dotP(a,b)", "Producto punto"), ("eigVc", "eigVc(M)", "Vectores propios"), ("eigVl", "eigVl(M)", "Valores propios"),
    ("exact", "exact(Valor)", "Resultado exacto"), ("exp", "exp(x)", "ℯ^x"), ("expand", "expand(Expr)", "Expande"),
    ("factor", "factor(Expr)", "Factoriza"), ("floor", "floor(x)", "Parte entera hacia abajo"),
    ("fMax", "fMax(Expr,x[,a,b])", "Máximo de una función"), ("fMin", "fMin(Expr,x[,a,b])", "Mínimo de una función"),
    ("fPart", "fPart(x)", "Parte fraccionaria"), ("gcd", "gcd(a,b)", "Máximo común divisor"),
    ("getDenom", "getDenom(Fracción)", "Denominador"), ("getNum", "getNum(Fracción)", "Numerador"),
    ("identity", "identity(n)", "Matriz identidad"), ("imag", "imag(z)", "Parte imaginaria"),
    ("impDif", "impDif(Ecuación,x,y)", "Derivación implícita"), ("integral", "integral(Expr,x[,a,b])", "Integral"),
    ("invNorm", "invNorm(p[,μ,σ])", "Normal inversa"), ("iPart", "iPart(x)", "Parte entera"),
    ("lcm", "lcm(a,b)", "Mínimo común múltiplo"), ("limit", "limit(Expr,x,a[,dir])", "Límite"),
    ("ln", "ln(x)", "Logaritmo natural"), ("log", "log(x[,base])", "Logaritmo (base 10 o la que indiques)"),
    ("max", "max(Lista)", "Máximo"), ("mean", "mean(Lista)", "Media"), ("median", "median(Lista)", "Mediana"),
    ("min", "min(Lista)", "Mínimo"), ("mod", "mod(a,b)", "Módulo"), ("nCr", "nCr(n,r)", "Combinaciones"),
    ("nDerivative", "nDerivative(Expr,x=a)", "Derivada numérica"), ("newMat", "newMat(filas,col)", "Matriz de ceros"),
    ("nInt", "nInt(Expr,x,a,b)", "Integral numérica"), ("normalLine", "normalLine(Expr,x,a)", "Recta normal"),
    ("normCdf", "normCdf(a,b[,μ,σ])", "Normal acumulada"), ("normPdf", "normPdf(x[,μ,σ])", "Densidad normal"),
    ("nPr", "nPr(n,r)", "Permutaciones"), ("nSolve", "nSolve(Ecuación,x[=inicio])", "Solución numérica"),
    ("par", "par(Z1,Z2,…)", "Impedancias en paralelo"), ("poissCdf", "poissCdf(λ,a,b)", "Poisson acumulada"),
    ("poissPdf", "poissPdf(λ,x)", "Poisson"), ("polyCoeffs", "polyCoeffs(Poly,x)", "Coeficientes"),
    ("polyDegree", "polyDegree(Poly,x)", "Grado"), ("polyGcd", "polyGcd(a,b)", "MCD de polinomios"),
    ("polyQuotient", "polyQuotient(P,Q,x)", "Cociente"), ("polyRemainder", "polyRemainder(P,Q,x)", "Residuo"),
    ("polyRoots", "polyRoots(Poly,x)", "Raíces reales"), ("propFrac", "propFrac(Expr)", "Fracción propia"),
    ("rand", "rand()", "Aleatorio entre 0 y 1"), ("randInt", "randInt(a,b)", "Entero aleatorio"),
    ("real", "real(z)", "Parte real"), ("ref", "ref(M)", "Forma escalonada"), ("remain", "remain(a,b)", "Residuo"),
    ("root", "root(x,n)", "Raíz n-ésima"), ("round", "round(x[,dígitos])", "Redondea"),
    ("rowNorm", "rowNorm(M)", "Norma de filas"), ("rref", "rref(M)", "Forma escalonada reducida"),
    ("seq", "seq(Expr,k,a,b)", "Secuencia"), ("sign", "sign(x)", "Signo"), ("simult", "simult(A,B)", "Sistema lineal"),
    ("sin", "sin(θ)", "Seno (en el modo de ángulo)"), ("solve", "solve(Ecuación,x)", "Resuelve"),
    ("sqrt", "√(x)", "Raíz cuadrada"), ("stDevSamp", "stDevSamp(Lista)", "Desviación estándar muestral"),
    ("subMat", "subMat(M,f1,c1,f2,c2)", "Submatriz"), ("sum", "sum(Lista)", "Suma de una lista"),
    ("tan", "tan(θ)", "Tangente"), ("tangentLine", "tangentLine(Expr,x,a)", "Recta tangente"),
    ("taylor", "taylor(Expr,x,n[,a])", "Polinomio de Taylor"), ("tCollect", "tCollect(Expr)", "Recopila trigonometría"),
    ("tExpand", "tExpand(Expr)", "Expande trigonometría"), ("trace", "trace(M)", "Traza"),
    ("unitV", "unitV(v)", "Vector unitario"), ("varSamp", "varSamp(Lista)", "Varianza muestral"),
    ("y2delta", "y2delta(Za,Zb,Zc)", "Y → Δ"), ("zeros", "zeros(Expr,x)", "Ceros"),
    ("Σ", "Σ(Expr,k,a,b)", "Sumatoria"), ("Π", "Π(Expr,k,a,b)", "Productoria"), ("∫", "∫(Expr,x[,a,b])", "Integral"),
]
