"""
roots.py - Soluciones dentro de un intervalo y cerca de un valor, como la TI:

    solve(ec, x) | 0<x<40      -> todas las soluciones en ese intervalo
    solve(ec, x=0)             -> la solución más cercana a 0 (decimal)

Se combinan dos fuentes: las soluciones generales de Giac (con n_1, n_2… enteros) recorridas dentro del
intervalo, que dan la forma exacta, y una búsqueda numérica (muestreo + bisección), que encuentra lo que la
forma general no da.
"""
from __future__ import annotations

import math

import sympy as sp


def _fn(ex, v):
    f = sp.lambdify(v, ex, modules=["mpmath"])
    fc = None
    try:                                   # con cmath/numpy es mucho más rápido que mpmath (celular)
        import numpy as np
        fn = sp.lambdify(v, ex, modules=["numpy"])
        with np.errstate(all="ignore"):
            t = complex(fn(complex(0.37)))
        tm = complex(f(0.37))
        if abs(t - tm) <= 1e-9 * max(1.0, abs(tm)) or not (math.isfinite(tm.real) and math.isfinite(t.real)):
            fc = fn
    except Exception:  # noqa: BLE001
        fc = None

    def g(x):
        try:
            if fc is not None:
                import numpy as np
                with np.errstate(all="ignore"):
                    y = complex(fc(complex(x)))
                if not (math.isfinite(y.real) and math.isfinite(y.imag)):
                    y = complex(f(x))
            else:
                y = complex(f(x))
        except (ZeroDivisionError, ValueError, OverflowError, TypeError):
            return float("nan")
        if abs(y.imag) > 1e-9 * max(1.0, abs(y.real)):
            return float("nan")
        return y.real
    return g


def _sample(ex, v, xs, g):
    """f en todos los puntos de una vez con numpy (rápido); si no se puede, punto por punto."""
    try:
        import numpy as np
        f = sp.lambdify(v, ex, modules=["numpy"])
        with np.errstate(all="ignore"):
            y = np.asarray(f(np.asarray(xs, dtype=complex)), dtype=complex)
        if y.shape == ():
            y = np.full(len(xs), complex(y))
        if y.shape != (len(xs),):
            raise ValueError
        re_ = y.real.copy()
        bad = ~np.isfinite(y) | (np.abs(y.imag) > 1e-9 * np.maximum(1.0, np.abs(y.real)))
        re_[bad] = np.nan
        return [float(t) for t in re_]
    except Exception:  # noqa: BLE001
        return [g(x) for x in xs]


def numeric_roots(ex, v, lo, hi, n=None):
    """Raíces reales de ex(v)=0 en [lo, hi] (muestreo + bisección; también raíces dobles)."""
    if not (math.isfinite(lo) and math.isfinite(hi)) or hi <= lo:
        return []
    g = _fn(ex, v)
    n = n or 3000
    xs = [lo + (hi - lo) * i / n for i in range(n + 1)]
    ys = _sample(ex, v, xs, g)
    finite = sorted(abs(y) for y in ys if math.isfinite(y))
    scale = finite[len(finite) // 2] if finite else 1.0     # mediana: un eˣ enorme en un extremo no manda
    out = []
    for i in range(n):
        a, b, fa, fb = xs[i], xs[i + 1], ys[i], ys[i + 1]
        if not (math.isfinite(fa) and math.isfinite(fb)):
            continue
        if fa == 0:
            out.append(a)
            continue
        if fa * fb < 0:
            fa, fb = g(a), g(b)
            if not (math.isfinite(fa) and math.isfinite(fb)) or fa * fb > 0:
                continue
            for _ in range(80):
                m = (a + b) / 2
                if m == a or m == b:
                    break
                fm = g(m)
                if not math.isfinite(fm):
                    break
                if fa * fm <= 0:
                    b, fb = m, fm
                else:
                    a, fa = m, fm
            r = (a + b) / 2
            fr = g(r)
            # no es un polo: cerca de la raíz f es chica comparada con sus vecinos
            near = max(abs(ys[i]), abs(ys[i + 1]))
            if math.isfinite(fr) and abs(fr) < 1e-6 * max(1.0, near):
                out.append(r)
    # raíces dobles (tocan el eje sin cruzarlo): mínimos locales de |f| casi cero
    dg = None
    for i in range(1, n):
        y0, y1, y2 = ys[i - 1], ys[i], ys[i + 1]
        if not all(math.isfinite(t) for t in (y0, y1, y2)):
            continue
        if abs(y1) <= abs(y0) and abs(y1) <= abs(y2) and abs(y1) < 1e-3 * max(1.0, scale) and y0 * y2 > 0:
            try:
                import mpmath
                if dg is None:
                    dg = _fn(sp.diff(ex, v), v)
                r = float(mpmath.findroot(lambda t, _d=dg: _d(float(t)), xs[i]))
                if lo <= r <= hi and abs(g(r)) < 1e-9 * max(1.0, scale):
                    out.append(r)
            except Exception:  # noqa: BLE001
                pass
    out.sort()
    clean = []
    for r in out:
        if not clean or abs(r - clean[-1]) > 1e-7 * max(1.0, abs(r)):
            clean.append(r)
    return clean


def enumerate_general(sols, v, lo, hi, limit=400):
    """Soluciones generales con enteros n_k -> las que caen en [lo, hi] (exactas)."""
    out = []
    for s in sols:
        s = sp.sympify(s)
        ns = [t for t in s.free_symbols if t.name.startswith("n") and t.name[1:].isdigit()]
        if not ns:
            if s.is_number:
                out.append(s)
            continue
        if len(ns) > 1:
            continue
        nn = ns[0]
        try:
            a = float(sp.N(s.subs(nn, 0)))
            b = float(sp.N(s.subs(nn, 1))) - a
        except (TypeError, ValueError):
            continue
        if b == 0:
            out.append(s.subs(nn, 0))
            continue
        k0, k1 = (lo - a) / b, (hi - a) / b
        k0, k1 = min(k0, k1), max(k0, k1)
        if not (math.isfinite(k0) and math.isfinite(k1)) or k1 - k0 > limit:
            continue
        for k in range(math.floor(k0) - 1, math.ceil(k1) + 2):
            out.append(sp.simplify(s.subs(nn, k)))
    return out


def merge(exact, approx, lo, hi, lo_strict=False, hi_strict=False):
    """Une soluciones exactas y numéricas (sin repetir), solo las que están en el intervalo."""
    def inside(x):
        return (x > lo if lo_strict else x >= lo - 1e-12) and (x < hi if hi_strict else x <= hi + 1e-12)
    vals = []
    for e in exact:
        try:
            c = complex(sp.N(e))
        except (TypeError, ValueError):
            continue
        if abs(c) < 1e-9 and (isinstance(e, sp.Float) or e.atoms(sp.Float)):
            e, c = sp.Integer(0), 0j                 # ruido numérico (2.6ᴇ-27) = 0
        if abs(c.imag) > 1e-9 * max(1.0, abs(c.real)) or not inside(c.real):
            continue
        vals.append((c.real, e))
    for r in approx:
        if abs(r) < 1e-9:
            r = 0.0
        if not inside(r):
            continue
        if any(abs(r - x) <= 1e-6 * max(1.0, abs(r)) for x, _ in vals):
            continue
        vals.append((r, sp.Float(r, 15)))
    vals.sort(key=lambda t: t[0])
    out = []
    for x, e in vals:
        if not out or abs(x - out[-1][0]) > 1e-9 * max(1.0, abs(x)):
            out.append((x, e))
    return [e for _, e in out]


def nearest(ex, v, guess, span=1.0):
    """La solución real más cercana a guess (la TI: solve(ec, x=guess))."""
    w = max(span, abs(guess) * 0.5, 1.0)
    for _ in range(8):
        rs = numeric_roots(ex, v, guess - w, guess + w, 4000)
        if rs:
            return min(rs, key=lambda r: abs(r - guess))
        w *= 6
    return None


def system_roots(exs, vs, seconds=3.0, box=None):
    """Sistemas no lineales con decimales (flujo de potencia, etc.): Newton desde muchos puntos de partida.
    Devuelve una lista de dicts {var: Float} con las soluciones reales distintas (residuo ~0)."""
    import itertools
    import random
    import time

    import numpy as np

    n = len(vs)
    if n == 0 or len(exs) < n:
        return []
    try:
        f = sp.lambdify(vs, list(exs), modules="numpy")
        jac = sp.Matrix(exs).jacobian(vs)
        jf = sp.lambdify(vs, jac, modules="numpy")
    except Exception:  # noqa: BLE001
        return []

    def F(x):
        return np.array(f(*x), dtype=complex).ravel()

    def J(x):
        return np.array(jf(*x), dtype=complex).reshape(len(exs), n)

    base = [0.0, 1.0, -1.0, 0.5, -0.5, 2.0, -2.0, 3.0, -3.0, 0.1]
    starts = []
    per = max(2, int(round(400 ** (1.0 / n))))
    for p in itertools.product(base[:per], repeat=n):
        starts.append(np.array(p))
        if len(starts) > 600:
            break
    rnd = random.Random(1)
    box = box or 4.0
    for _ in range(300):
        starts.append(np.array([rnd.uniform(-box, box) for _ in range(n)]))
    t_end = time.time() + seconds
    found = []
    with np.errstate(all="ignore"):
        for x in starts:
            if time.time() > t_end:
                break
            x = x.astype(float)
            ok = False
            for _ in range(60):
                try:
                    fx = F(x)
                    jx = J(x)
                except Exception:  # noqa: BLE001
                    break
                if not np.all(np.isfinite(fx)) or not np.all(np.isfinite(jx)):
                    break
                if np.max(np.abs(fx.imag)) > 1e-9 * (1 + np.max(np.abs(fx.real))):
                    break
                try:
                    dx = np.linalg.lstsq(jx.real, -fx.real, rcond=None)[0]
                except np.linalg.LinAlgError:
                    break
                lam = 1.0
                while lam > 1e-3:                      # Newton amortiguado
                    xn = x + lam * dx
                    try:
                        fn = F(xn)
                    except Exception:  # noqa: BLE001
                        fn = None
                    if fn is not None and np.all(np.isfinite(fn)) and np.linalg.norm(fn) < np.linalg.norm(fx) * (1 - 1e-4 * lam):
                        break
                    lam /= 2
                x = x + lam * dx
                if np.linalg.norm(dx) * lam < 1e-14 * (1 + np.linalg.norm(x)):
                    ok = True
                    break
            if not np.all(np.isfinite(x)) or np.max(np.abs(x)) > 1e6:
                continue
            try:
                res = np.max(np.abs(F(x)))
            except Exception:  # noqa: BLE001
                continue
            if not (res < 1e-9 or ok and res < 1e-7):
                continue
            if any(np.max(np.abs(x - y)) < 1e-7 * (1 + np.max(np.abs(y))) for y in found):
                continue
            found.append(x.copy())
    found.sort(key=lambda y: (np.linalg.norm(y), tuple(y)))
    return [{v: sp.Float(float(y[i]), 15) for i, v in enumerate(vs)} for y in found[:12]]
