"""
aparato.py - La calculadora completa sin Qt: línea de entrada (editor.Editor) + historial + cálculo (core) +
pantalla (render). Es lo que correrá en la calculadora física: sus botones llaman a Aparato.tecla(...) y la
pantalla muestra Aparato.pantalla(). Se comporta como la pestaña Calculadora del PC (y como la TI):

    ↑ ↓            recorren el historial (resultado, luego expresión); Enter pega lo elegido en la línea
    Supr / ⌫       con algo elegido: borra esa entrada
    Ctrl+Z / Y     deshace tecla por tecla; con la línea vacía saca el último cálculo y su expresión vuelve
    Esc            sale del historial (o cierra el aviso de error)
"""
from __future__ import annotations

from .core import Calculadora
from .editor import Editor
from .rows import Row


class Aparato:
    def __init__(self, carpeta=None, ajustes=None):
        self.calc = Calculadora(carpeta, ajustes)
        self.ed = Editor()
        self.ed.undoHook = self.deshacer
        self.ed.redoHook = self.rehacer
        self.ed.onChange = self._edit_changed
        self.sel = None                 # índice del elemento elegido con ↑ (en _flat()), o None
        self.mensaje = None             # (título, texto) de la ventanita de error
        self._acts, self._redo_acts = [], []
        self._acting = False

    # ---------- historial como lista plana: entrada, resultados, entrada, resultados…
    def _flat(self):
        out = []
        for i, e in enumerate(self.calc.historial):
            out.append((i, None))
            for j in range(max(1, len(e.filas)) if not e.error else 1):
                out.append((i, j))
        return out

    def _set_sel(self, idx):
        n = len(self._flat())
        self.sel = idx if idx is not None and 0 <= idx < n else None
        self.ed.historyMode = self.sel is not None

    # ---------- teclas
    def tecla(self, k, text="", ctrl=False, shift=False, alt=False):
        """k: "text" (con text), "enter", "escape", "left", "right", "up", "down", "home", "end",
        "backspace", "delete", "tab", "backtab", "frac"; o ctrl=True con text="z"/"y"/"a"…"""
        if self.mensaje is not None:
            if k in ("enter", "escape"):
                self.mensaje = None
            return
        if self.sel is not None:
            flat = self._flat()
            if k == "up":
                self._set_sel(max(0, self.sel - 1))
                return
            if k == "down":
                self._set_sel(self.sel + 1 if self.sel + 1 < len(flat) else None)
                return
            if k == "home":
                self._set_sel(0)
                return
            if k == "end" or k == "escape":
                self._set_sel(None)
                return
            if k == "enter":
                i, j = flat[self.sel]
                self._set_sel(None)
                self.ed.insertRow(self.calc.pegar(i, resultado=j is not None))
                return
            if k in ("delete", "backspace") and not ctrl:
                self._borrar(flat[self.sel][0])
                return
            if not (ctrl and text.lower() in ("z", "y")):
                self._set_sel(None)
        r = self.ed.key(k, text, ctrl=ctrl, shift=shift, alt=alt)
        if r in ("submit", "submit_approx"):
            self._calcular(r == "submit_approx")
        elif r == "history_up":
            n = len(self._flat())
            if n:
                self._set_sel(n - 1)

    def escribir(self, s):
        """Atajo: escribe un texto tecla por tecla (como en la TI: ^ abre el exponente, → sale de él)."""
        for ch in s:
            if ch == "→":
                self.tecla("right")
            elif ch == "⏎":
                self.tecla("enter")
            else:
                self.tecla("text", ch)

    # ---------- calcular
    def _calcular(self, aprox=False):
        from .rows import first_empty_required
        row = self.ed.row()
        if not len(row):
            return
        vacia = first_empty_required(self.ed._root)
        if vacia is not None:                 # como la TI: "Sintaxis" y el cursor en la cajita vacía
            self.ed._cur = (vacia, 0)
            self.ed._anchor = None
            self.ed._changed()
            self.mensaje = ("Error", "Sintaxis")
            return
        r = self.calc.calcular(row, aprox)
        if r.tipo == "sintaxis":
            self.mensaje = ("Error", "Sintaxis" + (": " + r.error if r.error else ""))
            return
        if self.calc.historial:
            e = self.calc.historial[-1]
            st = self._stash()
            self._acting = True
            try:
                self.ed.clear()
            finally:
                self._acting = False
            self.ed._undo.clear()
            self.ed._redo.clear()
            self._push({"k": "eval", "e": e, "st": st})

    # ---------- deshacer / rehacer unificados (como la pestaña del PC)
    def _stash(self):
        st = (list(self.ed._undo), self.ed._snap)
        self.ed._undo.clear()
        self.ed._redo.clear()
        return st

    def _unstash(self, st):
        self._acting = True
        try:
            self.ed._restore(st[1])
        finally:
            self._acting = False
        self.ed._undo[:] = list(st[0])
        self.ed._redo.clear()

    def _push(self, act):
        self._acts.append(act)
        del self._acts[:-100]
        self._redo_acts.clear()

    def _edit_changed(self):
        if not self._acting and not self.ed._restoring:
            self._redo_acts.clear()

    def _apply(self, act, back):
        h = self.calc.historial
        if act["k"] == "eval":
            if back:
                act["i"] = h.index(act["e"]) if act["e"] in h else len(h)
                if act["e"] in h:
                    h.remove(act["e"])
                self._unstash(act["st"])
            else:
                act["st"] = self._stash()
                h.insert(min(act.get("i", len(h)), len(h)), act["e"])
                self._acting = True
                try:
                    self.ed.clear()
                finally:
                    self._acting = False
                self.ed._undo.clear()
                self.ed._redo.clear()
        elif act["k"] == "del":
            if back:
                self._unstash(act["st"])
                h.insert(min(act["i"], len(h)), act["e"])
                self._set_sel(self._index_of(act["e"]))
            else:
                act["st"] = self._stash()
                if act["e"] in h:
                    h.remove(act["e"])
        self.calc.guardar()

    def _index_of(self, ent):
        for n, (i, j) in enumerate(self._flat()):
            if j is None and self.calc.historial[i] is ent:
                return n
        return None

    def deshacer(self):
        if self.ed._undo:
            self._set_sel(None)
            self.ed.undo()
            return
        if self._acts:
            act = self._acts.pop()
            self._set_sel(None)
            self._apply(act, True)
            self._redo_acts.append(act)

    def rehacer(self):
        if self.ed._redo:
            self.ed.redo()
            return
        if self._redo_acts:
            act = self._redo_acts.pop()
            self._set_sel(None)
            self._apply(act, False)
            self._acts.append(act)

    def _borrar(self, i):
        h = self.calc.historial
        e = h[i]
        st = self._stash()
        h.pop(i)
        self._push({"k": "del", "e": e, "i": i, "st": st})
        prev = h[i - 1] if i - 1 >= 0 and h else (h[0] if h else None)
        self._set_sel(self._index_of(prev) if prev is not None else None)
        self.calc.guardar()

    # ---------- pantalla
    def pantalla(self, ancho=320, alto=240, px=15, oscuro=False):
        from .render import render_screen
        ents = [(e.entrada, e.filas if not e.error else [Row(list('"Error: ' + e.error + '"'))])
                for e in self.calc.historial]
        return render_screen(ents, None, ancho, alto, px, dark=oscuro, editor=self.ed, sel=self.sel,
                             mensaje=self.mensaje, estado=self.calc.ajustes.short())
