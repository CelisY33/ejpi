"""
rows.py - Modelo de las expresiones en 2D (sin Qt): filas, cajas (fracción, raíz, matriz…), texto lineal,
posiciones del cursor y JSON. Lo usan el motor (fmt), la app de PC y la calculadora física.

    Row      lista de elementos; cada elemento es un str (un carácter, o un "token" de
             varios caracteres que se mueve como una sola unidad) o una caja (Box).
    Cajas    Sup (exponente), Sub (subíndice), Frac, Sqrt, NRoot, Abs, Paren, Matrix…
             Cada caja expone slots(): sus Row en orden de navegación.
    to_linear(row) pasa el árbol a texto lineal para el motor de cálculo.
"""
from __future__ import annotations

import copy

# ---------------------------------------------------------------- modelo


class Row(list):
    """Fila de elementos (str o Box)."""

    def __deepcopy__(self, memo):
        r = Row()
        memo[id(self)] = r
        r.extend(copy.deepcopy(x, memo) for x in self)
        return r

    def __repr__(self):
        return "Row(%s)" % list.__repr__(self)


class Ghost(str):
    """Letra "fantasma" (Ans en gris): se calcula con ella si se aprieta Enter, pero desaparece al escribir."""
    __slots__ = ()


def iter_rows(root):
    """Todas las filas del árbol (la raíz y las de adentro de las cajas)."""
    yield root
    for it in root:
        if isinstance(it, Box):
            for s in it.slots():
                yield from iter_rows(s)


def solidify(root):
    """Las letras fantasma pasan a ser texto normal."""
    for r in iter_rows(root):
        for i, x in enumerate(r):
            if isinstance(x, Ghost):
                r[i] = str(x)


def _row(x=None) -> Row:
    if x is None:
        return Row()
    if isinstance(x, Row):
        return x
    if isinstance(x, str):
        return from_text(x)
    return Row(x)


class Box:
    def slots(self) -> list:
        return []

    def is_empty(self) -> bool:
        return all(len(s) == 0 for s in self.slots())

    def linear(self) -> str:
        return ""

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(repr(s) for s in self.slots()))


class Sup(Box):
    """Exponente: la base es lo que está antes en la fila."""

    def __init__(self, row=None):
        self.row = _row(row)

    def slots(self):
        return [self.row]

    def linear(self):
        return "^(" + to_linear(self.row) + ")"


class Sub(Box):
    """Subíndice (solo para mostrar)."""

    def __init__(self, row=None):
        self.row = _row(row)

    def slots(self):
        return [self.row]

    def linear(self):
        return to_linear(self.row)


class Frac(Box):
    def __init__(self, num=None, den=None):
        self.num = _row(num)
        self.den = _row(den)

    def slots(self):
        return [self.num, self.den]

    def linear(self):
        return "((%s)/(%s))" % (to_linear(self.num), to_linear(self.den))


class Sqrt(Box):
    def __init__(self, row=None):
        self.row = _row(row)

    def slots(self):
        return [self.row]

    def linear(self):
        return "√(" + to_linear(self.row) + ")"


class NRoot(Box):
    """Raíz n-ésima: primero el índice (opcional, vacío = 2), después lo de adentro."""
    optional = {0}

    def __init__(self, index=None, row=None):
        self.index = _row(index)
        self.row = _row(row)

    def slots(self):
        return [self.index, self.row]

    def linear(self):
        i = to_linear(self.index)
        return "root(%s,%s)" % (to_linear(self.row), i) if i else "√(" + to_linear(self.row) + ")"


class Abs(Box):
    def __init__(self, row=None):
        self.row = _row(row)

    def slots(self):
        return [self.row]

    def linear(self):
        return "abs(" + to_linear(self.row) + ")"


CLOSE = {"(": ")", "[": "]", "{": "}"}


class Paren(Box):
    """Paréntesis que crecen con lo de adentro (solo para mostrar)."""

    def __init__(self, row=None, kind="("):
        self.row = _row(row)
        self.kind = kind if kind in CLOSE else "("

    def slots(self):
        return [self.row]

    def linear(self):
        return self.kind + to_linear(self.row) + CLOSE[self.kind]


class Matrix(Box):
    def __init__(self, rows=None):
        self.rows = [[_row(c) for c in r] for r in (rows or [[None]])]

    @classmethod
    def empty(cls, nrows, ncols):
        return cls([[None] * ncols for _ in range(nrows)])

    @property
    def ncols(self):
        return max(len(r) for r in self.rows) if self.rows else 0

    def slots(self):
        return [c for r in self.rows for c in r]

    def linear(self):
        return "[" + "".join("[" + ",".join(to_linear(c) for c in r) + "]" for r in self.rows) + "]"


class System(Box):
    """Sistema de ecuaciones como en la TI: una ecuación bajo la otra, con una llave a la izquierda."""

    def __init__(self, rows=None):
        self.rows = [_row(r) for r in (rows or [None])]

    def slots(self):
        return self.rows

    def is_empty(self):
        return all(len(r) == 0 for r in self.rows)

    def linear(self):
        return "{" + ",".join(to_linear(r) for r in self.rows) + "}"


class LogBase(Box):
    """log con base: log_base(arg). La base es opcional (vacía = 10)."""
    optional = {0}

    def __init__(self, base=None, arg=None):
        self.base, self.arg = _row(base), _row(arg)

    def slots(self):
        return [self.base, self.arg]

    def linear(self):
        b = to_linear(self.base)
        return "log(%s%s)" % (to_linear(self.arg), "," + b if b else "")


class Piecewise(Box):
    """Función por tramos: filas (valor, condición). La última condición es opcional."""

    def __init__(self, rows=None):
        self.rows = [[_row(a), _row(b)] for a, b in (rows or [[None, None], [None, None]])]

    @property
    def optional(self):
        return {2 * len(self.rows) - 1}

    def slots(self):
        return [c for r in self.rows for c in r]

    def linear(self):
        parts = []
        for v, c in self.rows:
            parts.append(to_linear(v))
            cl = to_linear(c)
            parts.append(cl if cl and cl != "Else" else "true")
        return "piecewise(" + ",".join(parts) + ")"


class BigOp(Box):
    """Σ o Π: variable, desde, hasta, cuerpo."""

    def __init__(self, op="Σ", var=None, lo=None, hi=None, body=None):
        self.op = op
        self.var, self.lo, self.hi, self.body = _row(var), _row(lo), _row(hi), _row(body)

    def slots(self):
        return [self.var, self.lo, self.hi, self.body]

    def linear(self):
        return "%s(%s,%s,%s,%s)" % (self.op, to_linear(self.body), to_linear(self.var),
                                    to_linear(self.lo), to_linear(self.hi))


class Deriv(Box):
    """d/dx( ): variable, (orden), expresión. order=None: primera derivada sin cajita de orden."""

    def __init__(self, var=None, body=None, order=None, has_order=False):
        self.var, self.body = _row(var), _row(body)
        self.order = _row(order) if (order is not None or has_order) else None

    @property
    def optional(self):
        return {1} if self.order is not None else set()

    def slots(self):
        return [self.var, self.order, self.body] if self.order is not None else [self.var, self.body]

    def linear(self):
        o = to_linear(self.order) if self.order is not None else ""
        return "derivative(%s,%s%s)" % (to_linear(self.body), to_linear(self.var), "," + o if o and o != "1" else "")


class Integral(Box):
    """∫: definida (desde, hasta, integrando, variable) o indefinida (integrando, variable)."""

    def __init__(self, body=None, var=None, lo=None, hi=None, definite=False):
        self.definite = definite
        self.body, self.var = _row(body), _row(var)
        self.lo, self.hi = (_row(lo), _row(hi)) if definite else (None, None)

    @property
    def optional(self):
        return {0, 1} if self.definite else set()

    def slots(self):
        return [self.lo, self.hi, self.body, self.var] if self.definite else [self.body, self.var]

    def linear(self):
        if self.definite and (self.lo or self.hi):
            return "∫(%s,%s,%s,%s)" % (to_linear(self.body), to_linear(self.var), to_linear(self.lo),
                                       to_linear(self.hi))
        return "∫(%s,%s)" % (to_linear(self.body), to_linear(self.var))


class Limit(Box):
    """lím: variable, punto, dirección (opcional, + o −), expresión."""
    optional = {2}

    def __init__(self, var=None, point=None, direction=None, body=None):
        self.var, self.point, self.dir, self.body = _row(var), _row(point), _row(direction), _row(body)

    def slots(self):
        return [self.var, self.point, self.dir, self.body]

    def linear(self):
        d = to_linear(self.dir).replace("−", "-")
        dd = ""
        if d in ("+", "1", "+1"):
            dd = ",1"
        elif d in ("-", "-1"):
            dd = ",-1"
        return "limit(%s,%s,%s%s)" % (to_linear(self.body), to_linear(self.var), to_linear(self.point), dd)


class SubVar(Box):
    """Plantilla de subíndice de la TI: x₁ es un nombre de variable."""

    def __init__(self, base=None, sub=None):
        self.base, self.sub = _row(base), _row(sub)

    def slots(self):
        return [self.base, self.sub]

    def linear(self):
        return to_linear(self.base) + "_" + to_linear(self.sub)


def optional_slots(box) -> set:
    return set(getattr(box, "optional", set()) or set())


def first_empty_required(root):
    """Primera cajita obligatoria vacía (para avisar como la TI y poner el cursor ahí)."""
    for it in root:
        if isinstance(it, Box):
            opt = optional_slots(it)
            if isinstance(it, Sup) and len(it.row) == 0:
                return it.row
            for i, sl in enumerate(it.slots()):
                if len(sl) == 0 and i not in opt and not isinstance(it, (Matrix,)):
                    return sl
                if len(sl) == 0 and isinstance(it, Matrix):
                    return sl
                r = first_empty_required(sl)
                if r is not None:
                    return r
    return None


# nombres de funciones conocidas (se dibujan en negrita, como en la TI); los pone la calculadora
KNOWN_FUNCS: set = set()
SYSTEM_FUNCS = ("solve(", "csolve(", "linsolve(", "nsolve(")


def to_linear(row) -> str:
    return "".join(it if isinstance(it, str) else it.linear() for it in row)


def from_text(s: str) -> Row:
    """Texto plano -> fila de caracteres."""
    return Row(ch for ch in s if ch not in "\r\n")


def parse_template(s: str):
    """Plantilla de texto con un "|" donde queda el cursor -> (Row, índice del cursor)."""
    i = s.find("|")
    if i < 0:
        return from_text(s), len(from_text(s))
    before = from_text(s[:i])
    return Row(list(before) + list(from_text(s[i + 1:].replace("|", "")))), len(before)


def find_parent(root: Row, target: Row):
    """Busca la caja que contiene la fila target -> (fila, índice de la caja, caja, n° de slot)."""
    for i, it in enumerate(root):
        if isinstance(it, Box):
            for si, s in enumerate(it.slots()):
                if s is target:
                    return root, i, it, si
                r = find_parent(s, target)
                if r:
                    return r
    return None


# ---------------------------------------------------------------- selección con el mouse
def caret_chain(root, row, idx):
    """Camino desde la fila raíz hasta una posición del cursor: [(fila, índice), …]."""
    chain = [(row, idx)]
    while True:
        par = find_parent(root, row)
        if par is None:
            break
        prow, pidx, _box, _si = par
        chain.insert(0, (prow, pidx))
        row = prow
    return chain


def sel_range(root, a, b):
    """Entre dos posiciones del cursor -> (fila, desde, hasta) en la fila común (cajas enteras)."""
    if a is None or b is None:
        return None
    ca, cb = caret_chain(root, *a), caret_chain(root, *b)
    lv = 0
    while lv + 1 < min(len(ca), len(cb)) and ca[lv + 1][0] is cb[lv + 1][0]:
        lv += 1
    row = ca[lv][0]
    spans = []
    for ch in (ca, cb):
        i = ch[lv][1]
        spans.append((i, i) if lv == len(ch) - 1 else (i, i + 1))
    start = min(spans[0][0], spans[1][0])
    end = max(spans[0][1], spans[1][1])
    if start == end:
        return None
    return row, start, end


def sel_rect(carets, sel, full_top, full_bot):
    """Rectángulo (x0, x1, top, bot) de la selección según las posiciones del cursor."""
    row, start, end = sel
    xs = {i: (x, t, b) for r, i, x, t, b in carets if r is row}
    if start not in xs or end not in xs:
        return None
    tops = [v[1] for v in xs.values()]
    bots = [v[2] for v in xs.values()]
    if not any(r is row for r, *_ in carets[:1]):     # fila anidada: solo su alto
        return xs[start][0], xs[end][0], min(tops), max(bots)
    return xs[start][0], xs[end][0], full_top, full_bot


def _nearest(carets, x, y):
    best, score = None, None
    for r, i, cx, t, b in carets:
        dy = 0.0 if t <= y <= b else min(abs(y - t), abs(y - b))
        sc = abs(x - cx) + 2.5 * dy
        if score is None or sc < score:
            best, score = (r, i), sc
    return best


SEL_COLOR = "#BCD3F7"


def cursor_path(root, row, idx):
    """(fila, índice) -> [(índice de caja, n° de slot), …] + índice final (sirve tras copiar el árbol)."""
    steps = []
    while True:
        par = find_parent(root, row)
        if par is None:
            break
        prow, pidx, box, si = par
        steps.insert(0, (pidx, si))
        row = prow
    return steps, idx


def cursor_from_path(root, path):
    steps, idx = path
    row = root
    try:
        for pidx, si in steps:
            row = row[pidx].slots()[si]
    except (IndexError, AttributeError):
        return root, len(root)
    return row, min(idx, len(row))


# ---------------------------------------------------------------- filas <-> JSON (historial)
def row_to_json(row):
    out = []
    for it in row:
        if isinstance(it, str):
            out.append(it)
        elif isinstance(it, Matrix):
            out.append({"t": "Matrix", "r": [[row_to_json(c) for c in r] for r in it.rows]})
        elif isinstance(it, Paren):
            out.append({"t": "Paren", "k": it.kind, "s": [row_to_json(s) for s in it.slots()]})
        elif isinstance(it, System):
            out.append({"t": "System", "s": [row_to_json(s) for s in it.rows]})
        elif isinstance(it, Piecewise):
            out.append({"t": "Piecewise", "r": [[row_to_json(a), row_to_json(b)] for a, b in it.rows]})
        elif isinstance(it, BigOp):
            out.append({"t": "BigOp", "op": it.op, "s": [row_to_json(s) for s in it.slots()]})
        elif isinstance(it, Deriv):
            out.append({"t": "Deriv", "v": row_to_json(it.var), "b": row_to_json(it.body),
                        "o": row_to_json(it.order) if it.order is not None else None})
        elif isinstance(it, Integral):
            out.append({"t": "Integral", "def": it.definite, "b": row_to_json(it.body), "v": row_to_json(it.var),
                        "lo": row_to_json(it.lo) if it.definite else None,
                        "hi": row_to_json(it.hi) if it.definite else None})
        else:
            out.append({"t": type(it).__name__, "s": [row_to_json(s) for s in it.slots()]})
    return out


_BOXES = {"Sup": Sup, "Sub": Sub, "Frac": Frac, "Sqrt": Sqrt, "NRoot": NRoot, "Abs": Abs, "LogBase": LogBase,
          "Limit": Limit, "SubVar": SubVar}


def row_from_json(data):
    r = Row()
    for it in data or []:
        if isinstance(it, str):
            r.append(it)
            continue
        t = it.get("t")
        if t == "Matrix":
            r.append(Matrix([[row_from_json(c) for c in rr] for rr in it["r"]]))
        elif t == "System":
            r.append(System([row_from_json(x) for x in it["s"]]))
        elif t == "Paren":
            r.append(Paren(row_from_json(it["s"][0]), it.get("k", "(")))
        elif t == "Piecewise":
            r.append(Piecewise([[row_from_json(a), row_from_json(b)] for a, b in it["r"]]))
        elif t == "BigOp":
            r.append(BigOp(it.get("op", "Σ"), *[row_from_json(s) for s in it["s"]]))
        elif t == "Deriv":
            r.append(Deriv(row_from_json(it["v"]), row_from_json(it["b"]),
                           row_from_json(it["o"]) if it.get("o") is not None else None))
        elif t == "Integral":
            d = bool(it.get("def"))
            r.append(Integral(row_from_json(it["b"]), row_from_json(it["v"]),
                              row_from_json(it.get("lo")) if d else None, row_from_json(it.get("hi")) if d else None, d))
        elif t in _BOXES:
            r.append(_BOXES[t](*[row_from_json(s) for s in it["s"]]))
    return r


def to_plain(row) -> str:
    """Texto de corrido para leer (terminal): fracciones a/b, x^2, √(…), sin los paréntesis de sobra de to_linear."""
    def simple(r):
        s = to_plain(r)
        if len(r) == 1 and isinstance(r[0], str):
            return True
        return s.replace(".", "").replace("‑", "").replace("-", "").isalnum() and len(s) <= 12
    out = []
    for it in row:
        if isinstance(it, str):
            out.append(it)
        elif isinstance(it, Frac):
            n, d = to_plain(it.num), to_plain(it.den)
            out.append((n if simple(it.num) else "(" + n + ")") + "/" + (d if simple(it.den) else "(" + d + ")"))
        elif isinstance(it, Sup):
            e = to_plain(it.row)
            out.append("^" + (e if simple(it.row) else "(" + e + ")"))
        elif isinstance(it, Sqrt):
            out.append("√(" + to_plain(it.row) + ")")
        elif isinstance(it, Paren):
            out.append(it.kind + to_plain(it.row) + CLOSE[it.kind])
        elif isinstance(it, Abs):
            out.append("|" + to_plain(it.row) + "|")
        elif isinstance(it, Matrix):
            out.append("[" + "".join("[" + ",".join(to_plain(c) for c in r) + "]" for r in it.rows) + "]")
        elif isinstance(it, Integral):
            lim = (",%s,%s" % (to_plain(it.lo), to_plain(it.hi))) if it.definite and (it.lo or it.hi) else ""
            out.append("∫(%s,%s%s)" % (to_plain(it.body), to_plain(it.var), lim))
        elif isinstance(it, Deriv):
            o = to_plain(it.order) if it.order is not None else ""
            out.append("d%s/d%s%s(%s)" % ("^" + o if o and o != "1" else "", to_plain(it.var),
                                         "^" + o if o and o != "1" else "", to_plain(it.body)))
        elif isinstance(it, NRoot):
            i = to_plain(it.index)
            out.append(("root(%s,%s)" % (to_plain(it.row), i)) if i else "√(" + to_plain(it.row) + ")")
        else:
            out.append(it.linear())
    return "".join(out).replace("‑", "-")
