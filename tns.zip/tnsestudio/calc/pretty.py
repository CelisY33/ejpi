"""
pretty.py - Como la TI, la entrada que queda en el historial se muestra "bonita":
a/b como fracción apilada, derivative(…) como d/dx, ∫, Σ, lím, log con base, raíces,
5x como 5·x y los nombres de función con sus mayúsculas (csolve -> cSolve).

Trabaja sobre filas de mathview; si algo no calza, deja la fila como estaba.
"""
from __future__ import annotations

import copy

from .rows import (Abs, BigOp, Box, Deriv, Frac, Integral, LogBase, Limit, NRoot, Row, Sqrt,
                       to_linear)

NAME_CHARS = set("\\_")
STOP_LEFT = set("+-−=<>≤≥≠,;|→▸∠") | {" and ", " or "}
CANON: dict[str, str] = {}


def set_canonical(names):
    """names: nombres de funciones tal como se muestran (cSolve, nSolve, …)."""
    for n in names:
        CANON[n.lower()] = n


def _is_name_char(it):
    return isinstance(it, str) and len(it) == 1 and (it.isalnum() or it in NAME_CHARS)


def _match(row, i):
    """Índice del cierre que corresponde al "(" en i (o -1)."""
    depth = 0
    for k in range(i, len(row)):
        it = row[k]
        if it == "(":
            depth += 1
        elif it == ")":
            depth -= 1
            if depth == 0:
                return k
    return -1


def _split_args(items):
    out, cur, depth = [], Row(), 0
    for it in items:
        if it in ("(", "[", "{"):
            depth += 1
        elif it in (")", "]", "}"):
            depth -= 1
        if it == "," and depth == 0:
            out.append(cur)
            cur = Row()
        else:
            cur.append(it)
    out.append(cur)
    return out


def _strip(r):
    if len(r) >= 2 and r[0] == "(" and _match(r, 0) == len(r) - 1:
        return Row(r[1:-1])
    return r


def _functions(row):
    """Convierte llamadas conocidas en plantillas y corrige mayúsculas de nombres."""
    out = Row()
    i = 0
    n = len(row)
    while i < n:
        it = row[i]
        if it in ("∫", "Σ", "Π", "√") and i + 1 < n and row[i + 1] == "(":
            k = _match(row, i + 1)
            if k > 0:
                args = [prettify(a) for a in _split_args(row[i + 2:k])]
                box = _template({"∫": "integral", "Σ": "Σ", "Π": "Π", "√": "sqrt"}[it], args)
                if box is not None:
                    out.append(box)
                    i = k + 1
                    continue
        if _is_name_char(it) and it.isalpha() and not (out and _is_name_char(out[-1])) and not (out and out[-1] == "_"):
            j = i
            while j < n and _is_name_char(row[j]):
                j += 1
            name = "".join(row[i:j])
            low = name.lower()
            if j < n and row[j] == "(":
                k = _match(row, j)
                if k > 0:
                    args = [prettify(a) for a in _split_args(row[j + 1:k])]
                    box = _template(low, args)
                    if box is not None:
                        out.append(box)
                        i = k + 1
                        continue
                    out.extend(list(CANON.get(low, name)))
                    out.append("(")
                    for ai, a in enumerate(args):
                        if ai:
                            out.append(",")
                        out.extend(a)
                    out.append(")")
                    i = k + 1
                    continue
            out.extend(list(CANON.get(low, name)) if low in CANON else row[i:j])
            i = j
            continue
        if it in ("∫", "Σ", "Π", "√") and i + 1 < n and row[i + 1] == "(":
            k = _match(row, i + 1)
            if k > 0:
                args = [prettify(a) for a in _split_args(row[i + 2:k])]
                box = _template({"∫": "integral", "Σ": "Σ", "Π": "Π", "√": "sqrt"}[it], args)
                if box is not None:
                    out.append(box)
                    i = k + 1
                    continue
        out.append(it)
        i += 1
    return out


def _template(name, a):
    try:
        if name in ("derivative", "deriv", "diff") and len(a) in (2, 3):
            if len(a) == 3:
                return Deriv(a[1], _strip(a[0]), a[2])
            return Deriv(a[1], _strip(a[0]))
        if name in ("integral", "integrate", "∫") and len(a) in (2, 4):
            if len(a) == 4:
                return Integral(a[0], a[1], a[2], a[3], definite=True)
            return Integral(a[0], a[1])
        if name in ("Σ", "Π") and len(a) == 4:
            return BigOp(name, a[1], a[2], a[3], _strip(a[0]))
        if name in ("limit", "lim") and len(a) in (3, 4):
            d = Row()
            if len(a) == 4:
                t = to_linear(a[3]).replace("−", "-")
                d = Row(["+"]) if t.lstrip("+") in ("1",) else Row(["‑"]) if t in ("-1",) else Row()
            return Limit(a[1], a[2], d, _strip(a[0]))
        if name == "log" and len(a) == 2:
            return LogBase(a[1], a[0])
        if name == "root" and len(a) == 2:
            return NRoot(a[1], a[0])
        if name == "sqrt" and len(a) == 1:
            return Sqrt(a[0])
        if name == "abs" and len(a) == 1:
            return Abs(a[0])
    except Exception:  # noqa: BLE001
        return None
    return None


def _operand_left(row, i):
    """Desde el "/" en i, hacia la izquierda: toda la cadena de factores (2·z), hasta un + − = …"""
    k = i
    depth = 0
    while k > 0:
        it = row[k - 1]
        if it in (")", "]", "}"):
            depth += 1
        elif it in ("(", "[", "{"):
            if depth == 0:
                break
            depth -= 1
        elif depth == 0 and isinstance(it, str) and (it in STOP_LEFT or it == "/"):
            break
        k -= 1
    return k


def _operand_right(row, i):
    """Desde el "/" en i, hacia la derecha: un factor (número, nombre, (…), función(…), caja) y sus ^."""
    n = len(row)
    k = i + 1
    if k >= n:
        return k
    it = row[k]
    if it in ("‑", "-") and k + 1 < n:                      # signo negativo
        k += 1
        it = row[k]
    if it == "(":
        m = _match(row, k)
        k = (m + 1) if m > 0 else k + 1
    elif isinstance(it, Box):
        k += 1
    elif _is_name_char(it) or it == ".":
        while k < n and (_is_name_char(row[k]) or row[k] == "."):
            k += 1
        if k < n and row[k] == "(":
            m = _match(row, k)
            k = (m + 1) if m > 0 else k + 1
    else:
        k += 1
    while k < n and type(row[k]).__name__ in ("Sup",):
        k += 1
    return k


def _fractions(row):
    row = Row(row)
    for _ in range(50):
        depth = 0
        idx = -1
        for k, it in enumerate(row):
            if it in ("(", "[", "{"):
                depth += 1
            elif it in (")", "]", "}"):
                depth -= 1
            elif it == "/":
                idx = k
                break
        if idx < 0:
            # también dentro de paréntesis sueltos
            return row
        a = _operand_left(row, idx)
        b = _operand_right(row, idx)
        if a == idx or b == idx + 1:
            return row
        num = _strip(Row(row[a:idx]))
        den = _strip(Row(row[idx + 1:b]))
        row[a:b] = [Frac(num, den)]
    return row


def _in_name(out):
    """¿El número del final es parte de un nombre (pot3f, x2, c1)? Entonces no va ·."""
    j = len(out) - 1
    while j >= 0 and isinstance(out[j], str) and len(out[j]) == 1 and (out[j].isalnum() or out[j] in "_\\"):
        if out[j].isalpha() or out[j] == "_":
            return True
        j -= 1
    return False


def _dots(row):
    """5x -> 5·x y )( -> )·( (como la TI)."""
    out = Row()
    for k, it in enumerate(row):
        if out:
            prev = out[-1]
            if isinstance(prev, str) and len(prev) == 1 and prev in "0123456789" and not _in_name(out) and \
                    isinstance(it, str) and len(it) == 1 and (it.isalpha() or it in "(πℯⅈ_") and it not in "ᴇE":
                out.append("·")
            elif prev == ")" and it == "(":
                out.append("·")
        out.append(it)
    return out


def _deep(row, depth=0):
    """Fracciones y puntos (3x -> 3·x) en todas las cajas anidadas, a cualquier profundidad."""
    if depth > 30:
        return
    for it in row:
        if isinstance(it, Box):
            for sl in it.slots():
                if sl is not None:
                    sl[:] = _dots(_fractions(sl))
                    _deep(sl, depth + 1)


def prettify(row) -> Row:
    try:
        r = copy.deepcopy(Row(row))
        r = _functions(r)
        r = _fractions(r)
        r = _dots(r)
        _deep(r)
        return r
    except Exception:  # noqa: BLE001
        return Row(row)


AT = {"i": "ⅈ", "<": "∠", ">": "▸", "e": "ℯ", "E": "ᴇ", "d": "°", "t": "ᵀ", "r": "ʳ", "g": "ᵍ"}


def from_linear(text: str) -> Row:
    """Texto escrito de corrido (terminal, archivos) -> fila 2D como si se hubiera escrito en la línea de la TI:
    @i -> ⅈ, @< -> ∠…, x^2 / x^(n+1) con su cajita de exponente, y después las fracciones y raíces de prettify."""
    from .rows import Sup
    s = text.replace("\r", "").replace("\n", "")
    out = []
    i = 0
    while i < len(s):
        if s[i] == "@" and i + 1 < len(s) and s[i + 1] in AT:
            out.append(AT[s[i + 1]])
            i += 2
        else:
            out.append(s[i])
            i += 1

    def build(chars):
        row = Row()
        k = 0
        while k < len(chars):
            c = chars[k]
            if c == "^" and k + 1 < len(chars):
                k += 1
                if chars[k] == "(":
                    depth, j = 0, k
                    while j < len(chars):
                        depth += chars[j] == "("
                        depth -= chars[j] == ")"
                        if depth == 0:
                            break
                        j += 1
                    inner = chars[k + 1:j]
                    k = j + 1
                else:
                    j = k
                    if chars[j] in "-−":
                        j += 1
                    while j < len(chars) and (chars[j].isalnum() or chars[j] in ".ᴇ"):
                        j += 1
                    inner = chars[k:j] if j > k else [chars[k]]
                    k = max(j, k + 1)
                row.append(Sup(build(inner)))
                continue
            row.append(c)
            k += 1
        return row
    return prettify(build(out))
