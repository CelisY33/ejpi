"""
editor.py - La línea de entrada 2D de la TI, sin Qt: cursor, cajitas (exponente, fracción, raíz, matriz…),
paréntesis inteligentes, Ans gris, sistemas con {, Tab entre datos y deshacer tecla por tecla.

La usan la app de PC (mathview.MathEdit hereda de Editor y solo agrega dibujo, mouse y portapapeles de Qt)
y la calculadora física (las teclas llegan por nombre con Editor.key).

    ed = Editor()
    ed.key("text", "x"); ed.key("text", "^"); ed.key("text", "2"); ed.key("right")
    ed.text()  -> "x^(2)"        ed.row() -> fila 2D para calcular o dibujar
    ed.key("enter") -> "submit"  (lo que el editor no resuelve solo lo devuelve como evento)
"""
from __future__ import annotations

import copy

from .rows import (SYSTEM_FUNCS, Abs, BigOp, Box, Deriv, Frac, Ghost, Integral, Limit, LogBase, Matrix,  # noqa: F401
                   NRoot, Piecewise, Row, Sqrt, SubVar, Sup, System, _row, cursor_from_path, cursor_path,
                   find_parent, iter_rows, parse_template, sel_range, solidify, to_linear)


class Editor:
    """Estado y edición de la línea (sin dibujo)."""

    def __init__(self):
        self._root = Row()
        self._cur = (self._root, 0)
        self._anchor = None          # inicio de la selección (fila, índice) o None
        self._undo, self._redo = [], []
        self._snap = (repr(self._root), copy.deepcopy(self._root), ([], 0))
        self._snap_t = 0.0
        self._restoring = False
        self.undoHook = None         # Ctrl+Z / Ctrl+Y los puede manejar quien contiene la línea (historial)
        self.redoHook = None
        self.historyMode = False     # recorriendo el historial con ↑: sin cursor y cajita punteada (TI)
        self.onChange = None         # función sin argumentos que se llama después de cada cambio
        self._clip = ""              # portapapeles propio (la app de PC usa el de Qt)
        self._xoff = 0.0

    # ----- portapapeles (la app de PC lo cambia por el del sistema)
    def getClipboard(self) -> str:
        return self._clip

    def setClipboard(self, s: str):
        self._clip = s

    # ----- API
    def row(self) -> Row:
        r = copy.deepcopy(self._root)
        solidify(r)
        return r

    def setRow(self, row, cursor_at_end=True):
        self._root = copy.deepcopy(_row(row))
        self._anchor = None
        self._cur = (self._root, len(self._root) if cursor_at_end else 0)
        self._xoff = 0.0
        self._changed()

    def clear(self):
        self.setRow(Row())

    def text(self) -> str:
        return to_linear(self._root)

    def isEmpty(self) -> bool:
        return len(self._root) == 0

    def cursor(self):
        """(fila, índice) del cursor (la fila es parte del árbol interno)."""
        return self._cur

    # ----- selección
    def selection(self):
        return sel_range(self._root, self._anchor, self._cur) if self._anchor else None

    def selectedText(self) -> str:
        sel = self.selection()
        if not sel:
            return ""
        row, a, b = sel
        return to_linear(Row(row[a:b]))

    def selectAll(self):
        self._anchor = (self._root, 0)
        self._cur = (self._root, len(self._root))
        self._changed()

    # ----- Ans fantasma (en gris): Enter calcula con él; escribir, borrar o ↑ lo sacan
    def setGhost(self, text="Ans"):
        row, idx = self._cur
        for k, ch in enumerate(text):
            row.insert(idx + k, Ghost(ch))
        self._changed()

    def _ghost_loc(self):
        for r in iter_rows(self._root):
            for i, x in enumerate(r):
                if isinstance(x, Ghost):
                    return r, i
        return None

    def hasGhost(self) -> bool:
        return self._ghost_loc() is not None

    def dropGhost(self) -> bool:
        loc = self._ghost_loc()
        if loc is None:
            return False
        row, start = loc
        n = sum(1 for x in row if isinstance(x, Ghost))
        crow, cidx = self._cur
        row[:] = [x for x in row if not isinstance(x, Ghost)]
        if crow is row and cidx > start:
            self._cur = (row, max(start, cidx - n))
        return True

    def solidGhost(self) -> bool:
        """El Ans gris pasa a ser Ans escrito (cuando se mueve el cursor o se escribe un operador)."""
        loc = self._ghost_loc()
        if loc is None:
            return False
        solidify(self._root)
        return True

    def _del_sel(self) -> bool:
        self.dropGhost()
        sel = self.selection()
        self._anchor = None
        if not sel:
            return False
        row, a, b = sel
        del row[a:b]
        self._cur = (row, a)
        return True

    def insertFraction(self):
        """Ctrl+/ : fracción una arriba de la otra. Lo seleccionado o lo recién escrito (z, 2x, x^2,
        (a+b)) pasa al numerador y el cursor queda en el denominador; si no hay nada, cajita vacía."""
        if self.solidGhost():
            loc_row, loc_idx = self._cur
            self._cur = (loc_row, min(len(loc_row), loc_idx + 3))     # Ans/□ como la TI
        sel = self.selection()
        if sel:
            row, a, b = sel
            num = Row(row[a:b])
            del row[a:b]
            self._anchor = None
            box = Frac(num, None)
            row.insert(a, box)
            self._cur = (box.den, 0)
            self._changed()
            return
        row, idx = self._cur
        j = idx
        if j > 0 and row[j - 1] == ")":
            depth = 0
            k = j - 1
            while k >= 0:
                if row[k] == ")":
                    depth += 1
                elif row[k] == "(":
                    depth -= 1
                    if depth == 0:
                        break
                k -= 1
            j = max(k, 0)
            while j > 0 and isinstance(row[j - 1], str) and len(row[j - 1]) == 1 and row[j - 1].isalpha():
                j -= 1                      # nombre de función: sin(x)
        else:
            while j > 0:
                it = row[j - 1]
                if isinstance(it, (Sup, Sqrt, NRoot, Abs, Frac)) or (
                        isinstance(it, str) and len(it) == 1 and (it.isalnum() or it in "._ⅈπℯ°")):
                    j -= 1
                else:
                    break
        if j < idx:
            num = Row(row[j:idx])
            del row[j:idx]
            if len(num) >= 2 and num[0] == "(" and num[-1] == ")":
                depth = 0
                for n_, it in enumerate(num):
                    depth += 1 if it == "(" else -1 if it == ")" else 0
                    if depth == 0 and n_ < len(num) - 1:
                        break
                else:
                    num = Row(num[1:-1])          # (a+b)/c -> a+b arriba, sin paréntesis
            box = Frac(num, None)
            row.insert(j, box)
            self._cur = (box.den, 0)
            self._changed()
        else:
            self.insertBox("frac")

    def insertText(self, s: str):
        self._del_sel()
        row, idx = self._cur
        tpl, ci = parse_template(s)
        for k, it in enumerate(tpl):
            row.insert(idx + k, it)
        self._cur = (row, idx + (ci if "|" in s else len(tpl)))
        self._changed()

    def insertBox(self, kind: str):
        if kind == "sup":
            box = Sup()
        elif kind == "frac":
            box = Frac()
        elif kind == "sqrt":
            box = Sqrt()
        elif kind == "nroot":
            box = NRoot()
        elif kind == "abs":
            box = Abs()
        elif kind.startswith("matrix"):
            r, c = 2, 2
            try:
                r, c = (int(v) for v in kind.split(":", 1)[1].lower().split("x"))
            except (IndexError, ValueError):
                pass
            box = Matrix.empty(max(1, r), max(1, c))
        elif kind == "log":
            box = LogBase()
        elif kind.startswith("piecewise"):
            n = int(kind.split(":")[1]) if ":" in kind else 2
            box = Piecewise([[None, None] for _ in range(max(1, n))])
        elif kind.startswith("system"):
            n = int(kind.split(":")[1]) if ":" in kind else 2
            box = System([None] * max(1, n))
        elif kind in ("sum", "prod"):
            box = BigOp("Σ" if kind == "sum" else "Π")
        elif kind == "deriv":
            box = Deriv()
        elif kind == "deriv2":
            box = Deriv(order=Row(["2"]))
        elif kind == "derivn":
            box = Deriv(has_order=True)
        elif kind == "int_def":
            box = Integral(definite=True)
        elif kind == "int":
            box = Integral()
        elif kind == "lim":
            box = Limit()
        elif kind == "subvar":
            box = SubVar()
        else:
            raise ValueError("caja desconocida: %s" % kind)
        self._insert_box(box)

    def addRow(self, column=False) -> bool:
        """↵ (o Alt+Enter) agrega una fila a la matriz, sistema o función por tramos donde está el
        cursor; Shift+↵ agrega una columna a la matriz."""
        row, idx = self._cur
        par = self._parent(row)
        while par is not None:
            prow, pidx, box, si = par
            if isinstance(box, Matrix):
                nc = box.ncols
                r, c = divmod(si, nc)
                if column:
                    for rr in box.rows:
                        rr.insert(c + 1, Row())
                    self._cur = (box.rows[r][c + 1], 0)
                else:
                    box.rows.insert(r + 1, [Row() for _ in range(nc)])
                    self._cur = (box.rows[r + 1][0], 0)
                self._changed()
                return True
            if isinstance(box, System) and not column:
                box.rows.insert(si + 1, Row())
                self._cur = (box.rows[si + 1], 0)
                self._changed()
                return True
            if isinstance(box, Piecewise) and not column:
                r = si // 2
                box.rows.insert(r + 1, [Row(), Row()])
                self._cur = (box.rows[r + 1][0], 0)
                self._changed()
                return True
            par = self._parent(prow)
        return False

    def _ans_first(self, t) -> bool:
        """Como la TI: un operador al comienzo de la línea vacía usa Ans (Ans+, Ans^□, Ans²…)."""
        row, idx = self._cur
        return row is self._root and not self._root and t in ("+", "*", "/", "^", "=", "·", "×", "÷", "²", "▸", "→")

    def _put_ans(self):
        for ch in "Ans":
            self._root.append(ch)
        self._cur = (self._root, 3)

    def insertPower(self, base: str = "ℯ"):
        self._del_sel()
        row, idx = self._cur
        row.insert(idx, base)
        self._cur = (row, idx + 1)
        self._insert_box(Sup())

    def insertRow(self, row):
        self._del_sel()
        r, idx = self._cur
        items = list(copy.deepcopy(_row(row)))
        for k, it in enumerate(items):
            r.insert(idx + k, it)
        self._cur = (r, idx + len(items))
        self._changed()

    def insertSystem(self, n=2, fn="solve", variables="x,y"):
        """solve( {ecuación / ecuación} ,{x,y}) con el cursor en la primera ecuación."""
        self._del_sel()
        row, idx = self._cur
        box = System([None] * max(1, n))
        items = list(fn + "(") + [box] + list(",{" + variables + "})")
        for k, it in enumerate(items):
            row.insert(idx + k, it)
        self._cur = (box.rows[0], 0)
        self._changed()

    def _system_key(self, t) -> bool:
        row, idx = self._cur
        if t == "{":
            before = "".join(x for x in row[max(0, idx - 9):idx] if isinstance(x, str)).lower()
            if any(before.endswith(f) for f in SYSTEM_FUNCS):
                self._insert_box(System())
                return True
            return False
        par = self._parent(row)
        if par is None or not isinstance(par[2], System):
            return False
        prow, pidx, box, si = par
        if t in (",", ";"):
            if si + 1 >= len(box.rows):
                box.rows.append(Row())
            self._cur = (box.rows[si + 1], 0)
            self._changed()
            return True
        if t == "}":
            self._cur = (prow, pidx + 1)
            self._changed()
            return True
        return False

    # ----- edición interna
    def _insert_box(self, box):
        self._del_sel()
        row, idx = self._cur
        row.insert(idx, box)
        self._cur = (box.slots()[0], 0)
        self._changed()

    def _parent(self, row):
        return find_parent(self._root, row)

    def _move_right(self):
        row, idx = self._cur
        if idx < len(row):
            it = row[idx]
            if isinstance(it, Box) and it.slots():
                self._cur = (it.slots()[0], 0)
            else:
                self._cur = (row, idx + 1)
            return
        par = self._parent(row)
        if par is None:
            return
        prow, pidx, box, si = par
        slots = box.slots()
        if si + 1 < len(slots):
            self._cur = (slots[si + 1], 0)
        else:
            self._cur = (prow, pidx + 1)

    def _move_left(self):
        row, idx = self._cur
        if idx > 0:
            it = row[idx - 1]
            if isinstance(it, Box) and it.slots():
                last = it.slots()[-1]
                self._cur = (last, len(last))
            else:
                self._cur = (row, idx - 1)
            return
        par = self._parent(row)
        if par is None:
            return
        prow, pidx, box, si = par
        slots = box.slots()
        if si > 0:
            self._cur = (slots[si - 1], len(slots[si - 1]))
        else:
            self._cur = (prow, pidx)

    def _move_vert(self, d) -> bool:
        """Sube/baja entre numerador y denominador o filas de matriz. False si no hay a dónde."""
        row, idx = self._cur
        target = row
        while True:
            par = self._parent(target)
            if par is None:
                return False
            prow, pidx, box, si = par
            dest = None
            if isinstance(box, Frac):
                if d < 0 and si == 1:
                    dest = box.num
                elif d > 0 and si == 0:
                    dest = box.den
            elif isinstance(box, System):
                if 0 <= si + d < len(box.rows):
                    dest = box.rows[si + d]
            elif isinstance(box, Piecewise):
                r, c = divmod(si, 2)
                if 0 <= r + d < len(box.rows):
                    dest = box.rows[r + d][c]
            elif isinstance(box, Matrix):
                nc = box.ncols
                r, c = divmod(si, nc) if nc else (0, 0)
                r2 = r + d
                if 0 <= r2 < len(box.rows) and c < len(box.rows[r2]):
                    dest = box.rows[r2][c]
            if dest is not None:
                self._cur = (dest, min(idx if target is row else len(dest), len(dest)))
                return True
            target = prow

    def _backspace(self):
        if self.dropGhost():
            return
        if self._pair_backspace():
            return
        row, idx = self._cur
        if idx > 0:
            it = row[idx - 1]
            if isinstance(it, Box):
                if it.is_empty():
                    del row[idx - 1]
                    self._cur = (row, idx - 1)
                else:
                    last = it.slots()[-1]
                    self._cur = (last, len(last))
            else:
                del row[idx - 1]
                self._cur = (row, idx - 1)
            return
        par = self._parent(row)
        if par is None:
            return
        prow, pidx, box, si = par
        if box.is_empty():
            del prow[pidx]
            self._cur = (prow, pidx)
        elif isinstance(box, System) and si > 0 and len(row) == 0:
            del box.rows[si]
            prev = box.rows[si - 1]
            self._cur = (prev, len(prev))
        elif si > 0:
            prev = box.slots()[si - 1]
            self._cur = (prev, len(prev))
        else:
            self._cur = (prow, pidx)

    def _delete(self):
        if self.dropGhost():
            return
        row, idx = self._cur
        if idx < len(row):
            it = row[idx]
            if isinstance(it, Box):
                if it.is_empty():
                    del row[idx]
                else:
                    self._cur = (it.slots()[0], 0)
            else:
                del row[idx]
            return
        par = self._parent(row)
        if par is None:
            return
        prow, pidx, box, si = par
        if box.is_empty():
            del prow[pidx]
            self._cur = (prow, pidx)
        elif si + 1 < len(box.slots()):
            self._cur = (box.slots()[si + 1], 0)

    def _record(self):
        """Guarda el estado anterior para Ctrl+Z (un paso por tecla, como la TI)."""
        import time
        key = repr(self._root)
        if key == self._snap[0]:
            self._snap = (key, self._snap[1], cursor_path(self._root, *self._cur))
            return
        now = time.monotonic()
        if not self._restoring:
            self._undo.append(self._snap)               # como la TI: cada tecla es un paso de Ctrl+Z
            del self._undo[:-400]
            self._redo.clear()
        self._snap_t = now
        self._snap = (key, copy.deepcopy(self._root), cursor_path(self._root, *self._cur))

    def _restore(self, st):
        self._restoring = True
        self._root = copy.deepcopy(st[1])
        solidify(self._root)
        self._cur = cursor_from_path(self._root, st[2])
        self._anchor = None
        self._changed()
        self._restoring = False
        self._snap_t = 0.0

    def undo(self):
        if not self._undo:
            return
        self._redo.append(self._snap)
        self._restore(self._undo.pop())

    def redo(self):
        if not self._redo:
            return
        self._undo.append(self._snap)
        self._restore(self._redo.pop())

    def setCursorPath(self, path):
        self._cur = cursor_from_path(self._root, path)
        self._anchor = None
        self._changed()

    def _tab(self, d):
        """Tab: siguiente cajita (slot) de la caja actual, o salir de ella."""
        row, idx = self._cur
        par = self._parent(row)
        if par is None:
            return
        prow, pidx, box, si = par
        slots = box.slots()
        if 0 <= si + d < len(slots):
            nxt = slots[si + d]
            self._cur = (nxt, len(nxt) if d < 0 else 0)
        else:
            self._cur = (prow, pidx + (1 if d > 0 else 0))
        self._changed()

    STOPS = set("=→,;▸<>≤≥≠|")
    GHOST_OPS = set("+*/^·×÷²")

    # al escribir "(" después de un nombre (bases, zbase…) la pestaña puede poner una plantilla
    parenHook = None            # función(nombre, sola) -> True si ya insertó algo

    def _word_before(self, row, idx):
        j = idx
        while j > 0 and isinstance(row[j - 1], str) and len(row[j - 1]) == 1 and \
                (row[j - 1].isalnum() and row[j - 1] not in "ⅈπℯ°"):
            j -= 1
        if j > 0 and row[j - 1] in ("_", "'", ".") and isinstance(row[j - 1], str):
            return None, j                      # es una unidad o un número
        w = "".join(row[j:idx])
        while w and w[0].isdigit():
            w = w[1:]
            j += 1
        return (w or None), j

    def _paren_hook(self, row, idx) -> bool:
        if self.parenHook is None:
            return False
        if idx < len(row) and not (isinstance(row[idx], str) and row[idx] in ")],"):
            return False
        name, j = self._word_before(row, idx)
        if not name or not name[0].isalpha():
            return False
        alone = row is self._root and j == 0 and idx == len(row)
        return bool(self.parenHook(name, alone))

    def openParen(self):
        """( desde el teclado de la pantalla: igual que escribirlo."""
        self._del_sel()
        row, idx = self._cur
        if self._paren_hook(row, idx):
            return
        self._open_paren(row, idx)

    def _open_paren(self, row, idx):
        """( con algo escrito a la derecha: lo encierra hasta el final de esa expresión, 20*(10/50+30 ->
        20*(10/50+30). Sin nada a la derecha pone el par () con el cursor adentro."""
        end = idx
        d = 0
        while end < len(row):
            it = row[end]
            if isinstance(it, str) and it in "([{":
                d += 1
            elif isinstance(it, str) and it in ")]}":
                if d == 0:
                    break
                d -= 1
            elif d == 0 and isinstance(it, str) and it in self.STOPS:
                break
            end += 1
        row.insert(end, ")")
        row.insert(idx, "(")
        self._cur = (row, idx + 1)
        self._changed()
        self._mark_pair(row, idx, end + 1)

    # el paréntesis que se puso solo (la pareja) se borra junto con el que se escribió si se borra al tiro
    _pair = None

    def _mark_pair(self, row, i_open, i_close):
        self._pair = (repr(self._root), self._cur[1], row, i_open, i_close)

    def _pair_backspace(self) -> bool:
        pr = self._pair
        self._pair = None
        if pr is None:
            return False
        key, cidx, row, io, ic = pr
        crow, idx = self._cur
        if crow is not row or idx != cidx or repr(self._root) != key or self._anchor is not None:
            return False
        if not (0 <= io < len(row) and 0 <= ic < len(row) and row[io] == "(" and row[ic] == ")"):
            return False
        if idx - 1 not in (io, ic):                 # se borra justo el que se escribió
            return False
        del row[ic]
        del row[io]
        self._cur = (row, io if idx - 1 == io else ic - 1)
        return True

    def _arg_tab(self, d) -> bool:
        """Tab dentro de f(a,b,c): salta al comienzo del siguiente dato (Shift+Tab al anterior)."""
        row, idx = self._cur
        depth, k, op = 0, idx - 1, None
        while k >= 0:
            it = row[k]
            if isinstance(it, str) and it in ")]}":
                depth += 1
            elif isinstance(it, str) and it in "([{":
                if depth == 0:
                    op = k
                    break
                depth -= 1
            k -= 1
        if op is None:
            return False
        if d > 0:
            depth = 0
            for j in range(idx, len(row)):
                it = row[j]
                if not isinstance(it, str):
                    continue
                if it in "([{":
                    depth += 1
                elif it in ")]}":
                    if depth == 0:
                        self._cur = (row, j + 1)
                        return True
                    depth -= 1
                elif it == "," and depth == 0:
                    self._cur = (row, j + 1)
                    return True
            return False
        starts, depth = [op + 1], 0
        for j in range(op + 1, idx):
            it = row[j]
            if isinstance(it, str) and it in "([{":
                depth += 1
            elif isinstance(it, str) and it in ")]}":
                depth -= 1
            elif it == "," and depth == 0:
                starts.append(j + 1)
        prev = [x for x in starts if x < idx]
        self._cur = (row, prev[-1] if prev else op)
        return True

    def _wrap_close(self, row, idx, t):
        """) sin su ( : encierra lo escrito desde el comienzo del término (V:=240∠50) -> V:=(240∠50))."""
        op = {")": "(", "]": "[", "}": "{"}[t]
        depth = 0
        for it in row[:idx]:
            if it == op:
                depth += 1
            elif it == t:
                depth -= 1
        if depth > 0:
            return False                            # hay un ( abierto: es su cierre
        k = idx
        d = 0
        while k > 0:
            it = row[k - 1]
            if isinstance(it, str) and it in ")]}":
                d += 1
            elif isinstance(it, str) and it in "([{":
                if d == 0:
                    break
                d -= 1
            elif d == 0 and isinstance(it, str) and it in self.STOPS:
                break
            k -= 1
        if k == idx:
            return False
        row.insert(k, op)
        row.insert(idx + 1, t)
        self._cur = (row, idx + 2)
        self._changed()
        if t == ")":
            self._mark_pair(row, k, idx + 1)
        return True

    def _changed(self):
        self._record()
        if self.onChange is not None:
            self.onChange()


    # ----- teclas por nombre (la app de PC traduce las de Qt; la calculadora, las de sus botones)
    KEYS = ("text", "enter", "escape", "left", "right", "up", "down", "home", "end", "backspace", "delete",
            "tab", "backtab", "frac")

    def key(self, k, text="", ctrl=False, shift=False, alt=False):
        """Aplica una tecla. Devuelve None si la resolvió, o un evento para quien contiene la línea:
        "submit", "submit_approx", "history_up", "history_down", "escape" o "unhandled"."""
        if k not in ("backspace",):
            self._pair = None
        if k == "enter":
            if (alt or shift) and self.addRow(column=shift and not alt):
                return None
            return "submit_approx" if ctrl else "submit"
        if k == "escape":
            if self.dropGhost():
                self._changed()
                return None
            if self._anchor is not None:
                self._anchor = None
                self._changed()
                return None
            return "escape"
        if k in ("tab", "backtab"):
            d = -1 if k == "backtab" else 1
            self.solidGhost()
            if self._arg_tab(d):
                self._anchor = None
                self._changed()
                return None
            row, idx = self._cur
            if self._parent(row) is not None or k == "backtab":
                self._tab(d)
                return None
            return "unhandled"
        if k == "frac":
            self.insertFraction()
            return None
        if ctrl and k == "text" and text:
            c = text.lower()
            if c == "y" or (c == "z" and shift):
                (self.redoHook or self.redo)()
                return None
            if c == "z":
                (self.undoHook or self.undo)()
                return None
            if c == "a":
                self.selectAll()
                return None
            if c in ("c", "x"):
                self.setClipboard(self.selectedText() or self.text())
                if c == "x":
                    if not self._del_sel():
                        self._root.clear()
                        self._cur = (self._root, 0)
                    self._changed()
                return None
            if c == "v":
                self.pasteText(self.getClipboard())
                return None
            if c == "/":
                self.insertFraction()
                return None
            return "unhandled"
        if k in ("left", "right", "home", "end"):
            self.solidGhost()
            if shift:
                if self._anchor is None:
                    self._anchor = self._cur
            else:
                self._anchor = None
        elif k in ("up", "down"):
            if self.dropGhost():
                self._changed()                    # ↑ para buscar en el historial: se va el Ans gris
            self._anchor = None
        elif k in ("backspace", "delete") and self.selection():
            self._del_sel()
            self._changed()
            return None
        if k == "right":
            self._move_right()
        elif k == "left":
            self._move_left()
        elif k == "up":
            if not self._move_vert(-1):
                return "history_up"
        elif k == "down":
            if not self._move_vert(1):
                return "history_down"
        elif k == "home":
            self._cur = (self._root, 0)
        elif k == "end":
            self._cur = (self._root, len(self._root))
        elif k == "backspace":
            self._backspace()
        elif k == "delete":
            self._delete()
        elif k == "text":
            t = text
            if not t or not t.isprintable():
                return "unhandled"
            self.typeText(t)
            return None
        else:
            return "unhandled"
        self._changed()
        return None

    def typeText(self, t):
        """Lo que hace la TI al escribir t (una letra, un operador o un trozo de texto)."""
        if len(t) == 1 and t in self.GHOST_OPS and self.hasGhost():
            grow, gi = self._ghost_loc()
            solidify(self._root)                # Ans gris + operador = Ans·… (como la TI)
            self._cur = (grow, gi + 3)
        self._del_sel()
        if self._ans_first(t):
            self._put_ans()
        if t == "^":
            self.insertBox("sup")
            return
        if self._system_key(t):
            return
        row, idx = self._cur
        if len(t) == 1 and t in ")]}" and idx < len(row) and row[idx] == t:
            self._cur = (row, idx + 1)            # como la TI: ")" pasa por encima del que ya estaba
            self._changed()
            return
        if len(t) == 1 and t in ")]}" and self._wrap_close(row, idx, t):
            return
        if t == "(" and self._paren_hook(row, idx):
            return
        if t == "(":
            self._open_paren(row, idx)
            return
        if len(t) == 1 and t in "([{":
            row.insert(idx, t)
            row.insert(idx + 1, {"(": ")", "[": "]", "{": "}"}[t])
            self._cur = (row, idx + 1)            # se abre el par con el cursor adentro
            self._changed()
            self._mark_pair(row, idx, idx + 1)
            return
        for n, ch in enumerate(t):
            row.insert(idx + n, ch)
        self._cur = (row, idx + len(t))
        row, idx = self._cur
        if idx >= 2 and row[idx - 2] == "@" and isinstance(row[idx - 1], str) and row[idx - 1] in self.AT:
            row[idx - 2:idx] = [self.AT[row[idx - 1]]]     # como la TI: @i -> ⅈ, @< -> ∠, @> -> ▸, @e -> ℯ
            self._cur = (row, idx - 1)
        self._changed()

    AT = {"i": "ⅈ", "<": "∠", ">": "▸", "e": "ℯ", "E": "ᴇ", "d": "°", "t": "ᵀ", "r": "ʳ", "g": "ᵍ"}

    def pasteText(self, t):
        """Pegar texto: como si se escribiera (solve({…} queda apilado)."""
        self._del_sel()
        t = (t or "").replace("\r", "").replace("\n", "")
        for ch in t:
            if not self._system_key(ch):
                row, idx = self._cur
                row.insert(idx, ch)
                self._cur = (row, idx + 1)
        if t:
            self._changed()

    def commitText(self, t):
        """Texto ya compuesto por el sistema (teclas muertas: ^ en teclados en español)."""
        if t == "^":
            self.insertBox("sup")
        elif t:
            self.insertText(t.replace("|", ""))

