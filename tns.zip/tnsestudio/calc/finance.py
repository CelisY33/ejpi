"""
finance.py - Finanzas como la TI-Nspire (menú 8): valor del dinero en el tiempo (TVM), amortización,
flujos de efectivo (VPN, TIR, TIRM), tasas nominal/efectiva y días entre fechas.

Convención de signos de la TI: lo que sale es negativo y lo que entra es positivo
(PV=100000, FV=0 -> Pmt negativo). PmtAt: 0 = al final del periodo (END), 1 = al inicio (BEGIN).
"""
from __future__ import annotations

import math
from datetime import date


class FinError(ValueError):
    pass


def _rate(I, PpY, CpY):
    """Tasa por periodo de pago (I en % anual)."""
    return (1 + I / (100.0 * CpY)) ** (CpY / PpY) - 1


def tvm_eq(N, I, PV, Pmt, FV, PpY=1, CpY=None, PmtAt=0):
    CpY = PpY if CpY is None else CpY
    i = _rate(I, PpY, CpY)
    if abs(i) < 1e-14:
        return PV + Pmt * N + FV
    v = (1 + i) ** (-N)
    return PV + (1 + i * PmtAt) * Pmt * (1 - v) / i + FV * v


def tvm_fv(N, I, PV, Pmt, PpY=1, CpY=None, PmtAt=0):
    CpY = PpY if CpY is None else CpY
    i = _rate(I, PpY, CpY)
    if abs(i) < 1e-14:
        return -(PV + Pmt * N)
    g = (1 + i) ** N
    return -(PV * g + (1 + i * PmtAt) * Pmt * (g - 1) / i)


def tvm_pv(N, I, Pmt, FV, PpY=1, CpY=None, PmtAt=0):
    CpY = PpY if CpY is None else CpY
    i = _rate(I, PpY, CpY)
    if abs(i) < 1e-14:
        return -(Pmt * N + FV)
    v = (1 + i) ** (-N)
    return -((1 + i * PmtAt) * Pmt * (1 - v) / i + FV * v)


def tvm_pmt(N, I, PV, FV, PpY=1, CpY=None, PmtAt=0):
    CpY = PpY if CpY is None else CpY
    i = _rate(I, PpY, CpY)
    if N == 0:
        raise FinError("N no puede ser 0")
    if abs(i) < 1e-14:
        return -(PV + FV) / N
    v = (1 + i) ** (-N)
    return -(PV + FV * v) * i / ((1 + i * PmtAt) * (1 - v))


def tvm_n(I, PV, Pmt, FV, PpY=1, CpY=None, PmtAt=0):
    CpY = PpY if CpY is None else CpY
    i = _rate(I, PpY, CpY)
    if abs(i) < 1e-14:
        if Pmt == 0:
            raise FinError("Sin interés y sin pagos no hay solución para N")
        return -(PV + FV) / Pmt
    a = (1 + i * PmtAt) * Pmt / i
    num, den = a - FV, a + PV
    if num / den <= 0 if den != 0 else True:
        raise FinError("No hay solución para N con esos valores")
    return math.log(num / den) / math.log(1 + i)


def tvm_i(N, PV, Pmt, FV, PpY=1, CpY=None, PmtAt=0):
    """Tasa anual en % (búsqueda numérica)."""
    def f(I):
        return tvm_eq(N, I, PV, Pmt, FV, PpY, CpY, PmtAt)
    # busca un cambio de signo y luego bisección
    grid = [-99.0] + [x / 10.0 for x in range(-900, 10001, 5)]
    prev_x, prev_f = None, None
    for x in grid:
        try:
            fx = f(x)
        except (OverflowError, ZeroDivisionError, ValueError):
            continue
        if prev_f is not None and (fx == 0 or (fx > 0) != (prev_f > 0)):
            a, b, fa = prev_x, x, prev_f
            for _ in range(200):
                m = (a + b) / 2
                fm = f(m)
                if (fm > 0) == (fa > 0):
                    a, fa = m, fm
                else:
                    b = m
            return (a + b) / 2
        prev_x, prev_f = x, fx
    raise FinError("No encontré la tasa de interés (revisa los signos de PV, Pmt y FV)")


def amort(NPmt, N, I, PV, Pmt=None, FV=0.0, PpY=1, CpY=None, PmtAt=0, rnd=2):
    """Filas (periodo, interés, capital, saldo) como amortTbl de la TI."""
    CpY = PpY if CpY is None else CpY
    if Pmt is None:
        Pmt = round(tvm_pmt(N, I, PV, FV, PpY, CpY, PmtAt), rnd)
    i = _rate(I, PpY, CpY)
    bal = PV
    rows = [(0, 0.0, 0.0, round(bal, rnd))]
    for k in range(1, int(NPmt) + 1):
        if PmtAt and k == 1:
            intr = 0.0
        else:
            intr = round(-bal * i, rnd) if PmtAt == 0 else round(-(bal) * i, rnd)
        prn = round(Pmt - intr, rnd)
        bal = round(bal + prn, rnd)
        rows.append((k, intr, prn, bal))
    return rows


def npv(rate, cf0, cfs, freq=None):
    r = rate / 100.0
    flows = _expand(cfs, freq)
    return cf0 + sum(c / (1 + r) ** (k + 1) for k, c in enumerate(flows))


def irr(cf0, cfs, freq=None):
    flows = _expand(cfs, freq)

    def f(r):
        return cf0 + sum(c / (1 + r / 100.0) ** (k + 1) for k, c in enumerate(flows))
    xs = [x / 2.0 for x in range(-198, 2001)]
    prev = None
    for x in xs:
        try:
            fx = f(x)
        except (OverflowError, ZeroDivisionError):
            continue
        if prev is not None and (fx == 0 or (fx > 0) != (prev[1] > 0)):
            a, b, fa = prev[0], x, prev[1]
            for _ in range(200):
                m = (a + b) / 2
                fm = f(m)
                if (fm > 0) == (fa > 0):
                    a, fa = m, fm
                else:
                    b = m
            return (a + b) / 2
        prev = (x, fx)
    raise FinError("No encontré la TIR (los flujos deben cambiar de signo)")


def mirr(finance_rate, reinvest_rate, cf0, cfs, freq=None):
    flows = [cf0] + _expand(cfs, freq)
    n = len(flows) - 1
    fr, rr = finance_rate / 100.0, reinvest_rate / 100.0
    pv_neg = sum(c / (1 + fr) ** k for k, c in enumerate(flows) if c < 0)
    fv_pos = sum(c * (1 + rr) ** (n - k) for k, c in enumerate(flows) if c > 0)
    if pv_neg == 0 or fv_pos == 0 or n == 0:
        raise FinError("La TIRM necesita flujos positivos y negativos")
    return ((fv_pos / -pv_neg) ** (1.0 / n) - 1) * 100


def nom(eff_rate, cpy):
    return cpy * ((1 + eff_rate / 100.0) ** (1.0 / cpy) - 1) * 100


def eff(nom_rate, cpy):
    return ((1 + nom_rate / (100.0 * cpy)) ** cpy - 1) * 100


def _expand(cfs, freq):
    cfs = list(cfs)
    if freq is None:
        return cfs
    out = []
    for c, f in zip(cfs, list(freq)):
        out += [c] * int(f)
    return out


def _date(v):
    """Formato de la TI: MM.DDAA (12.3126) o DDMM.AA (3112.26)."""
    s = ("%.4f" % v) if v < 100 else ("%.2f" % v)
    if v < 100:                       # MM.DDAA
        mm, rest = s.split(".")
        return int(mm), int(rest[:2]), int(rest[2:4])
    ddmm, yy = s.split(".")
    ddmm = ddmm.zfill(4)
    return int(ddmm[2:]), int(ddmm[:2]), int(yy)


def dbd(d1, d2):
    def mk(v):
        m, d, y = _date(v)
        y += 1900 if y >= 50 else 2000
        return date(y, m, d)
    try:
        return (mk(d2) - mk(d1)).days
    except ValueError:
        raise FinError("Fecha inválida (usa MM.DDAA, por ejemplo 12.3126, o DDMM.AA, por ejemplo 3112.26)")
