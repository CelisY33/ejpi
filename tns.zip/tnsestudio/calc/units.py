"""
units.py - Unidades con guion bajo, al estilo TI (_km, _V, _Ω, _hr…).

Cada unidad es un número por un producto de unidades base del SI (símbolos de SymPy
_m, _kg, _s, _A, _K, _mol, _cd). Así 5_km/(2_hr) queda como 0.694444·_m/_s y se puede
convertir a cualquier otra unidad con ▸.

Los nombres siguen a la TI: _gm es gramo, _g es la gravedad, _h es la constante de Planck
y _hr es hora.
"""
from __future__ import annotations

import sympy as sp

BASE_NAMES = ("m", "kg", "s", "A", "K", "mol", "cd")
BASE = {n: sp.Symbol("_" + n, positive=True) for n in BASE_NAMES}
BASE_SYMS = tuple(BASE.values())
m, kg, s, A, K, mol, cd = (BASE[n] for n in BASE_NAMES)

R = sp.Rational
PI = sp.pi

# unidades derivadas (sin prefijo)
N_ = kg * m / s**2
J_ = N_ * m
W_ = J_ / s
C_ = A * s
V_ = W_ / A
OHM = V_ / A

UNITS: dict[str, sp.Expr] = {
    # longitud
    "m": m, "in": R(254, 10000) * m, "ft": R(3048, 10000) * m, "yd": R(9144, 10000) * m,
    "mi": R(1609344, 1000) * m, "Å": R(1, 10**10) * m, "nmi": 1852 * m,
    # masa (TI: _gm = gramo)
    "kg": kg, "gm": kg / 1000, "lb": R(45359237, 10**8) * kg, "oz": R(45359237, 16 * 10**8) * kg,
    # tiempo
    "s": s, "min": 60 * s, "hr": 3600 * s, "day": 86400 * s, "week": 604800 * s,
    "yr": R(31557600) * s,
    # corriente, temperatura, cantidad, intensidad
    "A": A, "K": K, "mol": mol, "cd": cd,
    # derivadas
    "N": N_, "J": J_, "W": W_, "C": C_, "V": V_, "Ω": OHM, "S": 1 / OHM,
    "F": C_ / V_, "H": V_ * s / A, "Wb": V_ * s, "T": V_ * s / m**2, "Hz": 1 / s,
    "Pa": N_ / m**2, "bar": 100000 * N_ / m**2, "atm": 101325 * N_ / m**2,
    "psi": R(689475729, 100000) * N_ / m**2, "mmHg": R(101325, 760) * N_ / m**2,
    "VA": W_, "var": W_, "Wh": 3600 * J_, "eV": R(1602176634, 10**28) * J_,
    "cal": R(4184, 1000) * J_, "Btu": R(105505585262, 10**8) * J_, "hp": R(745699872, 10**6) * W_,
    "l": m**3 / 1000, "L": m**3 / 1000, "gal": R(3785411784, 10**12) * m**3,
    "ha": 10000 * m**2, "acre": R(40468564224, 10**7) * m**2,
    "rpm": 2 * PI / (60 * s), "lbf": R(444822161526, 10**11) * N_, "kgf": R(980665, 100000) * N_,
    # constantes (como en la TI)
    "c": 299792458 * m / s,
    "g": R(980665, 100000) * m / s**2,
    "h": R(662607015, 10**42) * J_ * s,
    "q": R(1602176634, 10**28) * C_,
    "k": R(1380649, 10**29) * J_ / K,
    "Na": sp.Integer(602214076) * 10**15 / mol,
    "R": R(8314462618, 10**9) * J_ / (mol * K),
    "ε0": R(88541878128, 10**22) * C_ / (V_ * m),
    "μ0": R(125663706212, 10**17) * V_ * s / (A * m),
    "me": R(91093837015, 10**41) * kg,
    "mp": R(167262192369, 10**38) * kg,
}
# más unidades de la TI (las del Asistente de conversión)
_LB = R(45359237, 10**8) * kg
_IN = R(254, 10000) * m
_GAL = R(3785411784, 10**12) * m**3
_GALUK = R(454609, 10**8) * m**3
_KGF = R(980665, 100000) * N_
UNITS.update({
    "Ang": R(1, 10**10) * m, "au": 149597870700 * m, "fath": R(18288, 10000) * m, "ltyr": 9460730472580800 * m,
    "mil": R(254, 10**7) * m, "Nmi": 1852 * m, "pc": sp.Float("3.0856775814913673e16", 17) * m,
    "rod": R(50292, 10000) * m, "µ": R(1, 10**6) * m, "μ": R(1, 10**6) * m,
    "galUS": _GAL, "galUK": _GALUK, "qt": _GAL / 4, "pt": _GAL / 8, "cup": _GAL / 16, "floz": _GAL / 128,
    "flozUK": _GALUK / 160, "tbsp": _GAL / 256, "tsp": _GAL / 768,
    "knot": R(1852, 3600) * m / s, "mph": R(1609344, 1000 * 3600) * m / s,
    "amu": R(166053906660, 10**38) * kg, "slug": R(145939029, 10**7) * kg,
    "ton": 2000 * _LB, "tonUK": 2240 * _LB, "mton": 1000 * kg,
    "mg": kg / 10**6, "µg": kg / 10**9, "μg": kg / 10**9,
    "dyne": R(1, 10**5) * N_, "kgf": _KGF, "tonf": 2000 * R(444822161526, 10**11) * N_,
    "erg": R(1, 10**7) * J_, "ftlb": R(3048, 10000) * R(444822161526, 10**11) * J_, "latm": R(101325, 1000) * J_,
    "Btu": R(105505585262, 10**8) * J_, "BTU": R(105505585262, 10**8) * J_,
    "PS": R(73549875, 10**5) * W_,
    "inH2O": R(24908891, 10**5) * N_ / m**2, "inHg": R(3386389, 1000) * N_ / m**2,
    "mmH2O": R(980665, 10**5) * N_ / m**2, "Torr": R(101325, 760) * N_ / m**2,
    # temperaturas (▸ y tmpCnv convierten el valor absoluto, como la TI)
    "°C": K, "°F": R(5, 9) * K, "°R": R(5, 9) * K, "ºC": K, "ºF": R(5, 9) * K,
})
# escala y cero de cada unidad de temperatura: K = (valor + cero)·escala
TEMPS = {"K": (sp.Integer(1), sp.Integer(0)), "°C": (sp.Integer(1), R(27315, 100)),
         "°F": (R(5, 9), R(45967, 100)), "°R": (R(5, 9), sp.Integer(0)),
         "ºC": (sp.Integer(1), R(27315, 100)), "ºF": (R(5, 9), R(45967, 100))}


def temp_convert(value, src, tgt):
    """100 (°C) -> 212 (°F): conversión absoluta."""
    a, za = TEMPS[src]
    b, zb = TEMPS[tgt]
    return (value + za) * a / b - zb


# Asistente de conversión (mismas categorías y unidades que la TI): (texto, lo que se inserta)
WIZARD = [
    ("Longitud", [("Å (angstrom)", "_Ang"), ("au (unidad astronómica)", "_au"), ("cm (centímetro)", "_cm"),
                  ("dm (decímetro)", "_dm"), ("fath (braza)", "_fath"), ("fm (fermi)", "_fm"), ("ft (pie)", "_ft"),
                  ("in (pulgada)", "_in"), ("km (kilómetro)", "_km"), ("ltyr (año luz)", "_ltyr"),
                  ("m (metro)", "_m"), ("µm (micrón)", "_µm"), ("mi (milla)", "_mi"), ("mil (1/1000 pulgada)", "_mil"),
                  ("mm (milímetro)", "_mm"), ("nm (nanómetro)", "_nm"), ("Nmi (milla náutica)", "_Nmi"),
                  ("pc (parsec)", "_pc"), ("rod (rod)", "_rod"), ("yd (yarda)", "_yd")]),
    ("Área", [("acre (acre)", "_acre"), ("cm²", "_cm^2"), ("dm²", "_dm^2"), ("ft²", "_ft^2"), ("ha (hectárea)", "_ha"),
              ("in²", "_in^2"), ("km²", "_km^2"), ("m²", "_m^2"), ("mi²", "_mi^2"), ("mm²", "_mm^2"), ("yd²", "_yd^2")]),
    ("Volumen", [("cm³", "_cm^3"), ("cup (taza)", "_cup"), ("dm³", "_dm^3"), ("ft³", "_ft^3"),
                 ("floz (onza líquida estadounidense)", "_floz"), ("flozUK (onza líquida británica)", "_flozUK"),
                 ("galUS (galón estadounidense)", "_galUS"), ("galUK (galón británico)", "_galUK"), ("in³", "_in^3"),
                 ("l (litro)", "_l"), ("m³", "_m^3"), ("ml (mililitro)", "_ml"), ("pt (pinta)", "_pt"),
                 ("qt (cuarto)", "_qt"), ("tbsp (cucharada)", "_tbsp"), ("tsp (cucharadita)", "_tsp"), ("yd³", "_yd^3")]),
    ("Tiempo", [("day (día)", "_day"), ("hr (hora)", "_hr"), ("min (minuto)", "_min"), ("ms (milisegundo)", "_ms"),
                ("µs (microsegundo)", "_µs"), ("ns (nanosegundo)", "_ns"), ("s (segundo)", "_s"),
                ("week (semana)", "_week"), ("yr (año)", "_yr")]),
    ("Velocidad", [("ft/min", "_ft/_min"), ("ft/s", "_ft/_s"), ("knot (nudo)", "_knot"), ("km/h", "_km/_hr"),
                   ("km/min", "_km/_min"), ("m/min", "_m/_min"), ("m/s", "_m/_s"), ("mi/h", "_mi/_hr"),
                   ("mi/min", "_mi/_min"), ("mi/s", "_mi/_s")]),
    ("Temperatura", [("°C (Celsius)", "_°C"), ("°F (Fahrenheit)", "_°F"), ("K (kelvin)", "_K"), ("°R (Rankine)", "_°R")]),
    ("Masa", [("amu (unidad de masa atómica)", "_amu"), ("gm (gramo)", "_gm"), ("kg (kilogramo)", "_kg"),
              ("lb (libra)", "_lb"), ("mg (miligramo)", "_mg"), ("mton (tonelada métrica)", "_mton"),
              ("oz (onza)", "_oz"), ("slug (slug)", "_slug"), ("ton (tonelada)", "_ton"),
              ("tonUK (tonelada británica)", "_tonUK")]),
    ("Fuerza", [("dyne (dina)", "_dyne"), ("kgf (kilogramo fuerza)", "_kgf"), ("lbf (libra fuerza)", "_lbf"),
                ("N (newton)", "_N"), ("tonf (tonelada fuerza)", "_tonf")]),
    ("Energía", [("BTU (unidad térmica británica)", "_Btu"), ("cal (caloría)", "_cal"), ("erg (ergio)", "_erg"),
                 ("eV (electrovoltio)", "_eV"), ("ftlb (pie-libra)", "_ftlb"), ("J (julio)", "_J"),
                 ("kcal (kilocaloría)", "_kcal"), ("kJ (kilojulio)", "_kJ"), ("kgf*m", "_kgf*_m"),
                 ("kWh (kilovatio-hora)", "_kWh"), ("latm (litro-atmósfera)", "_latm")]),
    ("Potencia", [("hp (caballo de fuerza)", "_hp"), ("kW (kilovatio)", "_kW"), ("PS (caballo de fuerza métrico)", "_PS"),
                  ("W (vatio)", "_W")]),
    ("Presión", [("atm (atmósfera)", "_atm"), ("bar (bar)", "_bar"), ("inH₂O (pulgadas de agua)", "_inH2O"),
                 ("inHg (pulgadas de mercurio)", "_inHg"), ("kPa (kilopascal)", "_kPa"), ("kgf/cm²", "_kgf/_cm^2"),
                 ("lbf/in²", "_lbf/_in^2"), ("mbar (milibar)", "_mbar"), ("mmH₂O (milímetros de agua)", "_mmH2O"),
                 ("mmHg (milímetros de mercurio)", "_mmHg"), ("N/m²", "_N/_m^2"), ("Pa (pascal)", "_Pa")]),
]

# Eléctricas (no están en el asistente de la TI, pero sí en su catálogo)
CATALOG_EXTRA = [
    ("Eléctricas", [("V (voltio)", "_V"), ("kV (kilovoltio)", "_kV"), ("mV (milivoltio)", "_mV"), ("A (amperio)", "_A"),
                    ("mA (miliamperio)", "_mA"), ("kA (kiloamperio)", "_kA"), ("Ω (ohmio)", "_Ω"), ("kΩ (kiloohmio)", "_kΩ"),
                    ("MΩ (megaohmio)", "_MΩ"), ("W (vatio)", "_W"), ("kW (kilovatio)", "_kW"), ("MW (megavatio)", "_MW"),
                    ("VA (voltamperio)", "_VA"), ("kVA", "_kVA"), ("MVA", "_MVA"), ("var (voltamperio reactivo)", "_var"),
                    ("kvar", "_kvar"), ("Wh (vatio-hora)", "_Wh"), ("kWh", "_kWh"), ("MWh", "_MWh"),
                    ("F (faradio)", "_F"), ("µF", "_µF"), ("nF", "_nF"), ("pF", "_pF"), ("H (henrio)", "_H"),
                    ("mH", "_mH"), ("µH", "_µH"), ("S (siemens)", "_S"), ("C (culombio)", "_C"), ("Hz (hercio)", "_Hz"),
                    ("kHz", "_kHz"), ("T (tesla)", "_T"), ("Wb (weber)", "_Wb"), ("rpm", "_rpm")]),
]
CONSTANTS = [("c (velocidad de la luz)", "_c"), ("g (aceleración de gravedad)", "_g"), ("h (constante de Planck)", "_h"),
             ("q (carga del electrón)", "_q"), ("k (constante de Boltzmann)", "_k"), ("Na (número de Avogadro)", "_Na"),
             ("R (constante de los gases)", "_R"), ("ε0 (permitividad del vacío)", "_ε0"),
             ("μ0 (permeabilidad del vacío)", "_μ0"), ("me (masa del electrón)", "_me"), ("mp (masa del protón)", "_mp")]

UNITS["eps0"] = UNITS["ε0"]
UNITS["mu0"] = UNITS["μ0"]
UNITS["µ0"] = UNITS["μ0"]
UNITS["ohm"] = OHM

PREFIXES = {"Y": 24, "Z": 21, "E": 18, "P": 15, "T": 12, "G": 9, "M": 6, "k": 3, "h": 2, "da": 1,
            "d": -1, "c": -2, "m": -3, "µ": -6, "μ": -6, "u": -6, "n": -9, "p": -12, "f": -15}
PREFIXABLE = {"m", "s", "A", "K", "mol", "N", "J", "W", "C", "V", "Ω", "ohm", "S", "F", "H", "Wb",
              "T", "Hz", "Pa", "VA", "var", "Wh", "eV", "l", "L", "cal", "gm", "bar"}

CONSTANT_NAMES = {"c", "g", "h", "q", "k", "Na", "R", "ε0", "μ0", "eps0", "mu0", "µ0", "me", "mp"}


class UnitError(ValueError):
    pass


def _ci(name, pool):
    """Coincidencias sin importar mayúsculas (si hay una sola unidad distinta)."""
    c = [k for k in pool if k.lower() == name.lower()]
    vals = {sp.srepr(UNITS[k]) for k in c}
    return c[0] if c and len(vals) == 1 else None


def lookup(name: str) -> sp.Expr:
    """'km' -> 1000*_m.  Sin el guion bajo.

    Primero tal cual; si no existe, sin importar mayúsculas (_v = _V, _kw = _kW, _ma = _mA):
    el prefijo se toma como se escribió (m = mili, M = mega) y la unidad en cualquier caso.
    Con apóstrofo el prefijo es explícito: _k'W, _M'A, _m'v, _µ'F, _p'F.
    """
    if "'" in name:
        pre, base = name.split("'", 1)
        if pre not in PREFIXES:
            raise UnitError("«%s'» no es un prefijo (p' n' µ' m' c' d' da' h' k' M' G' T')" % pre)
        b = base if base in UNITS else _ci(base, [k for k in UNITS if k not in CONSTANT_NAMES])
        if b is None or b in CONSTANT_NAMES:
            raise UnitError("No conozco la unidad _%s" % base)
        return sp.Integer(10) ** PREFIXES[pre] * UNITS[b]
    if name in UNITS:
        return UNITS[name]
    for p in sorted(PREFIXES, key=len, reverse=True):
        if name.startswith(p) and name[len(p):] in PREFIXABLE:
            base = name[len(p):]
            if base == "gm":                     # _kgm no existe; _mgm, _µgm sí
                return sp.Integer(10) ** PREFIXES[p] * UNITS["gm"]
            return sp.Integer(10) ** PREFIXES[p] * UNITS[base]
    k = _ci(name, [u for u in UNITS if u not in CONSTANT_NAMES])
    if k is not None:
        return UNITS[k]
    for p in sorted(PREFIXES, key=len, reverse=True):
        if name.startswith(p) and len(name) > len(p):
            b = _ci(name[len(p):], PREFIXABLE)
            if b is not None:
                return sp.Integer(10) ** PREFIXES[p] * UNITS[b]
    cands = [k for k in list(UNITS) + [p + b for p in PREFIXES for b in PREFIXABLE] if k.lower() == name.lower()]
    if cands:                          # el que más letras tiene igual (mv -> mV, no MV)
        best = max(cands, key=lambda k: sum(a == b for a, b in zip(k, name)))
        raise UnitError("No conozco la unidad _%s (¿quisiste decir _%s?)" % (name, best))
    raise UnitError("No conozco la unidad _%s" % name)


def is_unit_name(name: str) -> bool:
    try:
        lookup(name)
        return True
    except UnitError:
        return False


def has_units(e) -> bool:
    try:
        return bool(getattr(e, "free_symbols", set()) & set(BASE_SYMS))
    except Exception:  # noqa: BLE001
        return False


def dims(e) -> tuple:
    """Vector de exponentes de las unidades base de un término (producto)."""
    pw = sp.Mul.make_args(e)
    out = [0] * len(BASE_SYMS)
    for f in pw:
        b, ex = f.as_base_exp()
        if b in BASE_SYMS:
            out[BASE_SYMS.index(b)] += ex
    return tuple(out)


def unit_part(e) -> sp.Expr:
    d = dims(e)
    return sp.Mul(*[b ** x for b, x in zip(BASE_SYMS, d) if x != 0])


def split(e):
    """e = número · unidad.  Devuelve (número, unidad) o (e, 1) si no hay unidades."""
    if not has_units(e):
        return e, sp.Integer(1)
    e2 = sp.expand(e) if isinstance(e, sp.Add) else e
    terms = sp.Add.make_args(e2)
    d0 = dims(terms[0])
    for t in terms[1:]:
        if dims(t) != d0:
            raise UnitError("Unidades incoherentes (%s y %s)"
                            % (describe(d0), describe(dims(t))))
    u = sp.Mul(*[b ** x for b, x in zip(BASE_SYMS, d0) if x != 0])
    num = sp.expand(e2 / u) if u != 1 else e2
    if has_units(num):
        num = sp.simplify(num)
    return num, u


def check(e):
    """Revisa que no se sumen/comparen unidades distintas en ningún lugar de la expresión."""
    if not has_units(e):
        return
    for sub in sp.preorder_traversal(e):
        if isinstance(sub, sp.Add) and has_units(sub):
            terms = sp.Add.make_args(sp.expand(sub))
            ds = {dims(t) for t in terms}
            if len(ds) > 1:
                ds = sorted(ds, key=str)
                raise UnitError("Unidades incoherentes (%s y %s)"
                                % (describe(ds[0]), describe(ds[1])))


# --------- cómo mostrar una unidad ---------
# unidades derivadas preferidas (con prefijo automático cuando tiene sentido)
_PREFERRED = [
    ("V", True), ("A", True), ("Ω", True), ("W", True), ("J", True), ("N", True), ("Pa", True),
    ("Hz", True), ("F", True), ("H", True), ("S", True), ("C", True), ("T", True), ("Wb", True),
    ("m", True), ("kg", False), ("s", True), ("K", False), ("mol", False),
]
_PREF_DIMS = {}
for _n, _p in _PREFERRED:
    _PREF_DIMS.setdefault(dims(UNITS[_n]), (_n, _p))

_PREFIX_STEPS = [(12, "T"), (9, "G"), (6, "M"), (3, "k"), (0, ""), (-3, "m"), (-6, "µ"), (-9, "n"), (-12, "p")]
# prefijos automáticos permitidos por unidad (None = todos)
_ALLOWED = {"m": {3, 0, -3, -6, -9}, "s": {0, -3, -6, -9}}


def describe(d) -> str:
    if tuple(d) in _PREF_DIMS:
        return "_" + _PREF_DIMS[tuple(d)][0]
    parts = []
    for b, x in zip(BASE_SYMS, d):
        if x == 1:
            parts.append(b.name)
        elif x != 0:
            parts.append("%s^%s" % (b.name, x))
    return "·".join(parts) or "sin unidad"


def best_unit(u, magnitude=None, prefer=None):
    """Elige cómo mostrar la unidad u (producto de bases).

    Devuelve (factor, tokens) con número_mostrado = número / factor y tokens una lista
    [(nombre, exponente)], por ejemplo [("kV", 1)] o [("m", 1), ("s", -1)].
    """
    d = dims(u)
    if d in _PREF_DIMS or (prefer and prefer in UNITS and dims(UNITS[prefer]) == d):
        name, pref = (prefer, True) if (prefer and prefer in UNITS and dims(UNITS[prefer]) == d) else _PREF_DIMS[d]
        if pref and magnitude is not None and magnitude != 0:
            import math
            e3 = int(math.floor(math.log10(abs(magnitude)) / 3) * 3)
            steps = [(ex, p) for ex, p in _PREFIX_STEPS if name not in _ALLOWED or ex in _ALLOWED[name]]
            if e3 > steps[0][0] or e3 < steps[-1][0]:
                return sp.Integer(1), [(name, 1)]       # fuera de rango: sin prefijo
            for ex, p in steps:
                if e3 >= ex:
                    if ex == 0 or p == "":
                        return sp.Integer(1), [(name, 1)]
                    return sp.Integer(10) ** ex, [(p + name, 1)]
            return sp.Integer(1), [(name, 1)]
        return sp.Integer(1), [(name, 1)]
    toks = [(b.name[1:], x) for b, x in zip(BASE_SYMS, d) if x != 0]
    return sp.Integer(1), toks
