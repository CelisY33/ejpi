"""
giac.py - Puente con Giac (el CAS de la HP Prime y de GeoGebra) para lo que SymPy hace lento o mal:
solve / cSolve / zeros / cZeros e integrales que SymPy no encuentra.

Giac corre como un proceso aparte (giac.exe, versión de texto de Xcas) que queda abierto. Cada pregunta va
envuelta en marcas ("@@B"+string(...)+"@@E") para reconocer la respuesta. Si algo tarda más que el tope,
se mata el proceso (así "cancelar" funciona de verdad) y se vuelve a abrir en la próxima pregunta.

Dónde se busca giac.exe: variable TNS_GIAC, carpeta "giac" junto al .exe, junto al código o en assets.
Si no está, el motor sigue con SymPy como antes.
"""
from __future__ import annotations

import os
import queue
import re
import subprocess
import sys
import threading
import time

import sympy as sp

TIMEOUT = 8.0


class GiacError(Exception):
    pass


class GiacTimeout(GiacError):
    pass


class GiacCancelled(GiacTimeout):
    pass


def _candidates():
    env = os.environ.get("TNS_GIAC")
    if env:
        yield env
    exe = "giac.exe" if sys.platform.startswith("win") else "giac"
    bases = [os.path.dirname(sys.executable)]
    if getattr(sys, "_MEIPASS", None):
        bases.append(sys._MEIPASS)
    here = os.path.dirname(os.path.abspath(__file__))
    bases += [os.path.dirname(os.path.dirname(here)), os.path.dirname(here)]
    for b in bases:
        for sub in ("giac", os.path.join("assets", "giac")):
            yield os.path.join(b, sub, exe)


ZIP_NAME = "giac_win64.zip"


def _from_zip():
    """En Windows Giac viaja comprimido dentro del programa (assets/giac_win64.zip): la primera vez se
    descomprime en %LOCALAPPDATA%\\TNS Estudio\\giac y queda ahí para las siguientes."""
    if not sys.platform.startswith("win"):
        return None
    here = os.path.dirname(os.path.abspath(__file__))
    bases = [getattr(sys, "_MEIPASS", ""), os.path.dirname(sys.executable),
             os.path.dirname(os.path.dirname(here))]
    zp = None
    for b in bases:
        for sub in ("assets", ""):
            p = os.path.join(b, sub, ZIP_NAME)
            if b and os.path.isfile(p):
                zp = p
                break
        if zp:
            break
    if not zp:
        return None
    import zipfile
    root = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TNS Estudio", "giac",
                        "v%d" % os.path.getsize(zp))
    exe = os.path.join(root, "giac.exe")
    if os.path.isfile(exe) and os.path.isfile(os.path.join(root, "giac.dll")):
        return exe
    tmp = root + ".tmp"
    try:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
        with zipfile.ZipFile(zp) as z:
            z.extractall(tmp)
        shutil.rmtree(root, ignore_errors=True)
        os.replace(tmp, root)
    except OSError:
        return None
    return exe if os.path.isfile(exe) else None


def find_exe():
    for c in _candidates():
        if c and os.path.isfile(c):
            return c
    return _from_zip()


class Giac:
    def __init__(self):
        self.exe = find_exe()
        self.proc = None
        self.q = None
        self.lock = threading.Lock()
        self.failed = self.exe is None
        self.last_error = "" if self.exe else "No encontré giac.exe"

    @property
    def available(self):
        return not self.failed

    def _start(self):
        flags = 0
        if sys.platform.startswith("win"):
            flags = 0x08000000                     # CREATE_NO_WINDOW: sin ventana negra
        env = dict(os.environ)
        env.setdefault("HOME", os.path.expanduser("~"))
        self.proc = subprocess.Popen([self.exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, cwd=os.path.dirname(self.exe), env=env,
                                     text=True, encoding="utf-8", errors="replace", bufsize=1,
                                     creationflags=flags)
        self.q = queue.Queue()
        q, out = self.q, self.proc.stdout

        def reader():
            try:
                for line in out:
                    q.put(line)
            except (OSError, ValueError):
                pass
            q.put(None)
        threading.Thread(target=reader, daemon=True).start()
        self._raw("Digits:=15", 20.0)              # primera respuesta: también espera que arranque

    def cancel(self):
        """Esc en la calculadora: corta lo que Giac esté calculando."""
        if self.proc is not None and self.lock.locked():
            self._cancel = True
            self.kill()

    def kill(self):
        p, self.proc = self.proc, None
        if p is not None:
            try:
                p.kill()
            except OSError:
                pass

    def _raw(self, cmd, timeout):
        tag = "@@%d@@" % int(time.time() * 1000 % 1e9)
        self.proc.stdin.write('"%sB"+string(%s)+"%sE"\n' % (tag, cmd, tag))
        self.proc.stdin.flush()
        t0 = time.time()
        start = '"%sB' % tag
        while True:
            left = timeout - (time.time() - t0)
            if left <= 0:
                self.kill()
                raise GiacTimeout("Giac tardó más de %.0f s" % timeout)
            try:
                line = self.q.get(timeout=min(0.1, left))
            except queue.Empty:
                continue
            if line is None:
                self.kill()
                if getattr(self, "_cancel", False):
                    raise GiacCancelled("cancelado")
                raise GiacError("Giac se cerró")
            s = line.strip()
            if s.startswith(start) and s.endswith('%sE"' % tag):
                return s[len(start):-len(tag) - 2]

    def ask(self, cmd, timeout=TIMEOUT):
        if self.failed:
            raise GiacError(self.last_error)
        with self.lock:
            self._cancel = False
            try:
                if self.proc is None or self.proc.poll() is not None:
                    self._start()
                return self._raw(cmd, timeout)
            except GiacTimeout:
                raise
            except (OSError, GiacError) as e:
                self.kill()
                self.failed = True
                self.last_error = "Giac no funcionó: %s" % e
                raise GiacError(self.last_error)


_G = None


def instance():
    global _G
    if _G is None:
        _G = Giac()
        import atexit
        atexit.register(_G.kill)
    return _G


def cancel():
    if _G is not None:
        _G.cancel()


def available():
    return instance().available


# ---------------------------------------------------------------- SymPy -> texto de Giac
class _Printer(sp.printing.str.StrPrinter):
    def _print_Pow(self, e):
        b, x = e.as_base_exp()
        if x == sp.S.Half:
            return "sqrt(%s)" % self._print(b)
        if x == -1:
            return "1/(%s)" % self._print(b)
        return "(%s)^(%s)" % (self._print(b), self._print(x))

    def _print_ImaginaryUnit(self, e):
        return "i"

    def _print_Exp1(self, e):
        return "exp(1)"

    def _print_Pi(self, e):
        return "pi"

    def _print_Infinity(self, e):
        return "inf"

    def _print_NegativeInfinity(self, e):
        return "-inf"

    def _print_Rational(self, e):
        return "(%d/%d)" % (e.p, e.q)

    def _print_Float(self, e):
        return repr(float(e))

    def _print_Function(self, e):
        name = {"log": "ln", "Abs": "abs", "asin": "asin", "acos": "acos", "atan": "atan", "sign": "sign",
                "re": "re", "im": "im", "conjugate": "conj", "arg": "arg", "LambertW": "LambertW"}.get(
            e.func.__name__, e.func.__name__)
        return "%s(%s)" % (name, ", ".join(self._print(a) for a in e.args))

    def _print_Symbol(self, e):
        return e.name


def to_giac(expr):
    return _Printer().doprint(expr)


def rename(exprs):
    """Cambia los símbolos por v0, v1… (Giac no conoce θ, ω, y' ni nombres reservados)."""
    syms = set()
    for e in exprs:
        syms |= getattr(e, "free_symbols", set())
    syms = sorted(syms, key=lambda s: s.name)
    fwd = {s: sp.Symbol("tnsv%d" % i) for i, s in enumerate(syms)}
    back = {v: k for k, v in fwd.items()}
    return fwd, back


# ---------------------------------------------------------------- texto de Giac -> SymPy
_LOCAL = {"ln": sp.log, "log10": lambda x: sp.log(x, 10), "abs": sp.Abs, "sqrt": sp.sqrt, "exp": sp.exp,
          "atan": sp.atan, "asin": sp.asin, "acos": sp.acos, "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
          "sinh": sp.sinh, "cosh": sp.cosh, "tanh": sp.tanh, "pi": sp.pi, "i": sp.I, "inf": sp.oo,
          "infinity": sp.oo, "undef": sp.nan, "LambertW": sp.LambertW, "erf": sp.erf, "sign": sp.sign,
          "floor": sp.floor, "ceil": sp.ceiling, "re": sp.re, "im": sp.im, "conj": sp.conjugate,
          "Heaviside": sp.Heaviside, "Dirac": sp.DiracDelta, "e": sp.E, "euler_gamma": sp.EulerGamma,
          "Gamma": sp.gamma, "Si": sp.Si, "Ci": sp.Ci, "Ei": sp.Ei}


def _split_top(s):
    out, d, cur = [], 0, ""
    for ch in s:
        if ch in "([{":
            d += 1
        elif ch in ")]}":
            d -= 1
        if ch == "," and d == 0:
            out.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur)
    return out


def parse(text, back=None):
    """Una expresión de Giac (o una lista list[...] / [...]) a SymPy."""
    t = text.strip()
    if t.startswith("list["):
        t = t[4:]
    if t.startswith("[") and t.endswith("]"):
        return [parse(x, back) for x in _split_top(t[1:-1])]
    if t.startswith("set[") and t.endswith("]"):
        return [parse(x, back) for x in _split_top(t[4:-1])]
    if t.startswith('"') or "Error" in t:
        raise GiacError(t.strip('"'))
    t = t.replace("^", "**")
    t = re.sub(r"\bn_(\d+)\b", r"n\1", t)
    loc = dict(_LOCAL)
    if back:
        for k, v in back.items():
            loc[k.name] = v
    try:
        from sympy.parsing.sympy_parser import parse_expr, standard_transformations
        v = parse_expr(t, local_dict=loc, transformations=standard_transformations, evaluate=True)
    except Exception as e:  # noqa: BLE001
        raise GiacError("No entendí la respuesta de Giac: %s (%s)" % (text[:80], e))
    return v


def clean_number(v, ref=None):
    """Ruido numérico de Giac (2.35e-12 junto a 4.49) -> 0, como la TI."""
    try:
        if isinstance(v, sp.Float) or (v.is_number and v.atoms(sp.Float)):
            c = complex(v)
            scale = max(1.0, abs(ref) if ref else 1.0)
            if abs(c.imag) < 1e-10 * scale and c.imag != 0:
                v = sp.re(v)
                c = complex(c.real, 0)
            if abs(c.real) < 1e-10 * scale and c.real != 0:
                v = sp.Float(0) + sp.I * sp.im(v) if c.imag else sp.Float(0)
        return v
    except (TypeError, ValueError):
        return v


def to_decimal_if_special(v):
    """La TI muestra en decimal lo que no tiene forma cerrada simple (LambertW, raíces de polinomios…)."""
    if isinstance(v, sp.Basic) and v.has(sp.LambertW, sp.CRootOf):
        try:
            return sp.N(v, 15)
        except Exception:  # noqa: BLE001
            return v
    return v


def _recognize(x):
    """Un decimal que es una fracción simple o (fracción)·π -> exacto (π/2, 1/3…); si no, None."""
    from fractions import Fraction
    for base in (sp.Integer(1), sp.pi):
        q = x / float(base)
        f = Fraction(q).limit_denominator(24)
        if abs(float(f) - q) < 1e-12 * max(1.0, abs(q)):
            return sp.Rational(f.numerator, f.denominator) * base
    return None


def polish(v):
    """Deja la solución como la mostraría la TI."""
    try:
        if not isinstance(v, sp.Basic):
            return v
        if v.is_number and not v.atoms(sp.Float):
            if v.has(sp.I) or v.has(sp.asin, sp.acos, sp.atan) or sp.count_ops(v) > 25:
                c = complex(sp.N(v, 30))
                if abs(c.imag) < 1e-12 * max(1.0, abs(c)):          # raíz real escrita con ⅈ (Cardano)
                    r = _recognize(c.real)
                    if r is not None:
                        return r
                    if v.has(sp.I) or sp.count_ops(v) > 25:
                        return sp.Float(c.real, 15)
            return v
        if not v.is_number:
            t = sp.together(v)
            if sp.count_ops(t) <= sp.count_ops(v):
                return t
        return v
    except Exception:  # noqa: BLE001
        return v


# ---------------------------------------------------------------- operaciones
def solve(eqs, vs, cplx=False, timeout=TIMEOUT):
    """eqs: expresiones (= 0); vs: símbolos. Devuelve una lista de dicts {var: valor} (como sp.solve dict=True)."""
    fwd, back = rename(list(eqs) + list(vs))
    es = [to_giac(sp.sympify(e).xreplace(fwd)) + "=0" for e in eqs]
    xs = [to_giac(v.xreplace(fwd)) for v in vs]
    fn = "csolve" if cplx else "solve"
    if len(es) == 1 and len(xs) == 1:
        cmd = "%s(%s,%s)" % (fn, es[0], xs[0])
    else:
        cmd = "%s([%s],[%s])" % (fn, ",".join(es), ",".join(xs))
    ans = instance().ask(cmd, timeout)
    if "rootof" in ans:                            # raíces sin fórmula: en decimal, como la TI
        ans = instance().ask("evalf(%s)" % cmd, timeout)
    res = parse(ans, back)
    if not isinstance(res, list):
        res = [res]
    out = []
    for r in res:
        vals = r if isinstance(r, list) else [r]
        if len(vals) != len(vs):
            continue
        vals = [polish(to_decimal_if_special(v)) for v in vals]
        top = max([abs(complex(v)) for v in vals if getattr(v, "is_number", False)] or [1.0])
        out.append({v: clean_number(val, top) for v, val in zip(vs, vals)})
    if len(vs) == 1 and out:                       # ruido 1e-12 junto a soluciones grandes
        nums = [abs(complex(d[vs[0]])) for d in out if d[vs[0]].is_number]
        top = max(nums or [1.0])
        out = [{vs[0]: clean_number(d[vs[0]], top)} for d in out]
    return out


def integrate(expr, var, timeout=TIMEOUT):
    fwd, back = rename([expr, var])
    cmd = "integrate(%s,%s)" % (to_giac(sp.sympify(expr).xreplace(fwd)), to_giac(var.xreplace(fwd)))
    r = parse(instance().ask(cmd, timeout), back)
    if isinstance(r, list) or (isinstance(r, sp.Basic) and r.has(sp.Integral)):
        raise GiacError("sin primitiva")
    return r


def solve_general(ex, v, timeout=TIMEOUT):
    """Soluciones generales (con n_1, n_2… enteros) de una ecuación en una variable."""
    fwd, back = rename([ex, v])
    g = instance()
    g.ask("all_trig_solutions:=1", timeout)
    try:
        ans = g.ask("solve(%s=0,%s)" % (to_giac(sp.sympify(ex).xreplace(fwd)), to_giac(v.xreplace(fwd))), timeout)
    finally:
        try:
            g.ask("all_trig_solutions:=0", timeout)
        except GiacError:
            pass
    if "rootof" in ans:
        return []
    res = parse(ans, back)
    return res if isinstance(res, list) else [res]
