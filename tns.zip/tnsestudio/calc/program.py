"""
program.py - Funciones y programas como los de la TI-Nspire (TI-Basic):

    Define f(x)=Func
      Local s,i
      s:=0
      For i,1,x
        s:=s+i^2
      EndFor
      Return s
    EndFunc

Las líneas se separan con Enter o con ":" (Define f(x)=Func:Return x^2:EndFunc).
Se entiende: Local, If…Then…ElseIf…Else…EndIf, If (de una línea), For…EndFor, While…EndWhile,
Loop…EndLoop, Try…Else…EndTry, Return, Exit, Cycle, Stop, Disp, := y →.
"""
from __future__ import annotations

import re

import sympy as sp

MAX_STEPS = 200000
MAX_DEPTH = 60


class ProgError(Exception):
    pass


class _Return(Exception):
    def __init__(self, value):
        self.value = value


class _Exit(Exception):
    pass


class _Cycle(Exception):
    pass


class _Stop(Exception):
    pass


DEF_RE = re.compile(r"^\s*define\s+([A-Za-z][A-Za-z0-9_]*)\s*\(([^)]*)\)\s*=\s*(func|prgm)\b(.*?)\b(endfunc|endprgm)\s*$",
                    re.I | re.S)


def split_lines(text):
    """Líneas del programa: separa por Enter y por ':' (sin romper ':=' ni textos entre comillas)."""
    out, cur, q = [], "", False
    i = 0
    while i < len(text):
        c = text[i]
        if c == '"':
            q = not q
        if not q and c in "\r\n":
            out.append(cur)
            cur = ""
        elif not q and c == ":" and text[i + 1:i + 2] != "=":
            out.append(cur)
            cur = ""
        else:
            cur += c
        i += 1
    out.append(cur)
    lines = []
    for ln in out:
        ln = ln.split("©", 1)[0].strip()
        if ln:
            lines.append(ln)
    return lines


def _kw(line):
    m = re.match(r"^([A-Za-z]+)\b", line)
    return m.group(1).lower() if m else ""


def parse(lines):
    nodes, i, term = _block(lines, 0, ())
    if term:
        raise ProgError("Sobra «%s»" % term)
    return nodes


def _block(lines, i, ends):
    nodes = []
    while i < len(lines):
        ln = lines[i]
        k = _kw(ln)
        if k in ends or (("elseif" in ends) and k == "elseif") or (k == "else" and "else" in ends):
            return nodes, i, k
        if k == "local":
            nodes.append(("local", [n.strip() for n in ln[5:].split(",") if n.strip()]))
            i += 1
        elif k == "if":
            m = re.match(r"^if\s+(.*?)\s+then\s*$", ln, re.I)
            if m:
                branches = []
                cond = m.group(1)
                i += 1
                els = None
                while True:
                    body, i, t = _block(lines, i, ("elseif", "else", "endif"))
                    branches.append((cond, body))
                    if t == "elseif":
                        mm = re.match(r"^elseif\s+(.*?)\s+then\s*$", lines[i], re.I)
                        if not mm:
                            raise ProgError("ElseIf necesita Then: %s" % lines[i])
                        cond = mm.group(1)
                        i += 1
                        continue
                    if t == "else":
                        i += 1
                        els, i, t2 = _block(lines, i, ("endif",))
                        if t2 != "endif":
                            raise ProgError("Falta EndIf")
                        i += 1
                        break
                    if t == "endif":
                        i += 1
                        break
                    raise ProgError("Falta EndIf")
                nodes.append(("if", branches, els))
            else:
                cond = ln[2:].strip()
                if i + 1 >= len(lines):
                    raise ProgError("Después de If va una instrucción")
                body, _j, _t = _block([lines[i + 1]], 0, ())
                nodes.append(("if", [(cond, body)], None))
                i += 2
        elif k == "for":
            parts = _args(ln[3:])
            if len(parts) not in (3, 4):
                raise ProgError("For variable, inicio, fin[, paso]")
            body, i, t = _block(lines, i + 1, ("endfor",))
            if t != "endfor":
                raise ProgError("Falta EndFor")
            nodes.append(("for", parts[0].strip(), parts[1], parts[2], parts[3] if len(parts) == 4 else "1", body))
            i += 1
        elif k == "while":
            body, j, t = _block(lines, i + 1, ("endwhile",))
            if t != "endwhile":
                raise ProgError("Falta EndWhile")
            nodes.append(("while", ln[5:].strip(), body))
            i = j + 1
        elif k == "loop":
            body, j, t = _block(lines, i + 1, ("endloop",))
            if t != "endloop":
                raise ProgError("Falta EndLoop")
            nodes.append(("loop", body))
            i = j + 1
        elif k == "try":
            body, j, t = _block(lines, i + 1, ("else", "endtry"))
            els = []
            if t == "else":
                els, j, t = _block(lines, j + 1, ("endtry",))
            if t != "endtry":
                raise ProgError("Falta EndTry")
            nodes.append(("try", body, els))
            i = j + 1
        elif k == "return":
            nodes.append(("return", ln[6:].strip()))
            i += 1
        elif k in ("exit", "cycle", "stop", "clrerr", "passerr"):
            nodes.append((k,))
            i += 1
        elif k == "disp":
            nodes.append(("disp", _args(ln[4:])))
            i += 1
        elif k in ("endif", "endfor", "endwhile", "endloop", "endtry", "else", "elseif"):
            return nodes, i, k
        else:
            nodes.append(("stmt", ln))
            i += 1
    return nodes, i, None


def _args(s):
    out, cur, d, q = [], "", 0, False
    for c in s:
        if c == '"':
            q = not q
        if not q and c in "([{":
            d += 1
        elif not q and c in ")]}":
            d -= 1
        if c == "," and d == 0 and not q:
            out.append(cur.strip())
            cur = ""
        else:
            cur += c
    if cur.strip():
        out.append(cur.strip())
    return out


class Program:
    def __init__(self, name, params, kind, body_text, source):
        self.name, self.params, self.kind, self.source = name, params, kind, source
        self.nodes = parse(split_lines(body_text))


def define(text):
    """'Define f(x)=Func … EndFunc' -> Program (o None si no es una definición de programa)."""
    m = DEF_RE.match(text)
    if not m:
        return None
    name, params, kind, body = m.group(1), m.group(2), m.group(3).lower(), m.group(4)
    ps = [p.strip() for p in params.split(",") if p.strip()]
    for p in ps:
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", p):
            raise ProgError("Parámetro inválido: %s" % p)
    return Program(name, ps, kind, body, text.strip())


class Runner:
    def __init__(self, engine):
        self.e = engine
        self.steps = 0

    def value(self, text):
        from .engine import Parser, tokenize
        p = Parser(self.e, tokenize(text))
        v, info = p.statement()
        nm = info.get("assigned") if isinstance(info, dict) else None
        if nm and not info.get("def"):
            # como la TI: con un decimal en la cuenta (modo Auto) lo guardado queda en decimal;
            # si no, δ:=δ+h*w dentro de un For arrastra sin⁻¹(1/3)+0.0012+… y se vuelve lentísimo
            from .engine import TIList, approx, has_float
            mode = self.e.settings.mode
            if isinstance(v, (sp.Basic, TIList)) and (mode == "Aproximado" or mode == "Auto" and (has_float(v) or info.get("dec"))):
                try:
                    v = approx(v)
                    self.e.vars[nm.lower()] = v
                except Exception:  # noqa: BLE001
                    pass
        return v

    def cond(self, text):
        v = self.value(text)
        if v is sp.true or v is True:
            return True
        if v is sp.false or v is False:
            return False
        try:
            return bool(v)
        except TypeError:
            raise ProgError("No se puede decidir la condición «%s» (¿falta un valor?)" % text)

    def tick(self):
        self.steps += 1
        if self.steps > MAX_STEPS:
            raise ProgError("El programa no termina (más de %d pasos)" % MAX_STEPS)

    def run(self, nodes):
        for n in nodes:
            self.tick()
            k = n[0]
            if k == "stmt":
                self.value(n[1])
            elif k == "local":
                for name in n[1]:
                    self.e.vars.pop(name.lower(), None)
            elif k == "if":
                done = False
                for cond, body in n[1]:
                    if self.cond(cond):
                        self.run(body)
                        done = True
                        break
                if not done and n[2]:
                    self.run(n[2])
            elif k == "for":
                var, a, b, st, body = n[1], self.value(n[2]), self.value(n[3]), self.value(n[4]), n[5]
                i = a
                try:
                    while (sp.sympify(st) > 0 and sp.sympify(i) <= b) or (sp.sympify(st) < 0 and sp.sympify(i) >= b):
                        self.e.vars[var.lower()] = i
                        self.e.names[var.lower()] = var
                        try:
                            self.run(body)
                        except _Cycle:
                            pass
                        i = self.e.vars.get(var.lower(), i) + st
                        self.tick()
                except _Exit:
                    pass
                except TypeError:
                    raise ProgError("Los límites del For deben ser números")
            elif k == "while":
                try:
                    while self.cond(n[1]):
                        try:
                            self.run(n[2])
                        except _Cycle:
                            pass
                        self.tick()
                except _Exit:
                    pass
            elif k == "loop":
                try:
                    while True:
                        try:
                            self.run(n[1])
                        except _Cycle:
                            pass
                        self.tick()
                except _Exit:
                    pass
            elif k == "try":
                from .engine import CalcError
                try:
                    self.run(n[1])
                except (CalcError, ProgError, ZeroDivisionError, TypeError, ValueError):
                    self.run(n[2])
            elif k == "return":
                raise _Return(self.value(n[1]) if n[1] else None)
            elif k == "exit":
                raise _Exit()
            elif k == "cycle":
                raise _Cycle()
            elif k == "stop":
                raise _Stop()
            elif k == "disp":
                vals = []
                for a in n[1]:
                    a = a.strip()
                    vals.append(a[1:-1] if a.startswith('"') and a.endswith('"') else self.value(a))
                self.e.disp_out.append(vals)


def call(engine, prog, args):
    """Ejecuta el programa con los argumentos (ya evaluados). Func devuelve el valor de Return."""
    from .engine import DONE, CalcError
    if len(args) != len(prog.params):
        raise CalcError("%s necesita %d argumento(s)" % (prog.name, len(prog.params)))
    depth = getattr(engine, "_prog_depth", 0)
    if depth > MAX_DEPTH:
        raise CalcError("Demasiadas llamadas anidadas (¿recursión sin fin?)")
    engine._prog_depth = depth + 1
    names = set(p.lower() for p in prog.params)
    for n in prog.nodes:
        if n[0] == "local":
            names |= {x.lower() for x in n[1]}
    _collect_locals(prog.nodes, names)
    saved = {k: engine.vars[k] for k in names if k in engine.vars}
    if not hasattr(engine, "disp_out"):
        engine.disp_out = []
    r = Runner(engine)
    try:
        for p, a in zip(prog.params, args):
            engine.vars[p.lower()] = a
            engine.names[p.lower()] = p
        try:
            r.run(prog.nodes)
            ret = None
        except _Return as rv:
            ret = rv.value
        except _Stop:
            ret = None
        except (_Exit, _Cycle):
            raise CalcError("Exit/Cycle fuera de un ciclo")
        except ProgError as ex:
            raise CalcError("%s: %s" % (prog.name, ex))
    finally:
        for k in names:
            engine.vars.pop(k, None)
        engine.vars.update(saved)
        engine._prog_depth = depth
    if prog.kind == "func":
        if ret is None:
            raise CalcError("La función %s no devolvió un valor (falta Return)" % prog.name)
        return ret
    return DONE


def _collect_locals(nodes, names):
    for n in nodes:
        if n[0] == "local":
            names |= {x.lower() for x in n[1]}
        for part in n[1:]:
            if isinstance(part, list) and part and isinstance(part[0], tuple):
                _collect_locals(part, names)
            if isinstance(part, list) and part and isinstance(part[0], tuple) and len(part[0]) == 2 \
                    and isinstance(part[0][1], list):
                for _c, body in part:
                    _collect_locals(body, names)
