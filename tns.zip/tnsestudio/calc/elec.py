"""
elec.py - Funciones de eléctrica: Δ↔Y, paralelo, cuadripolos (redes de dos puertos).

Reemplazan a las librerías de la TI de Vicente (electrica, cuadripolo) pero sin ventanitas:
se llaman directo, aceptan fasores y unidades y dan errores claros.
"""
from __future__ import annotations

import sympy as sp


class ElecError(ValueError):
    pass


def delta2y(zab, zbc, zca):
    tot = zab + zbc + zca
    if tot == 0:
        raise ElecError("La suma Zab+Zbc+Zca no puede ser 0")
    return [("Za", zab * zca / tot), ("Zb", zab * zbc / tot), ("Zc", zbc * zca / tot)]


def y2delta(za, zb, zc):
    if 0 in (za, zb, zc):
        raise ElecError("Ninguna impedancia de la estrella puede ser 0")
    n = za * zb + zb * zc + zc * za
    return [("Zab", n / zc), ("Zbc", n / za), ("Zca", n / zb)]


def par(*zs):
    if not zs:
        raise ElecError("par() necesita al menos una impedancia")
    return 1 / sp.Add(*[1 / z for z in zs])


# ---------------- cuadripolos ----------------
TYPES = {"z": "z", "y": "y", "h": "h", "g": "g", "a": "a", "abcd": "a"}


def _type(t):
    t = str(t).strip().strip('"').lower()
    if t not in TYPES:
        raise ElecError('Tipo de parámetros "%s" no válido. Usa "z", "y", "h", "g" o "a" (ABCD)' % t)
    return TYPES[t]


def _need(x, what):
    if x == 0:
        raise ElecError("Esos parámetros no tienen representación %s (división por 0)" % what)


def to_abcd(t, x11, x12, x21, x22):
    t = _type(t)
    if t == "a":
        return sp.Matrix([[x11, x12], [x21, x22]])
    d = x11 * x22 - x12 * x21
    if t == "z":
        _need(x21, "ABCD")
        return sp.Matrix([[x11 / x21, d / x21], [1 / x21, x22 / x21]])
    if t == "y":
        _need(x21, "ABCD")
        return sp.Matrix([[-x22 / x21, -1 / x21], [-d / x21, -x11 / x21]])
    if t == "h":
        _need(x21, "ABCD")
        return sp.Matrix([[-d / x21, -x11 / x21], [-x22 / x21, -1 / x21]])
    if t == "g":
        _need(x21, "ABCD")
        return sp.Matrix([[1 / x21, x22 / x21], [x11 / x21, d / x21]])
    raise ElecError("Tipo no válido")


def from_abcd(t, M):
    t = _type(t)
    a, b, c, d = M[0, 0], M[0, 1], M[1, 0], M[1, 1]
    da = a * d - b * c
    if t == "a":
        return sp.Matrix([[a, b], [c, d]])
    if t == "z":
        _need(c, "z")
        return sp.Matrix([[a / c, da / c], [1 / c, d / c]])
    if t == "y":
        _need(b, "y")
        return sp.Matrix([[d / b, -da / b], [-1 / b, a / b]])
    if t == "h":
        _need(d, "h")
        return sp.Matrix([[b / d, da / d], [-1 / d, c / d]])
    if t == "g":
        _need(a, "g")
        return sp.Matrix([[c / a, -da / a], [1 / a, b / a]])
    raise ElecError("Tipo no válido")


def convert(t1, x11, x12, x21, x22, t2):
    return from_abcd(t2, to_abcd(t1, x11, x12, x21, x22)).applyfunc(sp.simplify)


def _abcd_any(t, M):
    return to_abcd(t, M[0, 0], M[0, 1], M[1, 0], M[1, 1])


CONNECTIONS = {
    "serie": "z", "series": "z", "s": "z", "ss": "z", "z": "z",
    "paralelo": "y", "parallel": "y", "p": "y", "pp": "y", "y": "y",
    "cascada": "a", "cascade": "a", "c": "a", "a": "a", "abcd": "a",
    "serie-paralelo": "h", "seriesparallel": "h", "series-parallel": "h", "sp": "h", "h": "h",
    "paralelo-serie": "g", "parallelseries": "g", "parallel-series": "g", "ps": "g", "g": "g",
}


def connect(kind, t1, x11, x12, x21, x22, t2, c11, c12, c21, c22, tout):
    k = str(kind).strip().strip('"').lower().replace(" ", "")
    if k not in CONNECTIONS:
        raise ElecError('Conexión "%s" no válida. Usa "serie", "paralelo", "cascada", '
                        '"serie-paralelo" o "paralelo-serie"' % kind)
    via = CONNECTIONS[k]
    a1 = to_abcd(t1, x11, x12, x21, x22)
    a2 = to_abcd(t2, c11, c12, c21, c22)
    if via == "a":
        res = a1 * a2
    else:
        res = to_abcd(via, *list(from_abcd(via, a1) + from_abcd(via, a2)))
    return from_abcd(tout, res).applyfunc(sp.simplify)


def cperf(t, x11, x12, x21, x22, zl, zs, vs):
    """Desempeño de un cuadripolo con fuente (vs, zs) y carga zl."""
    M = to_abcd(t, x11, x12, x21, x22)
    a, b, c, d = M[0, 0], M[0, 1], M[1, 0], M[1, 1]
    zin = (a * zl + b) / (c * zl + d)
    zout = (d * zs + b) / (c * zs + a)
    i1 = vs / (zs + zin)
    v1 = vs * zin / (zs + zin)
    av = zl / (a * zl + b)
    v2 = av * v1
    il = v2 / zl
    ai = 1 / (c * zl + d)
    vth = vs / (a + c * zs)
    out = [("Zin", zin), ("Zout", zout), ("V1", v1), ("I1", i1), ("V2", v2), ("I2", il),
           ("Av", av), ("Ai", ai), ("Vth", vth)]
    return [(n, sp.simplify(v)) for n, v in out]


# ---------------- por unidad ----------------
_KINDS = {(2, 1, -3, 0, 0, 0, 0): "S", (2, 1, -3, -1, 0, 0, 0): "V", (2, 1, -3, -2, 0, 0, 0): "Z",
          (0, 0, 0, 1, 0, 0, 0): "I"}


def kind(x):
    """'S' (VA, W, var), 'V', 'Z' (Ω), 'I' (A) o None si no tiene unidades eléctricas."""
    try:
        from . import units
        if not units.has_units(x):
            return None
        return _KINDS.get(units.dims(units.split(sp.sympify(x))[1]))
    except Exception:  # noqa: BLE001
        return None


def order(a, b, ka, kb):
    """Si los dos datos vienen con unidades y en el orden contrario (b es de tipo ka y a de tipo kb),
    los da vuelta: bases(13.8_kV,100_MVA) = bases(100_MVA,13.8_kV)."""
    if kind(a) == kb and kind(b) == ka:
        return b, a
    return a, b


def zbase(vb, sb):
    """Zbase = Vb²/Sb (Vb de línea, Sb trifásica)."""
    vb, sb = order(vb, sb, "V", "S")
    if sb == 0:
        raise ElecError("La potencia base no puede ser 0")
    return vb ** 2 / sb


def ibase(sb, vb):
    """Ibase = Sb/(√3·Vb)."""
    sb, vb = order(sb, vb, "S", "V")
    if vb == 0:
        raise ElecError("La tensión base no puede ser 0")
    return sb / (sp.sqrt(3) * vb)


def zpu(z, vb, sb):
    """Z en por unidad = Z·Sb/Vb²."""
    args = [z, vb, sb]
    ks = [kind(a) for a in args]
    if sorted(k or "" for k in ks) == ["S", "V", "Z"]:          # vienen en cualquier orden
        z, vb, sb = (args[ks.index(k)] for k in ("Z", "V", "S"))
    return z / zbase(vb, sb)


def cambiobase(zpu_, vb_old, sb_old, vb_new, sb_new):
    """Zpu nueva = Zpu vieja·(Vb vieja/Vb nueva)²·(Sb nueva/Sb vieja)."""
    vb_old, sb_old = order(vb_old, sb_old, "V", "S")
    vb_new, sb_new = order(vb_new, sb_new, "V", "S")
    return zpu_ * (vb_old / vb_new) ** 2 * (sb_new / sb_old)


# ---------------- trifásico ----------------
_SH = sp.sqrt(3) * sp.exp(sp.I * sp.pi / 6)      # √3∠30°


def _is_phasor(v):
    try:
        return bool(sp.sympify(v).has(sp.I))
    except (TypeError, ValueError):
        return False


def _clean(z):
    w = sp.expand_complex(sp.expand(z))
    if not w.atoms(sp.Float):
        w = sp.nsimplify(sp.simplify(w))
    return w


def linea(vf):
    """Tensión de línea desde la de fase: √3·Vf (si es fasor, √3∠30°·Vf, secuencia positiva)."""
    return _clean(vf * _SH) if _is_phasor(vf) else sp.sqrt(3) * vf


def fase(vl):
    """Tensión de fase desde la de línea: Vl/√3 (si es fasor, Vl/(√3∠30°))."""
    return _clean(vl / _SH) if _is_phasor(vl) else vl / sp.sqrt(3)


def pot3f(vl, il, fp):
    """Potencias trifásicas con tensión y corriente de línea y factor de potencia."""
    vl, il = order(vl, il, "V", "I")
    if not (-1 <= sp.N(fp) <= 1):
        raise ElecError("El factor de potencia va entre -1 y 1")
    s = sp.sqrt(3) * vl * il
    q = s * sp.sqrt(1 - fp ** 2)
    from . import units
    if units.has_units(s) and units.dims(sp.simplify(s)) == units.dims(units.W_):
        w = units.W_                                   # S en VA y Q en var (no en W)
        return [("S", sp.simplify(s / w) * sp.Symbol("_VA")), ("P", s * fp),
                ("Q", sp.simplify(q / w) * sp.Symbol("_var"))]
    return [("S", s), ("P", s * fp), ("Q", q)]


def scomp(v, i):
    """Potencia compleja S = V·I* (monofásica, con fasores)."""
    v, i = order(v, i, "V", "I")
    return sp.expand(v * sp.conjugate(i))


def s3f(vf, i_f):
    """Potencia compleja trifásica equilibrada S = 3·Vf·If* (fasores de fase)."""
    vf, i_f = order(vf, i_f, "V", "I")
    return sp.expand(3 * vf * sp.conjugate(i_f))
