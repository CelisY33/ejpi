"""
core.py - El "cerebro" de la calculadora sin ventanas: texto (o fila 2D) -> resultado.

Lo usan la pestaña Calculadora del PC (calctab.py, mismo camino de cálculo) y la calculadora física / la
versión de terminal (terminal.py). No importa Qt.

    calc = Calculadora("carpeta")            # carpeta donde se guarda estado.json (o None: no guarda)
    r = calc.calcular("solve(x^2=4,x)")      # Resultado: filas 2D, texto, error, pista ≈
    calc.historial                           # [Entrada], como el historial de la TI
    calc.deshacer() / calc.rehacer()         # Ctrl+Z / Ctrl+Y sobre los cálculos (como la TI)
    calc.pantalla(linea, 320, 240)           # imagen de la pantalla (Pillow), ver render.py
"""
from __future__ import annotations

import copy
import json
import os
import re
from dataclasses import dataclass, field

from . import rows as R
from .rows import Row, row_from_json, row_to_json, to_linear

# nombres con mayúsculas como los escribe la TI (para mostrar solve → solve, csolve → cSolve…)
EXTRA_CANONICAL = ["cSolve", "cZeros", "cFactor", "nSolve", "nCr", "nPr", "nInt", "nDerivative",
                   "linSolve", "polyRoots", "cPolyRoots", "approxFraction", "propFrac", "getNum",
                   "getDenom", "comDenom", "completeSquare", "tangentLine", "normalLine", "arcLen",
                   "fMin", "fMax", "impDif", "tExpand", "tCollect", "iPart", "fPart", "randInt",
                   "normCdf", "normPdf", "invNorm", "binomPdf", "binomCdf", "poissPdf", "poissCdf",
                   "stDevSamp", "varSamp", "eigVl", "eigVc", "charPoly", "rowNorm", "colNorm",
                   "rowDim", "colDim", "unitV", "crossP", "dotP", "subMat", "newMat", "randMat",
                   "cumulativeSum", "deltaList", "SortA", "SortD", "DelVar", "Define", "Ans", "constructMat"]

_CANON_DONE = False


def setup_canonical():
    """Nombres de funciones con sus mayúsculas (una vez)."""
    global _CANON_DONE
    if _CANON_DONE:
        return
    from . import pretty
    from .engine import CATALOG
    pretty.set_canonical([n for n, _syn, _d in CATALOG if n.isascii()] + EXTRA_CANONICAL)
    _CANON_DONE = True


def refresh_known(engine):
    """Nombres de funciones que se dibujan en negrita (las de la calculadora y las del usuario)."""
    R.KNOWN_FUNCS.clear()
    R.KNOWN_FUNCS.update(k for k in engine._fn if not k.endswith("_"))
    R.KNOWN_FUNCS.update(engine.funcs)
    R.KNOWN_FUNCS.update(engine.progs)
    R.KNOWN_FUNCS.update(("define", "delvar"))


def is_def(t: str) -> bool:
    tl = t.strip().lower()
    return ":=" in t or "→" in t or "->" in t or tl.startswith("define ") or tl.startswith("delvar ")


def is_prog_def(t: str) -> bool:
    return bool(re.match(r"^\s*define\b.*=\s*(func|prgm)\b", t, re.I | re.S))


@dataclass
class Evaluacion:
    res: object                 # engine.Result
    rows: list                  # filas 2D del resultado (con lo de Disp antes)
    hint: object = None         # fila "≈ 0.333333" en modo Auto, o None
    full_rows: list = None      # filas con 14 cifras (lo que se pega, como la TI), o None


def evaluar(engine, text, approx=False) -> Evaluacion:
    """Calcula y da formato como la TI. Lanza engine.SyntaxErr / engine.CalcError (u otra excepción)."""
    from .engine import Result
    from .fmt import approx_hint, format_result
    engine.disp_out = []
    res = engine.evaluate(text, approx)
    rows = format_result(res, engine.settings)
    hint = approx_hint(res, engine.settings)
    full = None
    try:                                     # al pegar un resultado la TI usa todas las cifras (14)
        st = copy.copy(engine.settings)
        if not str(st.digits).startswith("Fijo") and st.digits != "Flotante14":
            st.digits = "Flotante14"
            f = format_result(res, st)
            if [to_linear(r) for r in f] != [to_linear(r) for r in rows]:
                full = f
    except Exception:  # noqa: BLE001
        full = None
    if engine.disp_out:                      # lo que mostró Disp va antes del resultado (como la TI)
        drows = []
        for vals in engine.disp_out:
            r = Row()
            for i, v in enumerate(vals):
                if i:
                    r.append("  ")
                if isinstance(v, str):
                    r.extend(list(v))
                else:
                    sub = format_result(Result(text="", value=v, approx=res.approx), engine.settings)
                    r.extend(sub[0] if sub else [])
            drows.append(r)
        rows = drows + list(rows)
        if full is not None:
            full = drows + list(full)
    return Evaluacion(res, rows, hint, full)


@dataclass
class Entrada:
    """Una línea del historial (igual que la de la app de PC)."""
    entrada: Row
    texto: str
    filas: list = field(default_factory=list)
    pista: object = None
    error: str = None
    completas: list = None

    def to_json(self):
        d = {"t": self.texto, "in": row_to_json(self.entrada), "out": [row_to_json(r) for r in self.filas],
             "hint": row_to_json(self.pista) if self.pista is not None else None, "err": self.error}
        if self.completas:
            d["full"] = [row_to_json(r) for r in self.completas]
        return d

    @classmethod
    def from_json(cls, d):
        return cls(row_from_json(d.get("in", [])), d.get("t", ""), [row_from_json(r) for r in d.get("out", [])],
                   row_from_json(d["hint"]) if d.get("hint") else None, d.get("err"),
                   [row_from_json(r) for r in d["full"]] if d.get("full") else None)


@dataclass
class Resultado:
    tipo: str                   # "ok", "error" (queda en el historial) o "sintaxis" (la línea se queda)
    texto: str
    entrada: Row = None
    filas: list = field(default_factory=list)
    pista: object = None
    error: str = None
    completas: list = None
    valor: object = None        # el valor de SymPy (para quien lo necesite)

    def lineal(self) -> str:
        if self.tipo != "ok":
            return "Error: " + (self.error or "")
        return " | ".join(to_linear(r) for r in self.filas)


class Calculadora:
    MAX_HIST = 200

    def __init__(self, carpeta=None, ajustes=None):
        from .engine import Engine, Settings
        setup_canonical()
        self.carpeta = carpeta
        st = Settings()
        for k, v in (ajustes or {}).items():
            if hasattr(st, k):
                setattr(st, k, v)
        self.ajustes = st
        self.engine = Engine(st)
        self.historial: list[Entrada] = []
        self._hechos, self._deshechos = [], []
        if carpeta:
            self.cargar()
        refresh_known(self.engine)

    # ---------- calcular
    def calcular(self, entrada, aproximado=False) -> Resultado:
        """entrada: texto de corrido ("x^2+1") o una fila 2D (Row) de la línea de edición."""
        from .engine import CalcError, SyntaxErr
        from .pretty import from_linear, prettify
        if isinstance(entrada, str):
            fila = from_linear(entrada)
        else:
            fila = copy.deepcopy(entrada)
            R.solidify(fila)
        texto = to_linear(fila)
        if not texto.strip():
            return Resultado("sintaxis", texto, fila, error="Escribe algo para calcular")
        vacia = R.first_empty_required(fila)
        if vacia is not None:
            return Resultado("sintaxis", texto, fila, error="Falta completar una cajita")
        mostrada = prettify(fila)
        try:
            ev = evaluar(self.engine, texto, aproximado)
        except SyntaxErr as e:
            return Resultado("sintaxis", texto, fila, error=str(e))
        except CalcError as e:
            ent = Entrada(mostrada, texto, [], None, str(e))
            self._agregar(ent)
            return Resultado("error", texto, mostrada, error=str(e))
        except Exception as e:  # noqa: BLE001
            msg = "No pude calcular eso (%s)" % str(e)[:150]
            self._agregar(Entrada(mostrada, texto, [], None, msg))
            return Resultado("error", texto, mostrada, error=msg)
        ent = Entrada(mostrada, texto, ev.rows, ev.hint, None, ev.full_rows)
        self._agregar(ent)
        if ev.res.is_def or ":=" in texto or "→" in texto:
            refresh_known(self.engine)
        return Resultado("ok", texto, mostrada, ev.rows, ev.hint, None, ev.full_rows, ev.res.value)

    def _agregar(self, ent):
        self.historial.append(ent)
        del self.historial[:-self.MAX_HIST]
        self._hechos.append(ent)
        del self._hechos[:-100]
        self._deshechos.clear()
        self.guardar()

    # ---------- deshacer como la TI (el cálculo sale de la pantalla; las variables no se tocan)
    def deshacer(self):
        """Saca el último cálculo del historial y devuelve su fila (para volver a ponerla en la línea)."""
        while self._hechos:
            ent = self._hechos.pop()
            if ent in self.historial:
                self.historial.remove(ent)
                self._deshechos.append(ent)
                self.guardar()
                return copy.deepcopy(ent.entrada)
        return None

    def rehacer(self):
        if not self._deshechos:
            return None
        ent = self._deshechos.pop()
        self.historial.append(ent)
        self._hechos.append(ent)
        self.guardar()
        return ent

    def borrar(self, i):
        """Borra la entrada i del historial (Supr con una entrada elegida)."""
        if 0 <= i < len(self.historial):
            self.historial.pop(i)
            self.guardar()

    def limpiar(self):
        self.historial.clear()
        self.guardar()

    def pegar(self, i, resultado=True):
        """Lo que se pega al elegir con ↑ y Enter: la entrada, o el resultado con sus 14 cifras."""
        ent = self.historial[i]
        if not resultado or ent.error or not ent.filas:
            return copy.deepcopy(ent.entrada)
        src = ent.completas or ent.filas
        return copy.deepcopy(src[-1])

    # ---------- estado en archivo (en el PC la app usa sus propios ajustes)
    def _ruta(self):
        return os.path.join(self.carpeta, "estado.json") if self.carpeta else None

    def guardar(self):
        p = self._ruta()
        if not p:
            return
        defs = [e.texto for e in self.historial if not e.error and is_def(e.texto) and not is_prog_def(e.texto)]
        data = {"version": 1, "ajustes": dict(self.ajustes.__dict__),
                "historial": [e.to_json() for e in self.historial[-self.MAX_HIST:]],
                "definiciones": defs[-200:],
                "programas": [pr.source for pr in self.engine.progs.values()]}
        os.makedirs(self.carpeta, exist_ok=True)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)                       # sin archivos a medio escribir si se corta la luz

    def cargar(self):
        p = self._ruta()
        if not p or not os.path.isfile(p):
            return
        try:
            with open(p, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return
        for k, v in (data.get("ajustes") or {}).items():
            if hasattr(self.ajustes, k):
                setattr(self.ajustes, k, v)
        self.historial = []
        for d in data.get("historial") or []:
            try:
                self.historial.append(Entrada.from_json(d))
            except Exception:  # noqa: BLE001
                continue
        for t in (data.get("programas") or []) + (data.get("definiciones") or []):
            try:
                self.engine.evaluate(t)              # las variables y funciones vuelven a existir
            except Exception:  # noqa: BLE001
                pass

    # ---------- imagen de la pantalla
    def pantalla(self, linea=None, ancho=320, alto=240, px=15, oscuro=False):
        from .render import render_screen
        ents = [(e.entrada, e.filas if not e.error else [Row(list('"Error: ' + e.error + '"'))])
                for e in self.historial]
        return render_screen(ents, linea, ancho, alto, px, dark=oscuro)
